// Implementation of the CMeRobot class.
//
////////////////////////////////////////////////////////////////////////////////


#include <d3d9.h>
#include <d3dx9.h>

#include "MeRobot.h"


#define SAFE_DELETE(p)       { if(p) { delete (p);     (p)=NULL; } }
#define SAFE_DELETE_ARRAY(p) { if(p) { delete[] (p);   (p)=NULL; } }
#define SAFE_RELEASE(p)      { if(p) { (p)->Release(); (p)=NULL; } }


CMeRobot::CMeRobot()
{
	m_pDev			= NULL;
	m_pIB			= NULL;
	m_pVB			= NULL;
	m_pTex			= NULL;
}



CMeRobot::~CMeRobot()
{
	Destroy();
}


void CMeRobot::Destroy()
{
	SAFE_RELEASE( m_pVB );
	SAFE_RELEASE( m_pIB );

	SAFE_RELEASE( m_pTex );
}



INT CMeRobot::Create(LPDIRECT3DDEVICE9 pDev)
{
	HRESULT hr=-1;

	m_pDev = pDev;


	//�ؽ��ĸ� �����Ѵ�.
	D3DXCreateTextureFromFileEx(
		m_pDev
		, "Texture/2.png"
		, D3DX_DEFAULT
		, D3DX_DEFAULT
		, D3DX_DEFAULT
		, 0
		, D3DFMT_UNKNOWN
		, D3DPOOL_MANAGED
		, D3DX_DEFAULT
		, D3DX_DEFAULT
		, 0x00FFFFFF
		, NULL
		, NULL
		, &m_pTex);


	// Create the vertex buffer
	m_nTri			= 14;
	m_nVtx			= 28;

	//Ÿ��
	hr = m_pDev->CreateIndexBuffer(
			sizeof(VtxIdx) * m_nTri
			, 0
			, (D3DFORMAT)VtxIdx::FVF
			, D3DPOOL_MANAGED
			, &m_pIB
			, NULL	);

		VtxIdx* pIdx = NULL;

	INT k=0;
	m_pIB->Lock( 0, 0, (void**)&pIdx, 0 );
	

	//��
	int i=0;
	pIdx[i++]	= VtxIdx( 0, 1, 2);
	pIdx[i++]	= VtxIdx( 3, 2, 1);

	//��
	pIdx[i++]	= VtxIdx( 4, 5, 6);
	pIdx[i++]	= VtxIdx( 7, 6, 5);

	//��
	pIdx[i++]	= VtxIdx( 8, 9, 10);
	pIdx[i++]	= VtxIdx( 11, 10, 9);


	//���� ��
	pIdx[i++]	= VtxIdx( 12, 13, 14);
	pIdx[i++]	= VtxIdx( 15, 14, 13);

	//������ ��
	pIdx[i++]	= VtxIdx( 16, 17, 18);
	pIdx[i++]	= VtxIdx( 19, 18, 17);

	//���� �ٸ�
	pIdx[i++]	= VtxIdx( 20, 21, 22);
	pIdx[i++]	= VtxIdx( 23, 22, 21);

	//������ �ٸ�
	pIdx[i++]	= VtxIdx( 24, 25, 26);
	pIdx[i++]	= VtxIdx( 27, 26, 25);

	
	//���ؽ�
	hr = m_pDev->CreateVertexBuffer(
			3 * sizeof(VtxUV) * m_nTri
			, 0
			, VtxUV::FVF
			, D3DPOOL_MANAGED
			, &m_pVB
			, NULL	);

	// Fill the vertex buffer with 2 triangles
	VtxUV* pVertices;

	hr = m_pVB->Lock( 0, 0, (void**)&pVertices, 0 );

	if( FAILED( hr ) )
		return -1;


	float x=400, y=300, z=0, w=1;

	//�Ӹ�
	int j=0;
	pVertices[j++]  = VtxUV(	x-40,	y-250,	8/256.f,	12/256.f	);
	pVertices[j++]  = VtxUV(	x+40,	y-250,	68/256.f,	12/256.f	);		
	pVertices[j++]  = VtxUV(	x-40,	y-170,	8/256.f,	70/256.f	);

	pVertices[j++]  = VtxUV(	x+40,	y-170,	68/256.f,	70/256.f	);

	
	//��
	pVertices[j++]  = VtxUV(	x-20,	y-170,	9/256.f,	79/256.f	);
	pVertices[j++]  = VtxUV(	x+20,	y-170,	35/256.f,	79/256.f	);
	pVertices[j++]  = VtxUV(	x-20,	y-130,	9/256.f,	103/256.f	);

	pVertices[j++]  = VtxUV(	x+20,	y-130,	35/256.f,	103/256.f	);

	
	//��
	pVertices[j++] = VtxUV(	x-65,	y-130,	4/256.f,	138/256.f	);
	pVertices[j++] = VtxUV(	x+65,	y-130,	117/256.f,	138/256.f	);
	pVertices[j++] = VtxUV(	x-65,	y,		4/256.f,	250/256.f	);

	pVertices[j++] = VtxUV(	x+65,	y,		117/256.f,	250/256.f	);

	//���� �ٸ�
	pVertices[j++] = VtxUV(	x-100,	y-130,	87/256.f,	8/256.f		);
	pVertices[j++] = VtxUV(	x-65,	y-130,	116/256.f,	8/256.f		);
	pVertices[j++] = VtxUV(	x-100,	y+50,	87/256.f,	132/256.f	);

	pVertices[j++] = VtxUV(	x-65,	y+50,	116/256.f,	132/256.f	);


	//������ �ٸ�
	pVertices[j++] = VtxUV(	x+65,	y-130,	129/256.f,	8/256.f		);
	pVertices[j++] = VtxUV(	x+100,	y-130,	158/256.f,	8/256.f		);
	pVertices[j++] = VtxUV(	x+65,	y+50,	129/256.f,	132/256.f	);

	pVertices[j++] = VtxUV(	x+100,	y+50,	158/256.f,	132/256.f	);


	//���ʹ�
	pVertices[j++] = VtxUV(	x-65,	y,		172/256.f,	8/256.f		);
	pVertices[j++] = VtxUV(	x-20,	y,		202/256.f,	8/256.f		);
	pVertices[j++] = VtxUV(	x-65,	y+200,	172/256.f,	146/256.f	);

	pVertices[j++] = VtxUV(	x-20,	y+200,	202/256.f,	146/256.f	);

	
	//�����ʹ�
	pVertices[j++] = VtxUV(	x+20,	y,		213/256.f,	8/256.f		);
	pVertices[j++] = VtxUV(	x+65,	y,		243/256.f,	8/256.f		);
	pVertices[j++] = VtxUV(	x+20,	y+200,	213/256.f,	146/256.f	);

	pVertices[j++] = VtxUV(	x+65,	y+200,	243/256.f,	146/256.f	);

	m_pVB->Unlock();
	

	return 0;
}




INT CMeRobot::FrameMove()
{
	return 0;
}



void CMeRobot::Render()
{
	m_pDev->SetTexture(0, m_pTex);

	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSW, D3DTADDRESS_WRAP);

	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);



	//���� ������
//	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);

	//
//	m_pDev->SetRenderState(D3DRS_FILLMODE, D3DFILL_WIREFRAME);

	m_pDev->SetStreamSource( 0, m_pVB, 0, sizeof(VtxUV) );
	m_pDev->SetFVF( VtxUV::FVF );
	m_pDev->SetIndices(m_pIB);
	m_pDev->DrawIndexedPrimitive( D3DPT_TRIANGLELIST, 0, 0, m_nVtx, 0, m_nTri);
//	m_pDev->DrawPrimitive( D3DPT_TRIANGLELIST, 0, 14 );

	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
}





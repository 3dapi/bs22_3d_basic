// Interface for the CMeRobot class.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _MeRobot_H_
#define _MeRobot_H_


#pragma once

struct VtxIdx
{
	WORD	a, b, c;

	VtxIdx() : a(0), b(0), c(0){}
	VtxIdx(WORD A, WORD B, WORD C) : a(A), b(B), c(C){}

	enum { FVF=(D3DFMT_INDEX16),};
};


// Custom D3D vertex format used by the vertex buffer
struct VtxUV
{
	D3DXVECTOR4 p; 

	FLOAT  u, v;

	VtxUV(){}
	VtxUV(FLOAT X, FLOAT Y, FLOAT U, FLOAT V)
	{
		p.x = X;
		p.y = Y;
		p.z = 0;
		p.w = 1;
		u = U;
		v = V;
	}

	enum {FVF =(D3DFVF_XYZRHW | D3DFVF_TEX1)}; 
}; 



class CMeRobot
{
protected:
	LPDIRECT3DDEVICE9		m_pDev;

	INT						m_nVtx;		// ������ ����
	INT						m_nTri;		// �ﰢ���� ����
    LPDIRECT3DVERTEXBUFFER9 m_pVB;      // Vextex buffer
	LPDIRECT3DINDEXBUFFER9	m_pIB;		// Index Buffer
	
	LPDIRECT3DTEXTURE9		m_pTex;		// �ؽ�ó�� ������


public:
	CMeRobot();
	virtual ~CMeRobot();
	
    virtual INT		Create(LPDIRECT3DDEVICE9 pDev);
    virtual void	Destroy();

    virtual INT		FrameMove();
    virtual void	Render();
};



#endif




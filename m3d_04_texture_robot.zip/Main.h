// Interface for the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#pragma once


#ifndef _MAIN_H_
#define _MAIN_H_


class CMain : public CD3DApplication
{
protected:
	ID3DXFont*	m_pD3DXFont;            // D3DX font

	CMeRobot*	m_pRobot;


public:
    virtual HRESULT Init();
    virtual HRESULT Destroy();

    virtual HRESULT Restore();
    virtual HRESULT Invalidate();

    virtual HRESULT FrameMove();
    virtual HRESULT Render();

    HRESULT RenderText();


public:
	CMain();
    LRESULT MsgProc( HWND, UINT, WPARAM, LPARAM);
};


extern CMain* g_pApp;

#endif




// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMain::CMain()
{
	m_pD3DXFont                 = NULL;
	
	m_pInput					= NULL;
	m_pScene					= NULL;
}


HRESULT CMain::Init()
{
	HRESULT hr=-1;

	D3DXFONT_DESC hFont =
	{
		16, 0, FW_NORMAL
			, 1, 0
			, HANGUL_CHARSET
			, OUT_DEFAULT_PRECIS
			, ANTIALIASED_QUALITY
			, FF_DONTCARE
			, "Arial"
	};

	hr = D3DXCreateFontIndirect(m_pd3dDevice, &hFont, &m_pD3DXFont);

	if( FAILED(hr) )
		return -1;
	
	SAFE_NEWCREATE1(m_pInput,	CMcInput, m_pd3dDevice);
	SAFE_NEWCREATE1(m_pScene,	CMcScene, m_pd3dDevice);

	return S_OK;
}


HRESULT CMain::Destroy()
{
	SAFE_DELETE(m_pInput);

	SAFE_DESTROY(m_pScene);
	SAFE_DELETE(m_pScene);

	return S_OK;
}


HRESULT CMain::Restore()
{
	// ���� ��� �����
	D3DXMATRIX m_mtPrj;
	FLOAT	fScreenW = (FLOAT)m_d3dsdBackBuffer.Width;
	FLOAT	fScreenH = (FLOAT)m_d3dsdBackBuffer.Height;
	FLOAT	fFOV	= D3DX_PI/4.0f;
	FLOAT	fAspect	= fScreenW/fScreenH;
	FLOAT	fNear	= 1.f;
	FLOAT	fFar	= 5000.f;
	
	D3DXMatrixPerspectiveFovLH(&m_mtPrj, fFOV, fAspect, fNear, fFar);
	m_pd3dDevice->SetTransform( D3DTS_PROJECTION, &m_mtPrj );

	
	m_pD3DXFont->OnResetDevice();

	return S_OK;
}




HRESULT CMain::FrameMove()
{
	SAFE_FRAMEMOVE(	m_pInput	);
	SAFE_FRAMEMOVE(	m_pScene	);
	
	return S_OK;
}



HRESULT CMain::Render()
{
	// Clear the viewport
	m_pd3dDevice->Clear( 0L, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER | D3DCLEAR_STENCIL, 0x00006699, 1.0f, 0L );
	
	// Begin the scene
	if( SUCCEEDED( m_pd3dDevice->BeginScene() ) )
	{
		// TODO: render world
		m_pScene->Render();
		
		// Render stats and help text  
		RenderText();
		
		// End the scene.
		m_pd3dDevice->EndScene();
	}
	
	return S_OK;
}



HRESULT CMain::RenderText()
{
	D3DCOLOR fontColor        = D3DCOLOR_ARGB(255,255,255,0);
	TCHAR szMsg[MAX_PATH] = TEXT("");
	RECT rct;
	ZeroMemory( &rct, sizeof(rct) );       
	
	rct.left   = 2;
	rct.right  = m_d3dsdBackBuffer.Width - 20;
	
	// Output display stats
	INT nNextLine = 40; 
	
	lstrcpy( szMsg, m_strDeviceStats );
	nNextLine -= 20; rct.top = nNextLine; rct.bottom = rct.top + 20;    
	m_pD3DXFont->DrawText(NULL, szMsg, -1, &rct, 0, fontColor );
	
	lstrcpy( szMsg, m_strFrameStats );
	nNextLine -= 20; rct.top = nNextLine; rct.bottom = rct.top + 20;    
	m_pD3DXFont->DrawText(NULL, szMsg, -1, &rct, 0, fontColor );
	
	return S_OK;
}



LRESULT CMain::MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
	switch( msg )
	{
	case WM_PAINT:
		{
			if( m_bLoadingApp )
			{
				// Draw on the window tell the user that the app is loading
				// TODO: change as needed
				HDC hDC = GetDC( hWnd );
				TCHAR strMsg[MAX_PATH];
				wsprintf( strMsg, TEXT("Loading... Please wait") );
				RECT rct;
				GetClientRect( hWnd, &rct );
				DrawText( hDC, strMsg, -1, &rct, DT_CENTER|DT_VCENTER|DT_SINGLELINE );
				ReleaseDC( hWnd, hDC );
			}
			break;
		}
		
	}
	
	return CD3DApplication::MsgProc( hWnd, msg, wParam, lParam );
}




HRESULT CMain::Invalidate()
{
	// TODO: Cleanup any objects created in Restore()
	SAFE_RELEASE( m_pD3DXFont );
	
	return S_OK;
}




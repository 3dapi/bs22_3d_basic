// Implementation of the CMcScene class.
//
//////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMcScene::CMcScene()
{
	m_pDev		= NULL;
	m_Teapot	= NULL;
}

CMcScene::~CMcScene()
{
	Destroy();
}



void CMcScene::Destroy()
{
	SAFE_RELEASE(	m_Teapot	);
}


INT CMcScene::Create(LPDIRECT3DDEVICE9 pDev)
{
	m_pDev = pDev;
	
	m_Plan[0] = VtxD(-21, -21, 0, 0x66FF00FF);
	m_Plan[1] = VtxD(-21,  21, 0, 0x66FF00FF);
	m_Plan[2] = VtxD( 21,  21, 0, 0x66FF00FF);
	m_Plan[3] = VtxD( 21, -21, 0, 0x66FF00FF);
	
	::D3DXCreateTeapot(m_pDev, &m_Teapot, NULL);

	return 0;
}


void CMcScene::Restore()
{
}

INT	CMcScene::Invalidate()
{
	return 0;
}



INT	 CMcScene::FrameMove()
{
	D3DXVECTOR3 position( 50, 10.0f, -50);
	D3DXVECTOR3 target(0.0f, 0.0f, 0.0f);
	D3DXVECTOR3 up(0.0f, 1.0f, 0.0f);
	
	D3DXMatrixLookAtLH(&m_mtViw, &position, &target, &up);
	
	return 0;
}

void CMcScene::Render()
{
	static	D3DXMATRIX	mtI(1,0,0,0,  0,1,0,0,  0,0,1,0,  0,0,0,1);


	D3DXMATRIX	mtWld;
	D3DXMatrixScaling(&mtWld, 10, 10, 10);


	m_pDev->SetTransform( D3DTS_VIEW, &m_mtViw );

	
	DWORD dFunc=0;
	m_pDev->GetRenderState(D3DRS_ZFUNC,  &dFunc);

	// ���̸� ����.
	m_pDev->SetRenderState(D3DRS_COLORWRITEENABLE, 0);
	m_pDev->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
	m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);
	m_pDev->SetRenderState(D3DRS_ZWRITEENABLE, TRUE);
	m_pDev->SetFVF(VtxD::FVF);
	m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLEFAN, 2, m_Plan, sizeof(VtxD));

	// ���ٽ��� ����Ѵ�.
//	m_pDev->SetRenderState(D3DRS_STENCILENABLE, TRUE);
//	m_pDev->SetRenderState(D3DRS_STENCILREF, 0X1);
//	m_pDev->SetRenderState(D3DRS_STENCILMASK, 0X0000FFFF);
//	m_pDev->SetRenderState(D3DRS_STENCILFUNC, D3DCMP_ALWAYS );
//	m_pDev->SetRenderState(D3DRS_STENCILZFAIL,     D3DSTENCILOP_KEEP);
//	m_pDev->SetRenderState(D3DRS_STENCILFAIL,      D3DSTENCILOP_KEEP);
//	m_pDev->SetRenderState(D3DRS_STENCILPASS,      D3DSTENCILOP_REPLACE);

	m_pDev->SetRenderState(D3DRS_ZWRITEENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_COLORWRITEENABLE, 0XF);
	m_pDev->SetRenderState(D3DRS_ZFUNC,  D3DCMP_GREATER);


	m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
	m_pDev->SetRenderState(D3DRS_LIGHTING, FALSE);
	m_pDev->SetTransform(D3DTS_WORLD, &mtWld);
	m_Teapot->DrawSubset(0);


	m_pDev->SetTransform(D3DTS_WORLD, &mtI);


	m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);

	// ���̰� ����, ���ٽ� ���۷����� 0X1�� �κи� ��ĥ�Ѵ�.
//	m_pDev->SetRenderState(D3DRS_STENCILENABLE, TRUE);
//	m_pDev->SetRenderState(D3DRS_STENCILREF, 0X1);
//	m_pDev->SetRenderState(D3DRS_STENCILMASK, 0X0000FFFF);
//	m_pDev->SetRenderState(D3DRS_STENCILFUNC, D3DCMP_EQUAL);
//	m_pDev->SetRenderState(D3DRS_STENCILZFAIL,     D3DSTENCILOP_KEEP);
//	m_pDev->SetRenderState(D3DRS_STENCILFAIL,      D3DSTENCILOP_KEEP);
//	m_pDev->SetRenderState(D3DRS_STENCILPASS,      D3DSTENCILOP_KEEP);

//	m_pDev->SetRenderState(D3DRS_ZFUNC,  D3DCMP_EQUAL);
//	m_pDev->SetFVF(VtxD::FVF);
//	m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLEFAN, 2, m_Plan, sizeof(VtxD));


	m_pDev->SetRenderState(D3DRS_STENCILENABLE, FALSE);
	m_pDev->SetRenderState(D3DRS_ZWRITEENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);
	
	m_pDev->SetRenderState(D3DRS_ZFUNC,  dFunc);

	RenderXYZ();
}


void CMcScene::RenderXYZ()
{
	VtxD pVtx[12];
	FLOAT fMax = 10000;

	pVtx[ 0] = VtxD(-fMax,     0,     0, 0xFFFF0000);
	pVtx[ 1] = VtxD(    0,     0,     0, 0xFFFF0000);
	pVtx[ 2] = VtxD(    0,     0,     0, 0xFFFF0000);
	pVtx[ 3] = VtxD( fMax,     0,     0, 0xFFFF0000);

	pVtx[ 4] = VtxD(    0, -fMax,     0, 0xFF00FF00);
	pVtx[ 5] = VtxD(    0,     0,     0, 0xFF00FF00);
	pVtx[ 6] = VtxD(    0,     0,     0, 0xFF00FF00);
	pVtx[ 7] = VtxD(    0,  fMax,     0, 0xFF00FF00);

	pVtx[ 8] = VtxD(    0,     0, -fMax, 0xFF0000FF);
	pVtx[ 9] = VtxD(    0,     0,     0, 0xFF0000FF);
	pVtx[10] = VtxD(    0,     0,     0, 0xFF0000FF);
	pVtx[11] = VtxD(    0,     0,  fMax, 0xFF0000FF);

	// Render Lines
	m_pDev->SetRenderState( D3DRS_LIGHTING,  FALSE);
	
	m_pDev->SetTexture(0, NULL);
	m_pDev->SetFVF(CMcScene::VtxD::FVF);
	m_pDev->DrawPrimitiveUP(D3DPT_LINELIST, 6, pVtx, sizeof(VtxD));
}
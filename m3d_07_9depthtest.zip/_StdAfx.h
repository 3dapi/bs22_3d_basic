#pragma warning(disable: 4324)
#pragma warning(disable: 4996)


#ifndef __STDAFX_H_
#define __STDAFX_H_

#pragma once

#define STRICT
#define _WIN32_WINNT			0x0400
#define DIRECTINPUT_VERSION		0x0800

#pragma comment(lib, "dinput8.lib")

#include <windows.h>
#include <commctrl.h>
#include <commdlg.h>
#include <basetsd.h>
#include <math.h>
#include <stdio.h>
#include <tchar.h>

#include <d3dx9.h>

#include <dinput.h>


#include "DXUtil.h"
#include "D3DEnum.h"
#include "d3dsettings.h"
#include "D3DApp.h"
#include "D3DUtil.h"
#include "resource.h"


#include "McUtil.h"
#include "McInput.h"

#include "McScene.h"



#include "Main.h"

#endif
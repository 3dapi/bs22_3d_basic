// Interface for the CMcScene class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _MCSCENE_H_
#define _MCSCENE_H_

class CMcScene
{
public:
	struct VtxD
	{
		D3DXVECTOR3 p;
		DWORD		d;

		VtxD() : p(0,0,0), d(0xFFFFFFFF){};
		VtxD(FLOAT X, FLOAT Y, FLOAT Z, DWORD D=0xFFFFFFFF) : p(X,Y,Z), d(D){};

		enum {FVF =(D3DFVF_XYZ|D3DFVF_DIFFUSE), };
	};


protected:
	LPDIRECT3DDEVICE9	m_pDev	;

	LPD3DXMESH		m_Teapot	;
	VtxD			m_Plan[4]	;

	D3DXMATRIX		m_mtViw		;
	
public:
	CMcScene();
	virtual ~CMcScene();
	
	INT		Create(LPDIRECT3DDEVICE9 pDev);
	void	Restore();
	INT		Invalidate();
	void	Destroy();

	INT		FrameMove();
	void	Render();

	void	RenderXYZ();
};

#endif

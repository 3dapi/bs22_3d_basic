// Interface for the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _MAIN_H_
#define _MAIN_H_


#pragma once


class CMain : public CD3DApplication
{
protected:
	ID3DXFont*		m_pD3DXFont;            // D3DX font

	ID3DXMesh*		m_pBox;
	D3DXMATRIX		m_mtBox;

public:
    virtual HRESULT Init();
    virtual HRESULT Destroy();

    virtual HRESULT Restore();
    virtual HRESULT Invalidate();

    virtual HRESULT FrameMove();
    virtual HRESULT Render();

    HRESULT RenderText();

public:
	CMain();
    LRESULT MsgProc( HWND, UINT, WPARAM, LPARAM);
};


extern CMain* g_pApp;

#endif




// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMain::CMain()
{
	m_dwCreationWidth			= 1024;
	m_dwCreationHeight			= 768;
	strcpy(m_strClassName, TEXT( "Sp3DApp" ));

	m_bStartFullscreen			= false;
	m_bShowCursorWhenFullscreen	= true;

	m_pBox	= NULL;
	D3DXMatrixIdentity(&m_mtBox);
}



HRESULT CMain::Init()
{
	// TODO: create device objects
	HRESULT hr=-1;


	// Create a D3D font using D3DX
	D3DXFONT_DESC hFont =
	{
		16, 0
		, FW_NORMAL
		, 1					// Mip Level
		, FALSE				// Italic
		, HANGUL_CHARSET	// Charset
		, OUT_DEFAULT_PRECIS// Output Precision
		, ANTIALIASED_QUALITY// Qulity
		, FF_DONTCARE		// Pitch And Family
		, "Arial"			// FaceName
	};

	if( FAILED( hr = D3DXCreateFontIndirect( m_pd3dDevice, &hFont, &m_pD3DXFont ) ) )
		return -1;

	
	// Initialize Data....
	D3DXCreateBox(m_pd3dDevice, 10, 20, 30, &m_pBox, NULL);
	
	
	return S_OK;
}


HRESULT CMain::Destroy()
{
	SAFE_RELEASE(	m_pD3DXFont	);

	SAFE_RELEASE(	m_pBox		);

	return S_OK;
}



HRESULT CMain::Restore()
{
	HRESULT hr = -1;

	// Antialias Enable
	m_pd3dDevice->SetRenderState (D3DRS_MULTISAMPLEANTIALIAS, TRUE);
	m_pd3dDevice->SetRenderState (D3DRS_ANTIALIASEDLINEENABLE, TRUE);

	m_pD3DXFont->OnResetDevice();

	return S_OK;
}



HRESULT CMain::Invalidate()
{
	m_pD3DXFont->OnLostDevice();

	return S_OK;
}



HRESULT CMain::FrameMove()
{
	D3DXMATRIX matView;
	D3DXVECTOR3 vFromPt		= D3DXVECTOR3( 0.0f, 0.0f, -55.0f );
	D3DXVECTOR3 vLookatPt	= D3DXVECTOR3( 0.0f, 0.0f, 0.0f );
	D3DXVECTOR3 vUpVec		= D3DXVECTOR3( 0.0f, 1.0f, 0.0f );

	D3DXMatrixLookAtLH( &matView, &vFromPt, &vLookatPt, &vUpVec );
	m_pd3dDevice->SetTransform( D3DTS_VIEW, &matView );

	// Set the projection matrix
	D3DXMATRIX matProj;
	FLOAT fAspect = ((FLOAT)m_d3dsdBackBuffer.Width) / m_d3dsdBackBuffer.Height;
	D3DXMatrixPerspectiveFovLH( &matProj, D3DX_PI/4, fAspect, 1.0f, 5000.0f );
	m_pd3dDevice->SetTransform( D3DTS_PROJECTION, &matProj );


	static float fAngle =0.f;

	fAngle +=0.001f;
	D3DXMatrixRotationY(&m_mtBox,fAngle);

	return S_OK;
}


HRESULT CMain::Render()
{
	// Clear the viewport
	m_pd3dDevice->Clear( 0L
						, NULL
						, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER | D3DCLEAR_STENCIL
						, 0x00006699
						, 1.0f
						, 0L );

	if( FAILED( m_pd3dDevice->BeginScene() ) )
		return -1;


	m_pd3dDevice->SetRenderState(D3DRS_LIGHTING, FALSE);
	m_pd3dDevice->SetRenderState(D3DRS_FILLMODE, D3DFILL_WIREFRAME);
	m_pd3dDevice->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);


	m_pd3dDevice->SetTransform(D3DTS_WORLD, &m_mtBox);
	m_pBox->DrawSubset(0);


	static D3DXMATRIX mtIdentity(	1,0,0,0,
									0,1,0,0,
									0,0,1,0,
									0,0,0,1);
	m_pd3dDevice->SetTransform(D3DTS_WORLD, &mtIdentity);



	RenderText();
	m_pd3dDevice->EndScene();

	return S_OK;
}



HRESULT CMain::RenderText()
{
	D3DCOLOR fontColor		= D3DCOLOR_ARGB(255,255,255,0);
	TCHAR szMsg[MAX_PATH]	= {0};

	sprintf( szMsg, "%s %s", m_strDeviceStats, m_strFrameStats );


	RECT rct={ 10, 10, m_d3dsdBackBuffer.Width - 20, 10+30};
	m_pD3DXFont->DrawText(NULL, szMsg, -1, &rct, 0, fontColor );

	return S_OK;
}



LRESULT CMain::MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
	switch( msg )
	{
		case WM_PAINT:
		{
			if( m_bLoadingApp )
			{
				// Draw on the window tell the user that the app is loading
				HDC hDC = GetDC( hWnd );

				ReleaseDC( hWnd, hDC );
			}
			break;
		}

	}

	return CD3DApplication::MsgProc( hWnd, msg, wParam, lParam );
}





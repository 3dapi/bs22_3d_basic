//
//
////////////////////////////////////////////////////////////////////////////////

#pragma once

#pragma warning(disable: 4996)

#ifndef __STDAFX_H_
#define __STDAFX_H_

#define STRICT
#define WIN32_LEAN_AND_MEAN

#define _WIN32_WINNT			0x0400
#define _WIN32_WINDOWS			0x0400

#define DIRECTINPUT_VERSION		0x0800


#pragma warning( disable : 4018)
#pragma warning( disable : 4098)
#pragma warning( disable : 4100)
#pragma warning( disable : 4238)
#pragma warning( disable : 4245)
#pragma warning( disable : 4503)
#pragma warning( disable : 4663)
#pragma warning( disable : 4786)


// Static Library
#pragma comment(lib, "shell32.lib"		)
#pragma comment(lib, "comctl32.lib"		)



#include <windows.h>
#include <commctrl.h>
#include <commdlg.h>
#include <basetsd.h>
#include <math.h>
#include <stdio.h>
#include <tchar.h>

#include <d3d9.h>
#include <d3dx9.h>

// 2009 Auqust version
#if D3DX_SDK_VERSION == 42

#include <DxErr.h>
#pragma comment(lib, "DxErr.lib"	)

#elif D3DX_SDK_VERSION == 21

#pragma comment(lib, "dxerr9.lib"	)

#endif


#include "DXUtil.h"
#include "D3DEnum.h"
#include "D3DSettings.h"
#include "D3DApp.h"
#include "D3DUtil.h"
#include "resource.h"


// TODO: create user header files.



//

#include "Main.h"

#endif




// Interface for the CMcScene class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _McScene_H_
#define _McScene_H_

class CMcScene
{
public:
	LPDIRECT3DDEVICE9	m_pDev;

	LPD3DXMESH			m_pTeapot;

	D3DXMATRIX m_mtWld;
	D3DXMATRIX m_mtViw;
	D3DXMATRIX m_mtPrj;

public:
	CMcScene();
	virtual ~CMcScene();

	INT		Create(LPDIRECT3DDEVICE9 pDev);
	void	Destroy();

	INT		FrameMove();
	void	Render();
};

#endif
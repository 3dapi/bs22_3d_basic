// Implementation of the CMcScene class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


void LcMatrixReflect(void* pOutMatrix, const void* Plane, BOOL bNormalized=FALSE)
{
	D3DXPLANE	P((FLOAT*)Plane);

	D3DXMATRIX	mtS;

	// Normalize Plane
	if(FALSE == bNormalized)
		D3DXPlaneNormalize(&P, &P);

	// Setup Output Value
	mtS  = D3DXMATRIX
	(
		1 - 2 * P.a * P.a,	  - 2 * P.a * P.b,	  - 2 * P.a * P.c,    - 2 * P.a * P.d,
		  - 2 * P.b * P.a,	1 - 2 * P.b * P.b,	  - 2 * P.b * P.c,    - 2 * P.b * P.d,
		  - 2 * P.c * P.a,	  - 2 * P.c * P.b,	1 - 2 * P.c * P.c,    - 2 * P.c * P.d,
		  - 2 * P.d * P.a,	  - 2 * P.d * P.b,	  - 2 * P.d * P.c,  1 - 2 * P.d * P.d
	);

	// Copy Output value
	*((D3DXMATRIX*)pOutMatrix) = mtS;
}


void __main()
{
	INT	i,j;

	printf("\n D3DXRefelct ..\n\n");

	D3DXMATRIX mtShd1;
	D3DXMATRIX mtShd2;


	D3DXPLANE	P(13,52,86,21470);

	D3DXMatrixReflect(&mtShd1, &P);
	LcMatrixReflect(&mtShd2, &P);

	printf("Test1....\n");

	for(i=0; i<4; ++i)
	{
		for(j=0; j<4; ++j)
			printf("%12.6f   ",mtShd1.m[i][j]);
		
		printf("\n");

		for(j=0; j<4; ++j)
			printf("%12.6f   ",mtShd2.m[i][j]);

		printf("\n");
	}

	printf("\n");

	printf("Test2..\n");



	D3DXMatrixReflect(&mtShd1, &P);
	LcMatrixReflect(&mtShd2, &P);
	

	for(i=0; i<4; ++i)
	{
		for(j=0; j<4; ++j)
			printf("%12.6f   ",mtShd1.m[i][j]);
		
		printf("\n");

		for(j=0; j<4; ++j)
			printf("%12.6f   ",mtShd2.m[i][j]);

		printf("\n");
	}

	printf("\n");
}




CMcScene::CMcScene()
{
	m_pDev	= NULL;
	
	m_nVtx	= 0;
	m_nIdx	= 0;
	m_pVtx	= NULL;
	m_pIdx	= NULL;
	
	m_pTxTiger	= NULL;


	m_pTxWall	= NULL;
}

CMcScene::~CMcScene()
{
	Destroy();
}

INT CMcScene::Create(LPDIRECT3DDEVICE9 pDev)
{
	HRESULT hr;
	m_pDev	= pDev;
	


	// Setup Tiger
	{
		LPD3DXMESH		pMdlS=NULL;
		if( FAILED( D3DXLoadMeshFromX( "xFile/Tiger.x",	D3DXMESH_SYSTEMMEM,	m_pDev, NULL, NULL, NULL, NULL, &pMdlS ) ) )
			return -1;
		
		D3DXCreateTextureFromFile(m_pDev, "xFile/tiger.bmp", &m_pTxTiger);
		
		
		LPD3DXMESH pMdlD=NULL;
		hr = pMdlS->CloneMeshFVF(D3DXMESH_SYSTEMMEM, VtxUV1::FVF, m_pDev, &pMdlD);
		pMdlS->Release();
		
		m_nVtx = pMdlD->GetNumVertices();
		m_nIdx = pMdlD->GetNumFaces();
		
		//	DWORD dFVF = pMdlD->GetFVF();
		
		m_pVtx = new VtxUV1[m_nVtx];
		m_pIdx = new VtxIdx[m_nIdx];
		
		void* pVtx= NULL;
		hr = pMdlD->LockVertexBuffer(0, &pVtx);
		
		memcpy(m_pVtx, pVtx, m_nVtx * sizeof(VtxUV1));
		
		hr = pMdlD->UnlockVertexBuffer();
		
		void* pIdx= NULL;
		hr = pMdlD->LockIndexBuffer(0, &pIdx);
		
		memcpy(m_pIdx, pIdx, m_nIdx * sizeof(VtxIdx));
		
		hr = pMdlD->UnlockIndexBuffer();
		
		pMdlD->Release();
		
		
		float fSCale=12;
		for(int i=0; i<m_nVtx; ++i)
		{
			m_pVtx[i].p *= fSCale;
		}

		m_vcTiger = D3DXVECTOR3(0.0f, -3.0f, -16.f);
	}


	// Setup Wall
	D3DXCreateTextureFromFile(m_pDev, "Texture/seafloor.bmp", &m_pTxWall);

	m_pVtxWall[0]	= VtxUV1(-20.f, -20.0f, 0.0f, 0.0f, 0.0f);
	m_pVtxWall[1]	= VtxUV1(-20.f,  20.0f, 0.0f, 0.0f, 0.0f);
	m_pVtxWall[2]	= VtxUV1(  0.f,  20.0f, 0.0f, 1.0f, 0.0f);
	m_pVtxWall[3]	= VtxUV1(  0.f, -20.0f, 0.0f, 1.0f, 0.0f);

	m_pVtxMirr[0]	= VtxUV1(  0.f, -20.0f, 0.0f, 0.0f, 1.0f);
	m_pVtxMirr[1]	= VtxUV1(  0.f,  20.0f, 0.0f, 0.0f, 0.0f);
	m_pVtxMirr[2]	= VtxUV1( 20.f,  20.0f, 0.0f, 0.0f, 0.0f);
	m_pVtxMirr[3]	= VtxUV1( 20.f, -20.0f, 0.0f, 0.0f, 1.0f);

	
	return 0;
}


void CMcScene::Destroy()
{
	SAFE_DELETE_ARRAY(	m_pVtx		);
	SAFE_DELETE_ARRAY(	m_pIdx		);
	SAFE_RELEASE(	m_pTxTiger	);
	SAFE_RELEASE(	m_pTxWall	);
}

INT CMcScene::FrameMove()
{
	return 0;
}


void CMcScene::Render()
{
	D3DXMATRIX mtWld;	D3DXMatrixIdentity(&mtWld);
	D3DXMATRIX mtRot;	D3DXMatrixRotationY(&mtRot, D3DXToRadian(GetTickCount() *0.05F));
	D3DXMATRIX mtI;		D3DXMatrixIdentity(&mtI);


	m_pDev->SetRenderState(D3DRS_LIGHTING, FALSE);
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);


	// 1. ���ٽ��� Default�� �����Ǿ� �ִ� ȣ���̿� ���� ���� �׸���.
	// ȣ����
	mtWld = mtRot;
	mtWld._41 = m_vcTiger.x; mtWld._42 = m_vcTiger.y; mtWld._43 = m_vcTiger.z;

	m_pDev->SetTransform(D3DTS_WORLD, &mtWld);
	m_pDev->SetFVF(VtxUV1::FVF);
	m_pDev->SetTexture(0, m_pTxTiger);
	m_pDev->DrawIndexedPrimitiveUP(D3DPT_TRIANGLELIST, 0, m_nVtx, m_nIdx, m_pIdx, D3DFMT_INDEX16, m_pVtx, sizeof(VtxUV1));

	m_pDev->SetTexture(0, NULL);
	m_pDev->SetTransform(D3DTS_WORLD, &mtI);


	// ������ ��
	m_pDev->SetTexture(0, m_pTxWall);
	m_pDev->SetFVF(VtxUV1::FVF);
	m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLEFAN, 2, m_pVtxWall, sizeof(VtxUV1));


	


	// 2. ���ٽ� ������ ���� ������ ���� �׸���.
	// ȣ���̰� �� �ڿ� �׷����� ������ ������ z���� ���� ���� �ʵ��� �Ѵ�.
	m_pDev->SetRenderState(D3DRS_ZWRITEENABLE, FALSE);

	m_pDev->SetRenderState(D3DRS_STENCILENABLE,    TRUE);
	m_pDev->SetRenderState(D3DRS_STENCILFUNC,      D3DCMP_ALWAYS);
	m_pDev->SetRenderState(D3DRS_STENCILREF,       0x1);
	m_pDev->SetRenderState(D3DRS_STENCILMASK,      0xffffffff);
	m_pDev->SetRenderState(D3DRS_STENCILWRITEMASK, 0xffffffff);
	m_pDev->SetRenderState(D3DRS_STENCILZFAIL,     D3DSTENCILOP_KEEP);
	m_pDev->SetRenderState(D3DRS_STENCILFAIL,      D3DSTENCILOP_KEEP);
	m_pDev->SetRenderState(D3DRS_STENCILPASS,      D3DSTENCILOP_REPLACE);

	m_pDev->SetTexture(0, m_pTxWall);
	m_pDev->SetFVF(VtxUV1::FVF);
	m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLEFAN, 2, m_pVtxMirr, sizeof(VtxUV1));

	m_pDev->SetRenderState(D3DRS_ZWRITEENABLE, TRUE);




	// 3. ȣ���̿� ���ٽ��� ����
	m_pDev->SetRenderState(D3DRS_STENCILENABLE,    TRUE);
	m_pDev->SetRenderState(D3DRS_STENCILFUNC,		D3DCMP_EQUAL);
	m_pDev->SetRenderState(D3DRS_STENCILREF,       0x1);
	m_pDev->SetRenderState(D3DRS_STENCILMASK,      0xffffffff);
	m_pDev->SetRenderState(D3DRS_STENCILWRITEMASK, 0xffffffff);
	m_pDev->SetRenderState(D3DRS_STENCILZFAIL, D3DSTENCILOP_KEEP);
	m_pDev->SetRenderState(D3DRS_STENCILFAIL,  D3DSTENCILOP_KEEP);
	m_pDev->SetRenderState(D3DRS_STENCILPASS,  D3DSTENCILOP_KEEP);


	// ���� �ݴ� �鿡 ȣ���̸� �׸��� ���� ���� ��� ����
	D3DXMATRIX mtTrn;
	D3DXMATRIX mtRfc;
	D3DXPLANE plane(0.0f, 0.0f, -1.0f, 0.0f); // xy plane
	D3DXMatrixReflect(&mtRfc, &plane);
	D3DXMatrixTranslation(&mtTrn, m_vcTiger.x, m_vcTiger.y+12, -m_vcTiger.z);

	mtWld = mtRot * mtRfc * mtTrn;


	// �ݻ� ��Ŀ� ���� CW���� CCW�� �ø� �ȴ�. �̰��� �ٲپ�� �Ѵ�.
	m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_CW);

	// ȣ���̸� �׸���.
	m_pDev->SetTransform(D3DTS_WORLD, &mtWld);
	m_pDev->SetFVF(VtxUV1::FVF);
	m_pDev->SetTexture(0, m_pTxTiger);
	m_pDev->DrawIndexedPrimitiveUP(D3DPT_TRIANGLELIST, 0, m_nVtx, m_nIdx, m_pIdx, D3DFMT_INDEX16, m_pVtx, sizeof(VtxUV1));


	
	m_pDev->SetTransform(D3DTS_WORLD, &mtI);
	m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);
	m_pDev->SetRenderState( D3DRS_STENCILENABLE, FALSE);

	m_pDev->SetTexture(0, NULL);
}




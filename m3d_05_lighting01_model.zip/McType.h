#ifndef _MCTYPE_H_
#define _MCTYPE_H_

typedef D3DXMATRIX					MATA;
typedef D3DXVECTOR2					VEC2;
typedef D3DXVECTOR3					VEC3;
typedef D3DXVECTOR4					VEC4;

typedef LPDIRECT3DVERTEXBUFFER9		PDVB;

#endif
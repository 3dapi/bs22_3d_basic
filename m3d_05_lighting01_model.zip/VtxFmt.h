#ifndef _VTXFMT_H_
#define _VTXFMT_H_

struct VtxN
{
	D3DXVECTOR3	p;
	D3DXVECTOR3	n;
	
	VtxN(){}
	VtxN(FLOAT X,FLOAT Y,FLOAT Z
		,FLOAT nX,FLOAT nY,FLOAT nZ) : p(X,Y,Z),n(nX,nY,nZ){}
	
	enum {FVF = (D3DFVF_XYZ|D3DFVF_NORMAL)};
};


#endif
// Interface for the CMcScene class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _McScene_H_
#define _McScene_H_

class CMcScene
{
protected:
	LPDIRECT3DDEVICE9		m_pDev;

	INT						m_nVtx;
	INT						m_nIdx;
	VtxUV1 *				m_pVtx;
	VtxIdx*					m_pIdx;
	LPDIRECT3DTEXTURE9		m_pTxTiger;
	D3DXVECTOR3				m_vcTiger;

	LPDIRECT3DTEXTURE9		m_pTxFloor;
	VtxUV1					m_pVtxFloor[4];
	
public:
	CMcScene();
	virtual ~CMcScene();

	INT		Create(LPDIRECT3DDEVICE9 pDev);
	void	Destroy();

	INT		FrameMove();
	void	Render();
};

#endif
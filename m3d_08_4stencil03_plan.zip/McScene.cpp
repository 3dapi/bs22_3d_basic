// Implementation of the CMcScene class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMcScene::CMcScene()
{
	m_pDev	= NULL;
	
	m_nVtx	= 0;
	m_nIdx	= 0;
	m_pVtx	= NULL;
	m_pIdx	= NULL;
	
	m_pTxTiger	= NULL;


	m_pTxFloor	= NULL;
}

CMcScene::~CMcScene()
{
	Destroy();
}

INT CMcScene::Create(LPDIRECT3DDEVICE9 pDev)
{
	HRESULT hr;
	INT		i;

	m_pDev	= pDev;
	


	// Setup Tiger
	{
		LPD3DXMESH		pMdlS=NULL;
		if( FAILED( D3DXLoadMeshFromX( "xFile/Tiger.x",	D3DXMESH_SYSTEMMEM,	m_pDev, NULL, NULL, NULL, NULL, &pMdlS ) ) )
			return -1;
		
		D3DXCreateTextureFromFile(m_pDev, "xFile/tiger.bmp", &m_pTxTiger);
		
		
		LPD3DXMESH pMdlD=NULL;
		hr = pMdlS->CloneMeshFVF(D3DXMESH_SYSTEMMEM, VtxUV1::FVF, m_pDev, &pMdlD);
		pMdlS->Release();
		
		m_nVtx = pMdlD->GetNumVertices();
		m_nIdx = pMdlD->GetNumFaces();
		
		//	DWORD dFVF = pMdlD->GetFVF();
		
		m_pVtx = new VtxUV1[m_nVtx];
		m_pIdx = new VtxIdx[m_nIdx];
		
		void* pVtx= NULL;
		hr = pMdlD->LockVertexBuffer(0, &pVtx);
		
		memcpy(m_pVtx, pVtx, m_nVtx * sizeof(VtxUV1));
		
		hr = pMdlD->UnlockVertexBuffer();
		
		void* pIdx= NULL;
		hr = pMdlD->LockIndexBuffer(0, &pIdx);
		
		memcpy(m_pIdx, pIdx, m_nIdx * sizeof(VtxIdx));
		
		hr = pMdlD->UnlockIndexBuffer();
		
		pMdlD->Release();
		
		
		float fSCale=10;
		float	fMin=100000;
		for(i=0; i<m_nVtx; ++i)
		{
			m_pVtx[i].p *= fSCale;

			if(	m_pVtx[i].p.y<fMin)
				fMin= m_pVtx[i].p.y;
		}

		fMin = -fMin;

		for(i=0; i<m_nVtx; ++i)
		{
			m_pVtx[i].p.y +=fMin;
		}

		m_vcTiger = D3DXVECTOR3(8.f, 0.f, 0.f);
	}


	// Setup Floor
	D3DXCreateTextureFromFile(m_pDev, "Texture/seafloor.bmp", &m_pTxFloor);

	m_pVtxFloor[0] = VtxUV1(-25.f, -1.f, -25.f, 0.f, 4.f);
	m_pVtxFloor[1] = VtxUV1(-25.f, -1.f,  25.f, 0.f, 0.f);
	m_pVtxFloor[2] = VtxUV1( 25.f, -1.f,  25.f, 0.f, 0.f);
	m_pVtxFloor[3] = VtxUV1( 25.f, -1.f, -25.f, 0.f, 4.f);

	
	return 0;
}


void CMcScene::Destroy()
{
	SAFE_DELETE_ARRAY(	m_pVtx		);
	SAFE_DELETE_ARRAY(	m_pIdx		);
	SAFE_RELEASE(	m_pTxTiger	);
	SAFE_RELEASE(	m_pTxFloor	);
}

INT CMcScene::FrameMove()
{
	return 0;
}


void CMcScene::Render()
{
	D3DXMATRIX mtWld;	D3DXMatrixIdentity(&mtWld);
	D3DXMATRIX mtRot;	D3DXMatrixRotationY(&mtRot, D3DXToRadian(GetTickCount() *0.05F));
	D3DXMATRIX mtI;	D3DXMatrixIdentity(&mtI);


	m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);
	m_pDev->SetRenderState(D3DRS_LIGHTING, FALSE);
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);

	m_pDev->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
	m_pDev->SetTextureStageState(0, D3DTSS_COLORARG2, D3DTA_DIFFUSE);
	m_pDev->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_SELECTARG1);


	// 1. ���ٽ��� Default�� �����Ǿ� �ִ� ������Ʈ���� ���� �׸���.
	// ȣ���̸� �׸���.
	mtWld = mtRot;
	mtWld._41 = m_vcTiger.x; mtWld._42 = m_vcTiger.y; mtWld._43 = m_vcTiger.z;

	m_pDev->SetTransform(D3DTS_WORLD, &mtWld);
	m_pDev->SetFVF(VtxUV1::FVF);
	m_pDev->SetTexture(0, m_pTxTiger);
	m_pDev->DrawIndexedPrimitiveUP(D3DPT_TRIANGLELIST, 0, m_nVtx, m_nIdx, m_pIdx, D3DFMT_INDEX16, m_pVtx, sizeof(VtxUV1));

	m_pDev->SetTexture(0, NULL);
	m_pDev->SetTransform(D3DTS_WORLD, &mtI);



	// 2. ���ٽ��� �����ϰ� �ٴ��� �׸���.
	m_pDev->SetRenderState(D3DRS_ZWRITEENABLE, FALSE);

	m_pDev->SetRenderState(D3DRS_STENCILENABLE,    TRUE);
	m_pDev->SetRenderState(D3DRS_STENCILFUNC,      D3DCMP_ALWAYS);
	m_pDev->SetRenderState(D3DRS_STENCILREF,       0x1);
	m_pDev->SetRenderState(D3DRS_STENCILMASK,      0xffffffff);
	m_pDev->SetRenderState(D3DRS_STENCILWRITEMASK, 0xffffffff);
	m_pDev->SetRenderState(D3DRS_STENCILZFAIL,     D3DSTENCILOP_KEEP);
	m_pDev->SetRenderState(D3DRS_STENCILFAIL,      D3DSTENCILOP_KEEP);
	m_pDev->SetRenderState(D3DRS_STENCILPASS,      D3DSTENCILOP_REPLACE);
	
	m_pDev->SetTexture(0, m_pTxFloor);
	m_pDev->SetFVF(VtxUV1::FVF);
	m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLEFAN, 2, m_pVtxFloor, sizeof(VtxUV1));
	m_pDev->SetRenderState(D3DRS_ZWRITEENABLE, TRUE);


	//2. �׸��ڸ� �׸���.
	// ȣ���̸� ���� ���� ����� �����Ѵ�.
	// ȣ���̸� ��鿡 ���� �ǵ��� ����� �����.

	D3DXVECTOR4 vcLight(-2.8f, -1.0f, 0.0f, 0.0f);
	D3DXPLANE	dxPlane(  0.f, -1.0f, 0.0f, 0.0f);

	D3DXMATRIX mtShd;
	D3DXMATRIX mtTrn;

	D3DXVec4Normalize(&vcLight, &vcLight);
	D3DXMatrixShadow(&mtShd, &vcLight, &dxPlane);
	D3DXMatrixTranslation(&mtTrn, m_vcTiger.x, m_vcTiger.y, m_vcTiger.z);

	mtWld = mtShd* mtRot *mtTrn;



	// ȣ���̸� ��鿡 �׸��� ���ٽ� ���� 1�� �����Ѵ�.
	m_pDev->SetRenderState(D3DRS_STENCILENABLE,    TRUE);
	m_pDev->SetRenderState(D3DRS_STENCILFUNC,      D3DCMP_EQUAL);
	m_pDev->SetRenderState(D3DRS_STENCILREF,       0x1);
	m_pDev->SetRenderState(D3DRS_STENCILMASK,      0xffffffff);
	m_pDev->SetRenderState(D3DRS_STENCILWRITEMASK, 0xffffffff);

	// ȣ���̿� ���� ��� ���ٽ� �׽�Ʈ�� ���ؼ� ���� 0X1�� �����Ѵ�.
	m_pDev->SetRenderState(D3DRS_STENCILZFAIL,     D3DSTENCILOP_KEEP);
	m_pDev->SetRenderState(D3DRS_STENCILFAIL,      D3DSTENCILOP_KEEP);
	m_pDev->SetRenderState(D3DRS_STENCILPASS,      D3DSTENCILOP_KEEP);


	// ���� ������ Ȱ��ȭ
	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);


	// ����̽��� TFACTOR ������ ���ϰ� �̰��� ȣ���� �������� �����Ѵ�.
	m_pDev->SetRenderState(D3DRS_TEXTUREFACTOR, D3DXCOLOR(0.3F, 0.3F, 0.3F, 0.3F));
	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_TFACTOR );
	m_pDev->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_SELECTARG2 );

	// ȣ���̸� �׸���.
	m_pDev->SetTransform(D3DTS_WORLD, &mtWld);
	m_pDev->SetFVF(VtxUV1::FVF);
	m_pDev->SetTexture(0, NULL);
	m_pDev->DrawIndexedPrimitiveUP(D3DPT_TRIANGLELIST, 0, m_nVtx, m_nIdx, m_pIdx, D3DFMT_INDEX16, m_pVtx, sizeof(VtxUV1));


	m_pDev->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
	m_pDev->SetTextureStageState(0, D3DTSS_COLORARG2, D3DTA_DIFFUSE);
	m_pDev->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_MODULATE);

	m_pDev->SetTexture(0, NULL);
	m_pDev->SetTransform(D3DTS_WORLD, &mtI);

	m_pDev->SetRenderState(D3DRS_BLENDOP, D3DBLENDOP_ADD);
	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
	m_pDev->SetRenderState( D3DRS_STENCILENABLE, FALSE);
}




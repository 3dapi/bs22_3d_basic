// Interface for the CMain class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MAIN_H_
#define _MAIN_H_


class CMain : public CD3DApplication
{
protected:
	ID3DXFont*		m_pD3DXFont;            // D3DX font    
	CMcScene*		m_pScene;
	
public:
	CMain();
	
	virtual HRESULT OneTimeSceneInit();
	virtual HRESULT Init();
	virtual HRESULT Restore();
	virtual HRESULT Invalidate();
	virtual HRESULT Destroy();
	virtual HRESULT Render();
	virtual HRESULT FrameMove();
	virtual HRESULT FinalCleanup();
	virtual HRESULT ConfirmDevice( D3DCAPS9*, DWORD, D3DFORMAT );
	
	HRESULT RenderText();
	LRESULT MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam );
};

extern CMain*	g_pApp;


#endif

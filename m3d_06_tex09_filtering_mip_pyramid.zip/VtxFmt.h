#ifndef _VTXFMT_H_
#define _VTXFMT_H_


struct VtxRHWUV1
{
	D3DXVECTOR3	p;
	FLOAT	w;
	FLOAT	u, v;
	
	VtxRHWUV1()						: p(0,0,0),u(0),v(0), w(1){}
	VtxRHWUV1(	FLOAT X,FLOAT Y,FLOAT Z
			,	FLOAT U, FLOAT V)		: p(X,Y,Z),u(U),v(V), w(1){}

	enum { FVF = (D3DFVF_XYZRHW|D3DFVF_TEX1)};
};


#endif


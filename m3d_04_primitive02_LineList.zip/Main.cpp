// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


#define SAFE_DELETE(p)       { if(p) { delete (p);     (p)=NULL; } }
#define SAFE_DELETE_ARRAY(p) { if(p) { delete[] (p);   (p)=NULL; } }
#define SAFE_RELEASE(p)      { if(p) { (p)->Release(); (p)=NULL; } }


CMain::CMain()
{
	strcpy(m_sCls, "Mck_D3D");

	m_hInst			= NULL;
	m_hWnd			= NULL;
	m_pD3D			= NULL;
	m_pd3dDevice	= NULL;

	m_dWinStyle		= WS_OVERLAPPED | WS_CAPTION |WS_SYSMENU|WS_VISIBLE;
	m_dScnX			= 800;
	m_dScnY			= 600;


	m_pVB			= NULL;
}


CMain::~CMain()
{
}


INT CMain::Init()
{
	::SetWindowText(m_hWnd, "Primitive Line List");

	m_dwSizeVertices = sizeof(VtxD) * 6;

	// Create the vertex buffer
	if( FAILED( m_pd3dDevice->CreateVertexBuffer(
		m_dwSizeVertices
		, 0, VtxD::FVF, D3DPOOL_MANAGED, &m_pVB, 0 ) ) )
		return E_FAIL;


	// Initialize to render a quad
	VtxD pVtx[6];

	pVtx[0] = VtxD(-1500.f,    0.f,    0.f, 0xFFFF0000 );
	pVtx[1] = VtxD( 1500.f,    0.f,    0.f, 0xFFFF0000 );

	pVtx[2] = VtxD(   0.f, -1500.f,    0.f, 0xFF00FF00 );
	pVtx[3] = VtxD(   0.f,  1500.f,    0.f, 0xFF00FF00 );

	pVtx[4] = VtxD(   0.f,    0.f, -1500.f, 0xFF00FFFF );
	pVtx[5] = VtxD(   0.f,    0.f,  1500.f, 0xFF00FFFF );


	VtxD* pVertices;


	if( FAILED( m_pVB->Lock( 0, 0, (void**)&pVertices, 0 ) ) )
		return E_FAIL;

	memcpy( pVertices, pVtx, m_dwSizeVertices);

	m_pVB->Unlock();

	return 0;
}

void CMain::Destroy()
{
	SAFE_RELEASE( m_pVB );
}


INT CMain::FrameMove()
{
	D3DXMATRIX  matWorld;
	D3DXMatrixIdentity( &matWorld );
	m_pd3dDevice->SetTransform( D3DTS_WORLD,      &matWorld );

	// �� ��� �����
	D3DXMATRIX m_mtViw;
	D3DXVECTOR3 vEyePt    = D3DXVECTOR3( 10.f, 10.f, -200.f );
	D3DXVECTOR3 vLookAt = D3DXVECTOR3( 0.f, 0.f, 0.f );
	D3DXVECTOR3 vUpVec    = D3DXVECTOR3( 0.f, 1.f, 0.f );

	D3DXMatrixLookAtLH(&m_mtViw, &vEyePt, &vLookAt, &vUpVec );
	m_pd3dDevice->SetTransform( D3DTS_VIEW,       &m_mtViw );

	// ���� ��� �����
	D3DXMATRIX m_mtPrj;
	FLOAT	fScreenW = (FLOAT)this->m_dScnX;
	FLOAT	fScreenH = (FLOAT)this->m_dScnY;
	FLOAT	fFOV	= D3DX_PI/4.0f;
	FLOAT	fAspect	= fScreenW/fScreenH;
	FLOAT	fNear	= 1.f;
	FLOAT	fFar	= 5000.f;
	
	D3DXMatrixPerspectiveFovLH(&m_mtPrj, fFOV, fAspect, fNear, fFar);
	m_pd3dDevice->SetTransform( D3DTS_PROJECTION, &m_mtPrj );

	return 0;
}


INT CMain::Render()
{
	if( NULL == m_pd3dDevice )
		return -1;

	if( FAILED( m_pd3dDevice->BeginScene() ) )
		return -1;

	m_pd3dDevice->Clear( 0, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, 0xFF006699, 1.f, 0 );



	m_pd3dDevice->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);					// ���� ���� ��� ����
	m_pd3dDevice->SetRenderState(D3DRS_LIGHTING, FALSE);						// ���� ��� ����

	m_pd3dDevice->SetTexture( 0, NULL);											// �ؽ�ó ��� ����
	m_pd3dDevice->SetStreamSource( 0, m_pVB, 0, sizeof(VtxD) );

	m_pd3dDevice->SetFVF( VtxD::FVF );
	m_pd3dDevice->DrawPrimitive( D3DPT_LINELIST, 0, 3);



	// End the scene
	m_pd3dDevice->EndScene();

	m_pd3dDevice->Present( NULL, NULL, NULL, NULL );							// ���������� �ĸ���۸� ������۷� ��ü�Ѵ�.( flipping)

return 0;
}
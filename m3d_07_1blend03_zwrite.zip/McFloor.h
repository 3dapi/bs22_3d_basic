// Interface for the CMcFloor class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _MCFLOOR_H_
#define _MCFLOOR_H_

class CMcFloor
{
public:
	LPDIRECT3DDEVICE9	m_pDev;
	LPDIRECT3DTEXTURE9	m_pTex;

public:
	CMcFloor();
	~CMcFloor();
	
	INT		Create(LPDIRECT3DDEVICE9 pDev);
	void	Destroy();

	INT		FrameMove();
	void	Render();

};

#endif

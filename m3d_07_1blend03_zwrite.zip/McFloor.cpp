// McScene.cpp: implementation of the CMcFloor class.
//
//////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMcFloor::CMcFloor()
{
	m_pDev	= NULL;
	m_pTex	= NULL;
}

CMcFloor::~CMcFloor()
{
	Destroy();	
}



INT CMcFloor::Create(LPDIRECT3DDEVICE9 pDev)
{
	m_pDev = pDev;

	int i=0;
	
	if( FAILED( D3DXCreateTextureFromFile(m_pDev, "Texture/seafloor.bmp", &m_pTex)) )
		return -1;

	return 0;
}


void CMcFloor::Destroy()
{
	SAFE_RELEASE(	m_pTex		);
}

INT CMcFloor::FrameMove()
{
	return 0;
}

void	CMcFloor::Render()
{
	m_pDev->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE );
	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_MODULATE );
	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
	
	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_MIRROR);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_MIRROR);
	
	VtxDUV1		pVtxDUV1[4];

	pVtxDUV1[0] = VtxDUV1(-1000, 0, -1000,  0,  8); 
	pVtxDUV1[1] = VtxDUV1(-1000, 0,  1000,  0,  0);
	pVtxDUV1[2] = VtxDUV1( 1000, 0, -1000,  8,  8);
	pVtxDUV1[3] = VtxDUV1( 1000, 0,  1000,  8,  0);

	m_pDev->SetRenderState( D3DRS_ALPHABLENDENABLE, FALSE);
	m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
	m_pDev->SetTexture(0, m_pTex);
	m_pDev->SetFVF(VtxDUV1::FVF);
	m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, pVtxDUV1, sizeof(VtxDUV1));

	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);
}



#include "_StdAfx.h"


CMain::CMain()
:	m_pD3DXFont		(0)
,	m_pInput	(0)
,	m_pCam		(0)
,	m_pFloor	(0)
,	m_pScene	(0)
{
}


HRESULT CMain::Init()
{
	SAFE_NEWCREATE1(	m_pInput	, CMcInput	, m_pd3dDevice	);
	SAFE_NEWCREATE1(	m_pCam		, CMcCam	, m_pd3dDevice	);
	SAFE_NEWCREATE1(	m_pFloor	, CMcFloor	, m_pd3dDevice	);

	SAFE_NEWCREATE1(	m_pScene	, CMcScene	, m_pd3dDevice	);

	
	D3DXFONT_DESC hFont =
	{
		14, 0
		, FW_NORMAL, 1, FALSE
		, HANGUL_CHARSET
		, OUT_DEFAULT_PRECIS, ANTIALIASED_QUALITY, FF_DONTCARE
		, "Arial"
	};

	if( FAILED( D3DXCreateFontIndirect(m_pd3dDevice, &hFont, &m_pD3DXFont) ) )
		return -1;


	return S_OK;
}


HRESULT CMain::Destroy()
{
	SAFE_RELEASE( m_pD3DXFont );

	SAFE_DELETE(	m_pInput	);
	SAFE_DELETE(	m_pCam		);
	SAFE_DELETE(	m_pFloor	);

	SAFE_DELETE(	m_pScene	);

	return S_OK;
}



HRESULT CMain::Restore()
{
	if(m_pD3DXFont)
		m_pD3DXFont->OnResetDevice();	
	
	return S_OK;
}


HRESULT CMain::Invalidate()
{
	if(m_pD3DXFont)
		m_pD3DXFont->OnLostDevice();

	return S_OK;
}




HRESULT CMain::FrameMove()
{
	SAFE_FRMOV(	m_pInput	);


	D3DXVECTOR3 vcDelta = m_pInput->GetMouseDelta();

	if(vcDelta.z !=0.f)
		m_pCam->MoveForward(-vcDelta.z* 1.f, 1.f);

	if(m_pInput->KeyState(DIK_W))					// W
		m_pCam->MoveForward( 1.f, 1.f);

	if(m_pInput->KeyState(DIK_S))					// S
		m_pCam->MoveForward(-1.f, 1.f);


	if(m_pInput->KeyState(DIK_A))					// A
		m_pCam->MoveSideward(-1.f);
		

	if(m_pInput->KeyState(DIK_D))					// D
		m_pCam->MoveSideward(1.f);

	if(m_pInput->GetMouseSt(1))
		m_pCam->Rotate(vcDelta.x, vcDelta.y);


	SAFE_FRMOV(	m_pCam		);
	SAFE_FRMOV(	m_pFloor	);

	SAFE_FRMOV(	m_pScene	);

	sprintf( m_sMsg, "%s %s", m_strDeviceStats, m_strFrameStats	);

	return S_OK;
}


HRESULT CMain::Render()
{
	m_pd3dDevice->Clear( 0L, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER|D3DCLEAR_STENCIL, 0x00006699, 1.0f, 0L );
		
	if( FAILED( m_pd3dDevice->BeginScene() ) )
		return -1;

	m_pCam->SetTransForm();

	SAFE_RENDER(	m_pFloor	);
	SAFE_RENDER(	m_pScene	);
	
	m_pd3dDevice->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
	m_pd3dDevice->SetRenderState(D3DRS_FOGENABLE, FALSE);
	m_pd3dDevice->SetRenderState(D3DRS_LIGHTING, FALSE);
	
	RECT rc={2, 10, m_d3dsdBackBuffer.Width - 20, 30 };
	m_pD3DXFont->DrawText(NULL, m_sMsg, -1, &rc, 0, D3DCOLOR_ARGB(255,255,255,0));

	
	m_pd3dDevice->EndScene();
	
	return S_OK;
}



LRESULT CMain::MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
	switch( msg )
	{
	case WM_PAINT:
		{
			break;
		}
		
	}
	
	return CD3DApplication::MsgProc( hWnd, msg, wParam, lParam );
}

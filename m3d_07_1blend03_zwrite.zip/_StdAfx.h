#ifndef __STDAFX_H_
#define __STDAFX_H_

#pragma once
#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "comctl32.lib")

#define STRICT
#define STRICT
#define	WIN32_LEAN_AND_MEAN
#define DIRECTINPUT_VERSION 0x0800


#pragma warning( disable : 4018)
#pragma warning( disable : 4100)
#pragma warning( disable : 4245)
#pragma warning( disable : 4503)
#pragma warning( disable : 4663)
#pragma warning( disable : 4786)

#include <vector>
#include <set>
#include <map>
#include <algorithm>
#include <functional>
#include <string>

using namespace std;



#include <windows.h>
#include <windowsx.h>
#include <basetsd.h>
#include <commctrl.h>
#include <commdlg.h>

#include <math.h>
#include <mmsystem.h>
#include <stdio.h>
#include <tchar.h>


#include <D3D9.h>
#include <d3dx9.h>
#include <dinput.h>

#include "DXUtil.h"
#include "D3DUtil.h"
#include "D3DEnum.h"
#include "D3DSettings.h"

#include "resource.h"
#include "D3DApp.h"


#include "McVtxFmt.h"
#include "McUtil.h"



#include "McInput.h"
#include "McCam.h"
#include "McFloor.h"





#include "McScene.h"

#include "Main.h"

#endif
// McScene.cpp: implementation of the CMcScene class.
//
//////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMcScene::CMcScene()
{
	m_pDev = NULL;
}

CMcScene::~CMcScene()
{
	Destroy();	
}



INT	CMcScene::Create(LPDIRECT3DDEVICE9 pDev)
{
	m_pDev = pDev;

	int i=0;
	
	m_pVtx1[8] = VtxD( 0.f, -200.f,  0.f, 0x00000000);
	m_pVtx2[8] = VtxD( 0.f, -200.f,  0.f, 0x00000000);

	for(i=0; i<8; ++i)
	{
		m_pVtx1[i].p = D3DXVECTOR3( 300.f * cosf(D3DXToRadian(360.f * i / 8)), 180.f * 1.f + 50.f, 300.f * sinf(D3DXToRadian(360.f * i / 8) ) );
		m_pVtx1[i].d = D3DXCOLOR( rand()%6 * 0.1f, rand()%6 * 0.1f, rand()%6 * 0.1f, 1.f);

		m_pVtx2[i].p = D3DXVECTOR3( 400.f * cosf(D3DXToRadian(360.f * i / 8)), 120.f * 1.f + 50.f, 400.f * sinf(D3DXToRadian(360.f * i / 8) ) );
		m_pVtx2[i].d = D3DXCOLOR( rand()%6 * 0.1f, rand()%6 * 0.1f, rand()%6 * 0.1f, 1.f);
	}
	
	
	for(i=0; i<8; ++i)
	{
		m_pIdx[i] = VtxIdx(8, (i+1)%8, (i+2)%8 );
	}

	return 0;
}


void CMcScene::Destroy()
{
}

INT CMcScene::FrameMove()
{
	return 0;
}

void CMcScene::Render()
{
	m_pDev->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE );
	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_MODULATE );
	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
	
	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);
	

	
	m_pDev->SetRenderState( D3DRS_ALPHABLENDENABLE, TRUE );
	m_pDev->SetRenderState( D3DRS_SRCBLEND,  D3DBLEND_SRCALPHA );
	m_pDev->SetRenderState( D3DRS_DESTBLEND, D3DBLEND_DESTALPHA );

	m_pDev->SetTexture(0, 0);
	m_pDev->SetFVF(VtxD::FVF);

//	m_pDev->SetRenderState( D3DRS_ZENABLE,  FALSE);
	m_pDev->SetRenderState( D3DRS_ZWRITEENABLE,  FALSE);
	m_pDev->DrawIndexedPrimitiveUP(D3DPT_TRIANGLELIST, 0, 8+1, 8, m_pIdx, D3DFMT_INDEX16, m_pVtx1, sizeof(VtxD));

//	m_pDev->SetRenderState( D3DRS_ZWRITEENABLE,  FALSE);
	m_pDev->DrawIndexedPrimitiveUP(D3DPT_TRIANGLELIST, 0, 8+1, 8, m_pIdx, D3DFMT_INDEX16, m_pVtx2, sizeof(VtxD));

	

	m_pDev->SetRenderState( D3DRS_ZWRITEENABLE,  TRUE);
}

// Interface for the CMcScene class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _MCSCENE_H_
#define _MCSCENE_H_

class CMcScene
{
public:
	LPDIRECT3DDEVICE9	m_pDev;
	
	VtxD	m_pVtx1[8+1];
	VtxD	m_pVtx2[8+1];

	VtxIdx	m_pIdx[8];

public:
	CMcScene();
	~CMcScene();
	
	INT		Create(LPDIRECT3DDEVICE9	pDev);
	void	Destroy();

	INT		FrameMove();
	void	Render();

};

#endif

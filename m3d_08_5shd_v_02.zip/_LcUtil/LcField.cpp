// Implementation of the CLcField class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <stdio.h>
#include <d3d9.h>
#include <d3dx9.h>

#include "LcField.h"

#define SAFE_DELETE(p)       { if(p) { delete (p);     (p)=NULL; } }
#define SAFE_DELETE_ARRAY(p) { if(p) { delete[] (p);   (p)=NULL; } }
#define SAFE_RELEASE(p)      { if(p) { (p)->Release(); (p)=NULL; } }


CLcField::CLcField()
{
}


CLcField::~CLcField()
{
	Destroy();
}


INT CLcField::Create(LPDIRECT3DDEVICE9 pDev)
{
	m_pDev	= pDev;

	FLOAT	fW = 150;

	m_pVtx[0] = VtxD(-fW, 0, -fW);
	m_pVtx[1] = VtxD(-fW, 0,  fW);
	m_pVtx[2] = VtxD( fW, 0,  fW);
	m_pVtx[3] = VtxD( fW, 0, -fW);

	return 0;
}


void CLcField::Destroy()
{
}


INT	CLcField::FrameMove()
{
	return 0;
}

void CLcField::Render()
{
	m_pDev->SetRenderState( D3DRS_CULLMODE,  D3DCULL_CCW);
	m_pDev->SetRenderState( D3DRS_ALPHABLENDENABLE,  FALSE);
	m_pDev->SetRenderState( D3DRS_ALPHATESTENABLE,  FALSE);

	m_pDev->SetTexture(0, NULL);
	m_pDev->SetFVF(VtxD::FVF);

	m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLEFAN, 2, m_pVtx, sizeof(VtxD));
}


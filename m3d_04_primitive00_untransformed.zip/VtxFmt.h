

#ifndef _VTXFMT_H_
#define _VTXFMT_H_


struct VtxD
{
	D3DXVECTOR3	p;				// The untransformed position
	DWORD		d;				// The vertex color

	VtxD()	{}
	VtxD(FLOAT X, FLOAT Y, FLOAT Z, DWORD D=0xFFFFFFFF)
		:p(X, Y, Z), d(D){}

	enum{ FVF= (D3DFVF_XYZ| D3DFVF_DIFFUSE), };
};


#endif



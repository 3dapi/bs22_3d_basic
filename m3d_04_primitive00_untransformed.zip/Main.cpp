// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMain::CMain()
{
	strcpy(m_sCls, "Mck_D3D");

	m_hInst			= NULL;
	m_hWnd			= NULL;
	m_pD3D			= NULL;
	m_pd3dDevice	= NULL;

	m_dWinStyle		= WS_OVERLAPPED | WS_CAPTION |WS_SYSMENU|WS_VISIBLE;
	m_dScnX			= 800;
	m_dScnY			= 600;
}


CMain::~CMain()
{
}


INT CMain::Init()
{
	::SetWindowText(m_hWnd, "Primitive Base-Untransformed Vertex Data");


	m_dwSizeofVertices = sizeof(VtxD) * 4;

	// Create Vertex Buffer
	HRESULT hr;
	hr = m_pd3dDevice->CreateVertexBuffer( m_dwSizeofVertices,
				0, VtxD::FVF,
				D3DPOOL_MANAGED, &m_pVB, 0 );

	if(FAILED( hr ))
		return hr;


	VtxD pVtxSrc[4];
	pVtxSrc[0] = VtxD( -1.f, +1.f, 0.f, 0xffff0000 );
	pVtxSrc[1] = VtxD( +1.f, +1.f, 0.f, 0xff00ff00 );
	pVtxSrc[2] = VtxD( +1.f, -1.f, 0.f, 0xff0000ff );
	pVtxSrc[3] = VtxD( -1.f, -1.f, 0.f, 0xffff00ff );


	VtxD* pVertices;

	if( FAILED( m_pVB->Lock( 0, m_dwSizeofVertices, (void**)&pVertices, 0 ) ) )
		return -1;

	memcpy( pVertices, pVtxSrc, m_dwSizeofVertices);
	m_pVB->Unlock();


	// ���ؽ� ������ ������ ��´�.
//	D3DVERTEXBUFFER_DESC desc;
//	m_pVB->GetDesc(&desc);

	return 0;
}

void CMain::Destroy()
{
	if( m_pVB )
	{
		m_pVB->Release();
		m_pVB = NULL;
	}
}


INT CMain::FrameMove()
{
	return 0;
}


INT CMain::Render()
{
	if( NULL == m_pd3dDevice )
		return -1;

	if( FAILED( m_pd3dDevice->BeginScene() ) )
		return -1;


	m_pd3dDevice->Clear( 0, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, 0xFF006699, 1.f, 0 );



	D3DXMATRIX	mtTM;
	D3DXMatrixIdentity(&mtTM);

	m_pd3dDevice->SetTransform(D3DTS_WORLD, &mtTM);
	m_pd3dDevice->SetTransform(D3DTS_VIEW , &mtTM);
	m_pd3dDevice->SetTransform(D3DTS_PROJECTION, &mtTM);


	m_pd3dDevice->SetRenderState(D3DRS_LIGHTING, FALSE);

	m_pd3dDevice->SetStreamSource( 0, m_pVB, 0, sizeof(VtxD) );
	m_pd3dDevice->SetFVF( VtxD::FVF );
	m_pd3dDevice->DrawPrimitive( D3DPT_TRIANGLEFAN, 0, 2 );

	
	// End the scene
	m_pd3dDevice->EndScene();


	m_pd3dDevice->Present( NULL, NULL, NULL, NULL );							// ���������� �ĸ���۸� ������۷� ��ü�Ѵ�.( flipping)

	return 0;
}
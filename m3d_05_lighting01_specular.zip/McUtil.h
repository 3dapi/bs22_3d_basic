#ifndef _MCUTIL_H_
#define _MCUTIL_H_


#define SAFE_DESTROY(p)		{	if(p)	(p)->Destroy();					}
#define SAFE_INVALIDATE(p)	{	if(p)	(p)->Invalidate();				}
#define SAFE_RESTORE(p)		{	if(p)	(p)->Restore();	}

#define SAFE_FRAMEMOVE(p)	{	if(p)	(p)->FrameMove();				}
#define SAFE_RENDER(p)		{	if(p)	(p)->Render();					}


#endif



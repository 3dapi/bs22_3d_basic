#pragma warning(disable: 4324)
#pragma warning(disable: 4996)


#ifndef __STDAFX_H_
#define __STDAFX_H_


#define _WIN32_WINNT 0x0400

#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include <d3dx9.h>
#include <mmsystem.h>


#include "McInput.h"															// Input class






#include "Main.h"

#endif
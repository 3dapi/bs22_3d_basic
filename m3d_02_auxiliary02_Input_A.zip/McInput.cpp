// Implementation of the CMcInput class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMcInput::CMcInput()
{
	
}

CMcInput::~CMcInput()
{
	
}


INT CMcInput::Init()
{
	memset(KeyCur, 0, sizeof(KeyCur));
	memset(KeyOld, 0, sizeof(KeyOld));

	memset(&MsPosCur, 0, sizeof (MsPosCur));
	memset(&MsPosOld, 0, sizeof(MsPosOld));
	memset(&MsStCur, 0, sizeof(MsStCur));
	memset(&MsStOld, 0, sizeof(MsStOld));
	
	return 0;
}

INT CMcInput::FrameMove()
{
	memcpy(KeyOld	,	KeyCur,		sizeof(KeyCur)		);
	memcpy(&MsPosOld,	&MsPosCur,	sizeof(MsPosCur)	);
	memcpy(&MsStOld	,	&MsStCur,	sizeof(MsStCur)		);
	
	memset(&MsStCur, 0  ,	sizeof(MsStCur));

	::GetKeyboardState(KeyCur);
	
	POINT mouse;
	::GetCursorPos(&mouse);
	::ScreenToClient(g_pApp->m_hWnd, &mouse );

	MsPosCur.x = FLOAT(mouse.x);
	MsPosCur.y = FLOAT(mouse.y);
	
	return 0;
}


BOOL CMcInput::GetKey(INT cKey)
{
	return (KeyCur[cKey] & 0x80 && KeyOld[cKey] != KeyCur[cKey]);
}

BOOL CMcInput::KeyState(INT cKey)
{
	return (KeyCur[cKey] & 0x80);
}



void CMcInput::AddWheelMousePos(INT	d)
{
	MsPosCur.z += FLOAT(d);
}

BOOL CMcInput::GetMouseSt(INT nBtn)
{
	return MsStOld.m[nBtn];
}

void CMcInput::SetMouseSt(INT nBtn, BOOL bSt)
{
	MsStCur.m[nBtn]  = bSt;
}


D3DXVECTOR3	CMcInput::GetMousePos()
{
	return MsPosCur;
}
// Interface for the CMain class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MAIN_H_
#define _MAIN_H_


class CMain
{
public:
	TCHAR			m_sCls[128]		;
	HINSTANCE		m_hInst			;
	HWND			m_hWnd			;
	HDC				m_hDC			;
	TCHAR			m_sTitle[128]	;
	
public:
	CMcInput*		m_pInput		;
	

public:
	CMain();

	INT		Init();
	void	Destroy();

	INT		FrameMove();
	INT		Render();

	INT		Create( HINSTANCE);
	void	Cleanup();

	INT		Run();
	LRESULT MsgProc( HWND,UINT,WPARAM,LPARAM);
};

extern CMain*	g_pApp;

#endif

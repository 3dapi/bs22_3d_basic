// Interface for the CMcInput class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MCINPUT_H_
#define _MCINPUT_H_


class CMcInput
{
public:
	enum{
		MAX_INPUT_KEY =	256,
		MAX_INPUT_BTN =	8,
	};

	struct MouseState																// Mouse State
	{
		union
		{
			struct
			{
				BYTE	bBtnDnL;													// 0 Left Button Down
				BYTE	bBtnUpL;													// 1 Left Button Up
				BYTE	bBtnDcL;													// 2 Left Button Doublic Click

				BYTE	bBtnDnR;													// 3 Right Button Down
				BYTE	bBtnUpR;													// 4 Right Button Up
				BYTE	bBtnDcR;													// 5 Right Button Doublic Click

				BYTE	bBtnDnM;													// 6 Wheel Button Down
				BYTE	bBtnUpM;													// 7 Wheel Button Up
				BYTE	bBtnDcM;													// 8 Wheel Button Doublic
			};

			BYTE m[9];
		};

		operator BYTE*()		{	return (BYTE *) &bBtnDnL;				}
	};


protected:
	BYTE			KeyCur[MAX_INPUT_KEY];
	BYTE			KeyOld[MAX_INPUT_KEY];
	
	D3DXVECTOR3		MsPosCur;													// Z is Wheel Mouse
	D3DXVECTOR3		MsPosOld;
	MouseState		MsStCur;
	MouseState		MsStOld;

public:
	CMcInput();
	virtual ~CMcInput();

	INT			Init();
	INT			FrameMove();

	BOOL		GetKey(INT cKey);
	BOOL		KeyState(INT cKey);

	D3DXVECTOR3	GetMousePos();
	BOOL		GetMouseSt(INT nM);
	void		AddWheelMousePos(INT d);
	void		SetMouseSt(INT nBtn, BOOL bSt);
};

#endif

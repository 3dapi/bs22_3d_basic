// Interface for the CMcScene class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _MCSCENE_H_
#define _MCSCENE_H_

class CMcScene
{
public:
	LPDIRECT3DTEXTURE9	m_pTxUi;

public:
	CMcScene();
	~CMcScene();
	
	INT		Init();
	void	Destroy();

	INT		FrameMove();
	void	Render();

};

#endif

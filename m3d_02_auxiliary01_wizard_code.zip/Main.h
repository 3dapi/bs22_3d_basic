// Interface for the CMain class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MAIN_H_
#define _MAIN_H_


class CMain : public CD3DApplication
{
public:
	HFONT			m_hFont;
	ID3DXFont*		m_pD3DXFont;            // D3DX font    
	CMcScene*		m_pScene;

	HDC				m_hDC;					// For DC Test..
	HBITMAP			m_BitMap;
	HDC				m_MemDC;
	
public:
	virtual HRESULT Init();
	virtual HRESULT Destroy();

	virtual HRESULT Restore();
	virtual HRESULT Invalidate();
	
	virtual HRESULT Render();
	virtual HRESULT FrameMove();
	
	HRESULT RenderText();
	
public:
	LRESULT MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam );
	CMain();
};

extern CMain*	g_pApp;

#endif
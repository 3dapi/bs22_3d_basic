#ifndef _VTXFMT_H_
#define _VTXFMT_H_

struct VtxN
{
    D3DXVECTOR3	p;																	// vertex position
    D3DXVECTOR3	n;																	// diffuse

	VtxN(){}
	VtxN(D3DXVECTOR3 P,D3DXVECTOR3 N)			{	p=P; n=N;		}
};

#define FVF_VTXN		(D3DFVF_XYZ|D3DFVF_NORMAL)


#endif
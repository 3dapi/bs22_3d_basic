

#include "_StdAfx.h"


CMain::CMain()
{
	m_pD3DXFont		= NULL;
	m_pScene		= NULL;	
}


HRESULT CMain::Init()
{
	if(NULL == m_pScene)
	{
		m_pScene = new CMcScene;
		m_pScene->Init();
	}


	if( FAILED( D3DXCreateFont( GDEVICE, 16, 0, FW_BOLD, 1, 0, HANGUL_CHARSET, OUT_DEFAULT_PRECIS, ANTIALIASED_QUALITY, FF_DONTCARE, "Arial", &m_pD3DXFont ) ) )
		return -1;


	m_BitMap = (HBITMAP)LoadImage(m_hInst, "Texture/img1.bmp", IMAGE_BITMAP, 0, 0, LR_DEFAULTCOLOR|LR_LOADFROMFILE);

	return S_OK;
}


HRESULT CMain::Destroy()
{
	DeleteObject(m_hFont);
	DeleteObject(m_BitMap);
	SAFE_RELEASE( m_pD3DXFont );
	SAFE_DELETE(	m_pScene	);
	return S_OK;
}



HRESULT CMain::Restore()
{
	if(m_pD3DXFont)
		m_pD3DXFont->OnResetDevice();	
	
	return S_OK;
}


HRESULT CMain::Invalidate()
{
	if(m_pD3DXFont)
		m_pD3DXFont->OnLostDevice();

	return S_OK;
}




HRESULT CMain::FrameMove()
{
	if(m_pScene)
		m_pScene->FrameMove();

	return S_OK;
}


HRESULT CMain::Render()
{
	m_pd3dDevice->Clear( 0L, 0, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER|D3DCLEAR_STENCIL, 0x00006699, 1.0f, 0L );
	
	if( FAILED( m_pd3dDevice->BeginScene() ) )
		return -1;

	if(m_pScene)
		m_pScene->Render();

	RenderText();
		
	m_pd3dDevice->EndScene();

	
	if(m_pd3dSf)
	{
		m_pd3dSf->GetDC(&m_hDC);

		if(m_hDC)
		{
			m_MemDC = ::CreateCompatibleDC(m_hDC);
			SelectObject(m_MemDC, m_BitMap);

			BitBlt(m_hDC, 0, 30, 800, 700, m_MemDC, 0, 0, SRCCOPY);

			DeleteDC(m_MemDC);

			SetBkMode(m_hDC, TRANSPARENT);
			SelectObject(m_hDC, m_hFont);
			SetTextColor(m_hDC, RGB(0,255, 255));
			TextOut(m_hDC, 100, 100, "�� �̱׸��� �� ������ DC�� ������ �׸� ��", strlen("�� �̱׸��� �� ������ DC�� ������ �׸� ��"));


			TextOut(m_hDC, 100, 500, "�� �̱׸��� ��������Ʈ�� �׸� ��", strlen("�� �̱׸��� ��������Ʈ�� �׸� ��"));
			
			m_pd3dSf->ReleaseDC(m_hDC);
		}
	}

	
	return S_OK;
}



HRESULT CMain::RenderText()
{
	TCHAR szMsg[MAX_PATH] = {0};
	RECT rc;
	
	rc.left   = 2;
	rc.right  = m_d3dsdBackBuffer.Width - 20;
	rc.top = 3;
	rc.bottom = rc.top + 20;
	
	sprintf( szMsg, "%s %s", m_strDeviceStats, m_strFrameStats);

	m_pD3DXFont->DrawText(NULL, szMsg, -1, &rc, 0, D3DCOLOR_ARGB(255,255,255,0) );
	
	return S_OK;
}



LRESULT CMain::MsgProc( HWND hWnd, UINT msg, WPARAM wParam,
					   LPARAM lParam )
{
	switch( msg )
	{
	case WM_PAINT:
		{
			if( m_bLoadingApp )
			{
				HDC m_hDC = GetDC( hWnd );
				TCHAR strMsg[MAX_PATH];
				wsprintf( strMsg, TEXT("Loading... Please wait") );
				RECT rc;
				GetClientRect( hWnd, &rc );
				DrawText( m_hDC, strMsg, -1, &rc, DT_CENTER|DT_VCENTER|DT_SINGLELINE );
				ReleaseDC( hWnd, m_hDC );
			}
			break;
		}
		
	}
	
	return CD3DApplication::MsgProc( hWnd, msg, wParam, lParam );
}
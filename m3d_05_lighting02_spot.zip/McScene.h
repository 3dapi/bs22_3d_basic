// Interface for the CMcScene class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _McScene_H_
#define _McScene_H_


// for Object Rendering
class CMcObject
{
protected:
	LPD3DXMESH		m_pMsh;		// �޽�
	D3DMATERIAL9	m_Mtrl;		// ����

	D3DXMATRIX		m_mtWld;	// ���� ���

public:
	CMcObject();
	virtual ~CMcObject();

	void	SetMesh(LPD3DXMESH pMesh);
	void	SetMaterial(const D3DMATERIAL9* pMtrl);
	void	SetWorld(const D3DXMATRIX* mtWld);

	void	Render(LPDIRECT3DDEVICE9 pDev);
};


class CMcScene
{
public:
	LPDIRECT3DDEVICE9	m_pDev;
	

	CMcObject*	m_pObj;

	D3DXMATRIX m_mtViw;
	D3DXMATRIX m_mtPrj;

public:
	CMcScene();
	virtual ~CMcScene();

	INT		Create(LPDIRECT3DDEVICE9 pDev);
	void	Destroy();

	INT		FrameMove();
	void	Render();
};

#endif
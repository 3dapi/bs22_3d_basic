// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMain::CMain()
{
	m_pD3DXFont	= NULL;
	m_pd3dLine	= NULL;
}


HRESULT CMain::Init()
{
	if( FAILED( D3DXCreateFont( GDEVICE, 16, 0, FW_BOLD, 1, 0, HANGUL_CHARSET, OUT_DEFAULT_PRECIS, ANTIALIASED_QUALITY, FF_DONTCARE, "Arial", &m_pD3DXFont ) ) )
		return -1;


	D3DXCreateLine(m_pd3dDevice,&m_pd3dLine);

	return S_OK;
}


HRESULT CMain::Destroy()
{
	SAFE_RELEASE( m_pD3DXFont	);
	SAFE_RELEASE(	m_pd3dLine	);
	
	return S_OK;
}


HRESULT CMain::Restore()
{
	m_pD3DXFont->OnResetDevice();
	m_pd3dLine->OnResetDevice();

	return S_OK;
}


HRESULT CMain::Invalidate()
{
	m_pD3DXFont->OnLostDevice();
	m_pd3dLine->OnLostDevice();

	return S_OK;
}


HRESULT CMain::FrameMove()
{
	return S_OK;
}


HRESULT CMain::Render()
{
	MATA	mtW;
	D3DXMatrixIdentity(&mtW);
	GDEVICE->SetTransform(D3DTS_WORLD, &mtW);


	m_pd3dDevice->Clear( 0L, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER|D3DCLEAR_STENCIL, 0xFF006699, 1.0f, 0L);

	if( FAILED( m_pd3dDevice->BeginScene() ) )
		return -1;

	GDEVICE->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
	GDEVICE->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);

	RenderText();


	VEC2 Line[2];
	Line[0] =VEC2(   0, 300);
	Line[1] =VEC2(1000, 300);

	m_pd3dLine->Begin();

//	m_pd3dLine->Draw(Line, 2, 0xFF00FF00);
//	Line[0] =VEC2( 400,   0);
//	Line[1] =VEC2( 400, 700);
//	m_pd3dLine->Draw(Line, 2, 0xFFFF0000);

	for(INT i=0; i<840; ++i)
	{
		Line[0] =VEC2( i+0.f, 300 - 100*sinf(D3DXToRadian(i+0) * 8)  *sinf(D3DXToRadian(i+0) * 0.5f));
		Line[1] =VEC2( i+1.f, 300 - 100*sinf(D3DXToRadian(i+1) * 8)  *sinf(D3DXToRadian(i+0) * 0.5f));
		m_pd3dLine->Draw(Line, 2, 0xff00ffff);

		Line[0] =VEC2( 400 + 0.8f*(i+0) *cosf(2*D3DXToRadian(i+0)), 300 - 0.8f*(i+0) *sinf(2*D3DXToRadian(i+0)));
		Line[1] =VEC2( 400 + 0.8f*(i+1) *cosf(2*D3DXToRadian(i+1)), 300 - 0.8f*(i+1) *sinf(2*D3DXToRadian(i+1)));
		m_pd3dLine->Draw(Line, 2, 0xff00ff00);
	}

	m_pd3dLine->End();




	m_pd3dDevice->EndScene();

	return S_OK;
}


HRESULT CMain::RenderText()
{
	m_pd3dDevice->SetRenderState(D3DRS_LIGHTING, FALSE);
	m_pd3dDevice->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
	m_pd3dDevice->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);
	m_pd3dDevice->SetTexture( 0, 0);

	CHAR szMsg[MAX_PATH];
	RECT rc;
	rc.left   = 2;
	rc.right  = m_d3dsdBackBuffer.Width - 20;
	rc.top = 3;
	rc.bottom = rc.top + 20;

	sprintf(szMsg, "%s %s",m_strDeviceStats, m_strFrameStats );


	m_pD3DXFont->DrawText(NULL, szMsg, -1, &rc, 0, D3DXCOLOR(1,1,0,1) );


	return S_OK;
}

LRESULT CMain::MsgProc( HWND hWnd, UINT msg, WPARAM wParam,LPARAM lParam)
{
	WPARAM	wparHi;
	WPARAM	wparLo;

	wparHi = HIWORD(wParam);
	wparLo = LOWORD(wParam);

	switch( msg )
	{
		case WM_PAINT:
		{
			if( m_bLoadingApp )
			{
				HDC hDC = GetDC( hWnd );
				CHAR strMsg[MAX_PATH];
				RECT rc;
				wsprintf( strMsg, TEXT("Loading... Please wait") );
				GetClientRect( hWnd, &rc );
				DrawText( hDC, strMsg, -1, &rc, DT_CENTER|DT_VCENTER|DT_SINGLELINE );
				ReleaseDC( hWnd, hDC );
			}
			break;
		}

	}

	return CD3DApplication::MsgProc( hWnd, msg, wParam, lParam );
}










































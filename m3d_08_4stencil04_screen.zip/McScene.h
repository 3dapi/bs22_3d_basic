// Interface for the CMcScene class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _McScene_H_
#define _McScene_H_


struct VtxDRHW
{
	D3DXVECTOR4	p;// x,y,z, rhw
	DWORD		d;
	
	VtxDRHW()					{	p.x=p.y=p.z = 0.f;	p.w =1.f; d = 0xFFFFFFFF;		}
	VtxDRHW(FLOAT X,FLOAT Y,DWORD D=0xFFFFFFFF)	{	p.x = X;	p.y = Y;	p.z = 0.f; p.w =1.f;	d = D;	}

	enum { FVF = (D3DFVF_XYZRHW|D3DFVF_DIFFUSE)};
};

class CMcScene
{
protected:
	LPDIRECT3DDEVICE9		m_pDev;

	INT						m_nVtx;
	INT						m_nIdx;
	VtxUV1 *				m_pVtx;
	VtxIdx*					m_pIdx;
	LPDIRECT3DTEXTURE9		m_pTxTiger;
	D3DXVECTOR3				m_vcTiger;

	LPDIRECT3DTEXTURE9		m_pTxFloor;
	VtxUV1					m_pVtxFloor[4];



	VtxDRHW					m_VtxShadow[4];
	
public:
	CMcScene();
	virtual ~CMcScene();

	INT		Create(LPDIRECT3DDEVICE9 pDev);
	void	Destroy();

	INT		FrameMove();
	void	Render();
};

#endif
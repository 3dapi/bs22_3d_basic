// Implementation of the CMcScene class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


void LcMatrixShadow(void* pOutMatrix, const void* Light, void* Plane, BOOL bNormalized=FALSE)
{
	D3DXPLANE	P((FLOAT*)Plane);
	D3DXVECTOR4	L((FLOAT*)Light);

	D3DXMATRIX	mtS;
	FLOAT		D =0;

	// Normalize Plane
	if(FALSE == bNormalized)
		D3DXPlaneNormalize(&P, &P);

	// Dot(Plane, Light)
	D = D3DXVec4Dot((D3DXVECTOR4*)&P, (D3DXVECTOR4*)&L);

	// Setup Output Value
	mtS  = D3DXMATRIX
	(
		D - P.a * L.x,	  - P.a * L.y,	  - P.a * L.z,    - P.a * L.w,
		  - P.b * L.x,	D - P.b * L.y,	  - P.b * L.z,    - P.b * L.w,
		  - P.c * L.x,	  - P.c * L.y,	D - P.c * L.z,    - P.c * L.w,
		  - P.d * L.x,	  - P.d * L.y,	  - P.d * L.z,  D - P.d * L.w
	);

	// Copy Output value
	*((D3DXMATRIX*)pOutMatrix) = mtS;
}


void __main()
{
	INT	i,j;

	printf("\n Parallel Lighting..\n\n");

	D3DXMATRIX mtShd1;
	D3DXMATRIX mtShd2;


	D3DXPLANE	P(13,52,86,21470);
	D3DXVECTOR4	L(21,23,10,0);

	D3DXMatrixShadow(&mtShd1, &L, &P);
	LcMatrixShadow(&mtShd2, &L, &P);

	printf("Shadow matrix from D3D'/'Manual\n");

	for(i=0; i<4; ++i)
	{
		for(j=0; j<4; ++j)
			printf("%12.6f   ",mtShd1.m[i][j]);
		
		printf("\n");

		for(j=0; j<4; ++j)
			printf("%12.6f   ",mtShd2.m[i][j]);

		printf("\n");
	}

	printf("\n");

	printf("Point Lighting..\n");
	printf("Shadow matrix from D3D'/'Manual\n");

	L.w = 1.;

	D3DXMatrixShadow(&mtShd1, &L, &P);
	LcMatrixShadow(&mtShd2, &L, &P);
	

	for(i=0; i<4; ++i)
	{
		for(j=0; j<4; ++j)
			printf("%12.6f   ",mtShd1.m[i][j]);
		
		printf("\n");

		for(j=0; j<4; ++j)
			printf("%12.6f   ",mtShd2.m[i][j]);

		printf("\n");
	}

	printf("\n");
}








CMcScene::CMcScene()
{
	m_pDev	= NULL;
	
	m_nVtx	= 0;
	m_nIdx	= 0;
	m_pVtx	= NULL;
	m_pIdx	= NULL;
	
	m_pTxTiger	= NULL;


	m_pTxFloor	= NULL;
}

CMcScene::~CMcScene()
{
	Destroy();
}

INT CMcScene::Create(LPDIRECT3DDEVICE9 pDev)
{
	HRESULT hr;
	INT		i;

	m_pDev	= pDev;
	


	// Setup Tiger
	{
		LPD3DXMESH		pMdlS=NULL;
		if( FAILED( D3DXLoadMeshFromX( "xFile/Tiger.x",	D3DXMESH_SYSTEMMEM,	m_pDev, NULL, NULL, NULL, NULL, &pMdlS ) ) )
			return -1;
		
		D3DXCreateTextureFromFile(m_pDev, "xFile/tiger.bmp", &m_pTxTiger);
		
		
		LPD3DXMESH pMdlD=NULL;
		hr = pMdlS->CloneMeshFVF(D3DXMESH_SYSTEMMEM, VtxUV1::FVF, m_pDev, &pMdlD);
		pMdlS->Release();
		
		m_nVtx = pMdlD->GetNumVertices();
		m_nIdx = pMdlD->GetNumFaces();
		
		//	DWORD dFVF = pMdlD->GetFVF();
		
		m_pVtx = new VtxUV1[m_nVtx];
		m_pIdx = new VtxIdx[m_nIdx];
		
		void* pVtx= NULL;
		hr = pMdlD->LockVertexBuffer(0, &pVtx);
		
		memcpy(m_pVtx, pVtx, m_nVtx * sizeof(VtxUV1));
		
		hr = pMdlD->UnlockVertexBuffer();
		
		void* pIdx= NULL;
		hr = pMdlD->LockIndexBuffer(0, &pIdx);
		
		memcpy(m_pIdx, pIdx, m_nIdx * sizeof(VtxIdx));
		
		hr = pMdlD->UnlockIndexBuffer();
		
		pMdlD->Release();
		
		
		float fSCale=10;
		float	fMin=100000;
		for(i=0; i<m_nVtx; ++i)
		{
			m_pVtx[i].p *= fSCale;

			if(	m_pVtx[i].p.y<fMin)
				fMin= m_pVtx[i].p.y;
		}

		fMin = -fMin;

		for(i=0; i<m_nVtx; ++i)
		{
			m_pVtx[i].p.y +=fMin;
		}

		m_vcTiger = D3DXVECTOR3(8.0f, 0.f, 0.f);
	}


	// Setup Floor
	D3DXCreateTextureFromFile(m_pDev, "Texture/seafloor.bmp", &m_pTxFloor);

	m_pVtxFloor[0] = VtxUV1(-25.f, -1.f, -25.f, 0.f, 4.f);
	m_pVtxFloor[1] = VtxUV1(-25.f, -1.f,  25.f, 0.f, 0.f);
	m_pVtxFloor[2] = VtxUV1( 25.f, -1.f,  25.f, 0.f, 0.f);
	m_pVtxFloor[3] = VtxUV1( 25.f, -1.f, -25.f, 0.f, 4.f);





	// ������ ȭ�鿡 ���� ������ ���´�. ȭ�� ������ ������� ����̽��� �����
	// ������ �ڵ��� ã�´�.
	D3DDEVICE_CREATION_PARAMETERS Parameters;
	m_pDev->GetCreationParameters(&Parameters);

	// �����쿡 �ش��ϴ� ȭ�� ������ ��´�.
	RECT rc;
	GetClientRect(Parameters.hFocusWindow, &rc);

	FLOAT	fScnW = FLOAT(rc.right - rc.left);
	FLOAT	fScnH = FLOAT(rc.bottom- rc.top );

	m_VtxShadow[0] = VtxDRHW(  0.f,     0, 0x880000FF);
	m_VtxShadow[1] = VtxDRHW(fScnW,     0, 0x88FF0000);
	m_VtxShadow[2] = VtxDRHW(fScnW, fScnH, 0x8800FF00);
	m_VtxShadow[3] = VtxDRHW(  0.f, fScnH, 0x88FF00FF);


	
	return 0;
}


void CMcScene::Destroy()
{
	SAFE_DELETE_ARRAY(	m_pVtx		);
	SAFE_DELETE_ARRAY(	m_pIdx		);
	SAFE_RELEASE(	m_pTxTiger	);
	SAFE_RELEASE(	m_pTxFloor	);
}

INT CMcScene::FrameMove()
{
	return 0;
}


void CMcScene::Render()
{
	D3DXMATRIX mtWld;	D3DXMatrixIdentity(&mtWld);
	D3DXMATRIX mtRot;	D3DXMatrixRotationY(&mtRot, D3DXToRadian(GetTickCount() *0.05F));
	D3DXMATRIX mtI;		D3DXMatrixIdentity(&mtI);


	m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
	m_pDev->SetRenderState(D3DRS_LIGHTING, FALSE);
	m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);

	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);

	m_pDev->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
	m_pDev->SetTextureStageState(0, D3DTSS_COLORARG2, D3DTA_DIFFUSE);
	m_pDev->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_SELECTARG1);



	// 1. ���ٽ��� Default�� �����Ǿ� �ִ� ������Ʈ�� ���� �׸���.
	// ȣ���̸� �׸���.
	mtWld = mtRot;
	mtWld._41 = m_vcTiger.x; mtWld._42 = m_vcTiger.y; mtWld._43 = m_vcTiger.z;

	m_pDev->SetTransform(D3DTS_WORLD, &mtWld);
	m_pDev->SetFVF(VtxUV1::FVF);
	m_pDev->SetTexture(0, m_pTxTiger);
	m_pDev->DrawIndexedPrimitiveUP(D3DPT_TRIANGLELIST, 0, m_nVtx, m_nIdx, m_pIdx, D3DFMT_INDEX16, m_pVtx, sizeof(VtxUV1));

	m_pDev->SetTexture(0, NULL);
	m_pDev->SetTransform(D3DTS_WORLD, &mtI);



	// 2. ���ٽ��� �����ϰ� �ٴ��� �׸���.
	m_pDev->SetRenderState(D3DRS_ZWRITEENABLE, FALSE);

	m_pDev->SetRenderState(D3DRS_STENCILENABLE,    TRUE);
	m_pDev->SetRenderState(D3DRS_STENCILFUNC,      D3DCMP_ALWAYS);
	m_pDev->SetRenderState(D3DRS_STENCILREF,       0x1);
	m_pDev->SetRenderState(D3DRS_STENCILMASK,      0xffffffff);
	m_pDev->SetRenderState(D3DRS_STENCILWRITEMASK, 0xffffffff);
	m_pDev->SetRenderState(D3DRS_STENCILZFAIL,     D3DSTENCILOP_KEEP);
	m_pDev->SetRenderState(D3DRS_STENCILFAIL,      D3DSTENCILOP_KEEP);
	m_pDev->SetRenderState(D3DRS_STENCILPASS,      D3DSTENCILOP_REPLACE);
	
	m_pDev->SetTexture(0, m_pTxFloor);
	m_pDev->SetFVF(VtxUV1::FVF);
	m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLEFAN, 2, m_pVtxFloor, sizeof(VtxUV1));
	m_pDev->SetRenderState(D3DRS_ZWRITEENABLE, TRUE);
	m_pDev->SetTexture(0, NULL);


	//2. �׸��ڸ� �׸���.
	// ȣ���̸� ���� ���� ����� �����Ѵ�.
	// ȣ���̸� ��鿡 ���� �ǵ��� ����� �����.

	D3DXVECTOR4 vcLight(-2.8f, -1.f, 0.f, 0.f);
	D3DXPLANE	dxPlane(  0.f, -1.f, 0.f, 0.f);

	D3DXMATRIX mtShd;
	D3DXMATRIX mtTrn;

	D3DXVec4Normalize(&vcLight, &vcLight);
	LcMatrixShadow(&mtShd, &vcLight, &dxPlane);
	D3DXMatrixTranslation(&mtTrn, m_vcTiger.x, m_vcTiger.y, m_vcTiger.z);
	
	mtWld = mtShd* mtRot *mtTrn;




	// ȣ���̸� ��鿡 �׸��� ���ٽ� ���� 1�� �����Ѵ�.
	m_pDev->SetRenderState(D3DRS_STENCILENABLE,    TRUE);
	m_pDev->SetRenderState(D3DRS_STENCILFUNC,      D3DCMP_EQUAL);
	m_pDev->SetRenderState(D3DRS_STENCILREF,       0x1);
	m_pDev->SetRenderState(D3DRS_STENCILMASK,      0xffffffff);
	m_pDev->SetRenderState(D3DRS_STENCILWRITEMASK, 0xffffffff);

	// ȣ���̿� ���� ��� ���ٽ� �׽�Ʈ�� ���ؼ� ���� 0X1�� �����Ѵ�.
	// �׽�Ʈ�� ����ϸ� ���� 1 ���� ��Ų��.
	m_pDev->SetRenderState(D3DRS_STENCILZFAIL,     D3DSTENCILOP_KEEP);
	m_pDev->SetRenderState(D3DRS_STENCILFAIL,      D3DSTENCILOP_KEEP);
	m_pDev->SetRenderState(D3DRS_STENCILPASS,      D3DSTENCILOP_INCRSAT);


	// ȣ���̸� �׸��� ����, ������ ���� �ʰ� ���ٽǸ� �����ϵ��� �Ѵ�.
	m_pDev->SetRenderState(D3DRS_COLORWRITEENABLE, 0);	// �׸��ڿ� ���� ������ �ĸ� ���ۿ� ���� ������ ���� �ʴ´�.
	m_pDev->SetRenderState(D3DRS_ZWRITEENABLE, FALSE);	// ���̵� �Ⱦ���.

	m_pDev->SetTransform(D3DTS_WORLD, &mtWld);
	m_pDev->SetFVF(VtxUV1::FVF);
	m_pDev->SetTexture(0, NULL);
	m_pDev->DrawIndexedPrimitiveUP(D3DPT_TRIANGLELIST, 0, m_nVtx, m_nIdx, m_pIdx, D3DFMT_INDEX16, m_pVtx, sizeof(VtxUV1));


	m_pDev->SetTransform(D3DTS_WORLD, &mtI);
	m_pDev->SetRenderState(D3DRS_ZWRITEENABLE, TRUE);		// ���� Ȱ��ȭ
	m_pDev->SetRenderState(D3DRS_COLORWRITEENABLE, 0XF);	// ������ �ĸ� ���ۿ� �� �� �ֵ��� �Ѵ�.




	// 3. ȭ�� ��ü�� �׸���.
	// ���ٽ� �ε����� 0X2�� �κ��� ������ �ϱ� ���ؼ� ȭ�� ��ü�� RHW�� �׸���.
	m_pDev->SetRenderState(D3DRS_STENCILENABLE,    TRUE);
	m_pDev->SetRenderState(D3DRS_STENCILFUNC,      D3DCMP_LESSEQUAL);
	m_pDev->SetRenderState(D3DRS_STENCILREF,       0x2);
	m_pDev->SetRenderState(D3DRS_STENCILMASK,      0xffffffff);
	m_pDev->SetRenderState(D3DRS_STENCILWRITEMASK, 0xffffffff);
	m_pDev->SetRenderState(D3DRS_STENCILZFAIL,     D3DSTENCILOP_KEEP);
	m_pDev->SetRenderState(D3DRS_STENCILFAIL,      D3DSTENCILOP_KEEP);
	m_pDev->SetRenderState(D3DRS_STENCILPASS,      D3DSTENCILOP_KEEP);


	// ���� ���������� ������ ȥ���Ѵ�.
	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);

	m_pDev->SetTexture(0, NULL);
	m_pDev->SetFVF(VtxDRHW::FVF);
	m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLEFAN, 2, m_VtxShadow, sizeof(VtxDRHW));


	m_pDev->SetRenderState( D3DRS_STENCILENABLE, FALSE);
	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
}




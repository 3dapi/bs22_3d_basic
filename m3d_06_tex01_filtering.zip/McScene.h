// Interface for the CMcScene class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _McScene_H_
#define _McScene_H_

class CMcScene
{
protected:
	LPDIRECT3DDEVICE9	m_pDev;
	
	VtxUV1				m_pVtx[4];
	LPDIRECT3DTEXTURE9	m_pTx;
	
public:
	CMcScene();
	virtual ~CMcScene();

	INT		Create(LPDIRECT3DDEVICE9 pDev);
	void	Destroy();

	INT		FrameMove();
	void	Render();
};

#endif
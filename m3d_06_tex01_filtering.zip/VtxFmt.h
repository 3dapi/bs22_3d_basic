#ifndef _VTXFMT_H_
#define _VTXFMT_H_

struct VtxD
{
	D3DXVECTOR3	p;
	DWORD	d;

	VtxD() : d(0xFFFFFFFF){}
	VtxD(FLOAT X, FLOAT Y, FLOAT Z, DWORD D) : p(X,Y,Z), d(D){}
	enum { FVF = (D3DFVF_XYZ|D3DFVF_DIFFUSE)};
};



struct VtxUV1
{
	D3DXVECTOR3	p;
	FLOAT	u, v;
	
	VtxUV1()						: p(0,0,0),u(0),v(0){}
	VtxUV1(	FLOAT X,FLOAT Y,FLOAT Z
			,	FLOAT U, FLOAT V)	: p(X,Y,Z),u(U),v(V){}

	enum {	FVF= (D3DFVF_XYZ|D3DFVF_TEX1)	};

};


#endif
// Implementation of the CMcScene class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMcScene::CMcScene()
{
	m_pTx	= NULL;
}

CMcScene::~CMcScene()
{
	Destroy();
}

INT CMcScene::Create(LPDIRECT3DDEVICE9 pDev)
{
	m_pDev	= pDev;

	m_pVtx[0] = VtxUV1(-15.0f, 0.f, -45.0f,-10.0f, 30.0f);
	m_pVtx[1] = VtxUV1(-15.0f, 0.f, 180.0f,-10.0f,-90.0f);
	m_pVtx[2] = VtxUV1( 15.0f, 0.f, 180.0f, 10.0f,-90.0f);
	m_pVtx[3] = VtxUV1( 15.0f, 0.f, -45.0f, 10.0f, 30.0f);

	D3DXCreateTextureFromFileEx(m_pDev
							, "Texture/dx5_logo.bmp"
							, D3DX_DEFAULT
							, D3DX_DEFAULT
							, D3DX_DEFAULT
							, 0
							, D3DFMT_UNKNOWN
							, D3DPOOL_MANAGED
							, D3DX_DEFAULT
							, D3DX_DEFAULT
							, 0
							, NULL
							, NULL
							, &m_pTx);

	return 0;
}


void CMcScene::Destroy()
{
	SAFE_RELEASE(	m_pTx	);
}

INT CMcScene::FrameMove()
{
	return 0;
}

void CMcScene::Render()
{
	m_pDev->SetRenderState(D3DRS_LIGHTING, FALSE);

	m_pDev->SetTexture(0, m_pTx);

	// None
	if( ::GetAsyncKeyState('1') & 0x8000 )
	{
		m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_NONE);
		m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_NONE);
		m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_NONE);
	}

	// Point
	if( ::GetAsyncKeyState('2') & 0x8000 )
	{
		m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_POINT);
		m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_POINT);
		m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_POINT);
	}

	// Linear
	if( ::GetAsyncKeyState('3') & 0x8000 )
	{
		m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
		m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
		m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
	}

	// Anisotropic
	if( ::GetAsyncKeyState('4') & 0x8000 )
	{
		D3DCAPS9	caps;
		m_pDev->GetDeviceCaps(&caps);
		m_pDev->SetSamplerState(0, D3DSAMP_MAXANISOTROPY, caps.MaxAnisotropy);

		m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_ANISOTROPIC);
		m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_ANISOTROPIC);
		m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_ANISOTROPIC);

	}




	
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);


	m_pDev->SetFVF(VtxUV1::FVF);
	m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLEFAN, 2, m_pVtx, sizeof(VtxUV1));
}



// Interface for the CLcShadow class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LcShadow_H_
#define _LcShadow_H_

class CLcShadow
{
protected:
	LPDIRECT3DDEVICE9	m_pDev;
	D3DXVECTOR3			m_pVtx[32000]; // Vertex data for rendering LcShadow volume
	INT					m_nVtx;
	
public:
	CLcShadow();
	virtual ~CLcShadow();

	virtual INT		Create(LPDIRECT3DDEVICE9 pDev);
	virtual void	Render();

public:
	void    Reset();
	INT		Build(LPD3DXMESH pMesh, D3DXMATRIX m, D3DXVECTOR3 vL);
	void	AddEdge( WORD* pEdges, DWORD& dwNumEdges, WORD v0, WORD v1 );
};

#endif


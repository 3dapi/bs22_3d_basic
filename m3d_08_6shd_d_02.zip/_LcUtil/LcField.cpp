// Implementation of the CLcField class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <stdio.h>
#include <d3d9.h>
#include <d3dx9.h>

#include "LcField.h"

#define SAFE_DELETE(p)       { if(p) { delete (p);     (p)=NULL; } }
#define SAFE_DELETE_ARRAY(p) { if(p) { delete[] (p);   (p)=NULL; } }
#define SAFE_RELEASE(p)      { if(p) { (p)->Release(); (p)=NULL; } }


CLcField::CLcField()
{
}


CLcField::~CLcField()
{
	Destroy();
}


INT CLcField::Create(LPDIRECT3DDEVICE9 pDev)
{
	m_pDev	= pDev;

	FLOAT	fW = 150;

	m_pVtx[0] = VtxUV1(-fW, 0, -fW, 0, 2);
	m_pVtx[1] = VtxUV1(-fW, 0,  fW, 0, 0);
	m_pVtx[2] = VtxUV1( fW, 0,  fW, 0, 0);
	m_pVtx[3] = VtxUV1( fW, 0, -fW, 0, 2);



	D3DXCreateTextureFromFile(m_pDev, "Texture/seafloor.bmp", &m_pTex);

	return 0;
}


void CLcField::Destroy()
{
	SAFE_RELEASE(	m_pTex	);
}


INT	CLcField::FrameMove()
{
	return 0;
}

void CLcField::Render()
{
	m_pDev->SetRenderState( D3DRS_CULLMODE,  D3DCULL_CCW);
	m_pDev->SetRenderState( D3DRS_ALPHABLENDENABLE,  FALSE);
	m_pDev->SetRenderState( D3DRS_ALPHATESTENABLE,  FALSE);

	m_pDev->SetTexture(0, m_pTex);
	m_pDev->SetFVF(VtxUV1::FVF);

	m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLEFAN, 2, m_pVtx, sizeof(VtxUV1));
	m_pDev->SetTexture(0, NULL);
}


// Implementation of the CLcShadow class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <stdio.h>

#include <d3d9.h>
#include <d3dx9.h>

#include "LcShadow.h"


CLcShadow::CLcShadow()
{
	m_pDev	= 0;
	memset(m_pVtx, 0, sizeof m_pVtx);
	m_nVtx	= 0;
}

CLcShadow::~CLcShadow()
{

}


INT CLcShadow::Create(LPDIRECT3DDEVICE9 pDev)
{
	m_pDev = pDev;
	return 0;
}



void CLcShadow::Render()
{
	m_pDev->SetFVF( D3DFVF_XYZ );
	m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLELIST, m_nVtx/3, m_pVtx, sizeof(D3DXVECTOR3) );
}


void CLcShadow::Reset()
{
	m_nVtx = 0L;
}



void CLcShadow::AddEdge( WORD* pEdges, DWORD& nFce, WORD v0, WORD v1 )
{
	// Remove interior edges (which appear in the list twice)
	for( DWORD i=0; i < nFce; i++ )
	{
		if( ( pEdges[2*i+0] == v0 && pEdges[2*i+1] == v1 ) ||
			( pEdges[2*i+0] == v1 && pEdges[2*i+1] == v0 ) )
		{
			if( nFce > 1 )
			{
				pEdges[2*i+0] = pEdges[2*(nFce-1)+0];
				pEdges[2*i+1] = pEdges[2*(nFce-1)+1];
			}
			nFce--;
			return;
		}
	}
	
	pEdges[2*nFce+0] = v0;
	pEdges[2*nFce+1] = v1;
	nFce++;
}





INT CLcShadow::Build(LPD3DXMESH pMesh, D3DXMATRIX m, D3DXVECTOR3 vL)
{	
	FLOAT	fL = 4000;

	D3DXVECTOR3 vT = - vL*(fL + fabsf(m._42));




	memset(m_pVtx, 0, sizeof m_pVtx);
	m_nVtx	= 0;

	BYTE*	pVtx	= NULL;
	WORD*   pFce	= NULL;
	DWORD	dNumVtx	= pMesh->GetNumVertices();
	DWORD	dStride	= D3DXGetFVFVertexSize(pMesh->GetFVF());

	DWORD	nFce    = pMesh->GetNumFaces();
	WORD*	pEdges = new WORD[nFce*6];
	DWORD	nEdges = 0;
	DWORD	i=0;
	
	pMesh->LockVertexBuffer( 0L, (void**)&pVtx );
	pMesh->LockIndexBuffer( 0L, (void**)&pFce );

	for(i=0; i<nFce; i++ )
	{
		WORD wFace0 = pFce[3*i+0];
		WORD wFace1 = pFce[3*i+1];
		WORD wFace2 = pFce[3*i+2];

		D3DXVECTOR3 v0 = *((D3DXVECTOR3*)(pVtx + wFace0 * dStride));
		D3DXVECTOR3 v1 = *((D3DXVECTOR3*)(pVtx + wFace1 * dStride));
		D3DXVECTOR3 v2 = *((D3DXVECTOR3*)(pVtx + wFace2 * dStride));

		D3DXVec3TransformCoord(&v0, &v0, &m);
		D3DXVec3TransformCoord(&v1, &v1, &m);
		D3DXVec3TransformCoord(&v2, &v2, &m);
		
		// Transform vertices or transform light?
		D3DXVECTOR3 vCross1(v2-v1);
		D3DXVECTOR3 vCross2(v1-v0);
		D3DXVECTOR3 vNormal;
		D3DXVec3Cross( &vNormal, &vCross1, &vCross2 );
		
		if( D3DXVec3Dot( &vNormal, &vL ) >= 0.0f )
		{
			AddEdge( pEdges, nEdges, wFace0, wFace1 );
			AddEdge( pEdges, nEdges, wFace1, wFace2 );
			AddEdge( pEdges, nEdges, wFace2, wFace0 );
		}
	}
	
	for( i=0; i<nEdges; i++ )
	{
		D3DXVECTOR3 v1 = *((D3DXVECTOR3*)(pVtx + pEdges[2*i+0] * dStride));
		D3DXVECTOR3 v2 = *((D3DXVECTOR3*)(pVtx + pEdges[2*i+1] * dStride));

		D3DXVec3TransformCoord(&v1, &v1, &m);
		D3DXVec3TransformCoord(&v2, &v2, &m);
		
//		D3DXVECTOR3 v3 = v1 - vL*(fL + fabsf(m._42));
//		D3DXVECTOR3 v4 = v2 - vL*(fL + fabsf(m._42));

		D3DXVECTOR3 v3 = vT;
		D3DXVECTOR3 v4 = vT;


////		v1 += vL*(50 + fabsf(m._42));
////		v2 += vL*(50 + fabsf(m._42));

	
	
		m_pVtx[m_nVtx++] = v1;
		m_pVtx[m_nVtx++] = v2;
		m_pVtx[m_nVtx++] = v3;
		
		m_pVtx[m_nVtx++] = v2;
		m_pVtx[m_nVtx++] = v4;
		m_pVtx[m_nVtx++] = v3;
	}

	delete[] pEdges;
	

	pMesh->UnlockVertexBuffer();
	pMesh->UnlockIndexBuffer();

	return 0;
}
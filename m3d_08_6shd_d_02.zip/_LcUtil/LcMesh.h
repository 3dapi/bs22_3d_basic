// Interface for the CLcMesh class.
//
////////////////////////////////////////////////////////////////////////////////

#if _MSC_VER >=1200
  #pragma warning(disable: 4996)
#endif

#ifndef _LcMesh_H_
#define _LcMesh_H_


class CLcMesh
{
public:
	char				m_sName[MAX_PATH];
	
	LPDIRECT3DDEVICE9	m_pDev;
	LPD3DXMESH			m_pMeshSrc;		// Source Mesh, lives through resize
	LPD3DXMESH			m_pMeshDst;		// Dest Mesh, rebuilt on resize
	
	DWORD				m_nMaterial;	// Materials for the mesh
	D3DMATERIAL9*		m_pMaterial;
	LPDIRECT3DTEXTURE9*	m_pTexture;

	BOOL				m_bMaterial;
	BOOL				m_bOpaque;
	BOOL				m_bAlpha;
	
public:
	CLcMesh();
	virtual ~CLcMesh();
	
	virtual	INT		Create(LPDIRECT3DDEVICE9 pDev, char* strFilename=NULL, LPD3DXFILEDATA pFileData=NULL);
	virtual	void	Destroy();

	virtual	INT		Restore();
	virtual	void	Invalidate();
	
	virtual	INT		FrameMove();
	virtual	void	Render();

public:
	INT		SetFVF(DWORD);
	INT		SetVertexDecl(D3DVERTEXELEMENT9*);
	
	void	SetOpaqueSubsets(BOOL = TRUE);
	void	SetAlphaSubsets(BOOL = TRUE);
	void	UseMeshMaterials(BOOL);
	void*	GetMeshSrc();
	void*	GetMeshDst();
};




#endif

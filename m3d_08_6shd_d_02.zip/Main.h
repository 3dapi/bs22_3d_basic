// Interface for the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _MAIN_H_
#define _MAIN_H_


class CMain : public CD3DApplication
{
protected:
	CLcInput*		m_pInput;
	CLcCam*			m_pCam;
	ID3DXFont*      m_pD3DXFont;            // D3DX font

	CLcField*		m_pField;

	CMcScene*		m_pScene;

public:
	CMain();
    
	virtual HRESULT Init();
    virtual HRESULT Destroy();

    virtual HRESULT Restore();
    virtual HRESULT Invalidate();

    virtual HRESULT FrameMove();
    virtual HRESULT Render();

	virtual LRESULT MsgProc( HWND, UINT, WPARAM, LPARAM);

    HRESULT RenderText();

public:
	CLcInput*	GetInput()	{	return m_pInput;	}
	CLcCam*		GetCam()	{	return m_pCam;		}
	CLcField*	GetFiled()	{	return m_pField;	}
};


extern CMain*	g_pApp;
#define GMAIN	g_pApp

#endif




// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMain*	CMain::g_pD3DApp = NULL;


CMain::CMain()
{
	CMain::g_pD3DApp = this;
	m_pD3D			= NULL;
	m_pd3dDevice	= NULL;
}


CMain::~CMain()
{
}


INT CMain::Create( HINSTANCE hInst)
{
	m_hInst	= hInst;
	// ������ Ŭ���� ���
	WNDCLASS wc =
	{
		(CS_CLASSDC | CS_DBLCLKS)
			, WndProc
			, 0L
			, 0L
			, m_hInst//GetModuleHandle(NULL)
			, LoadIcon(NULL, IDI_APPLICATION)
			, LoadCursor(NULL, IDC_ARROW)
			, (HBRUSH)GetStockObject(WHITE_BRUSH)
			, NULL
			, "Mck_D3D"
	};
	
	// ������ Ŭ���� ���
	if( !RegisterClass( &wc ))
		return -1;
	
	RECT	rc ={0, 0, 800, 600};
	DWORD	dStyle = (WS_CAPTION | WS_SYSMENU | WS_VISIBLE);
	AdjustWindowRect( &rc, dStyle, FALSE );
	
	// ������ ����
	m_hWnd = CreateWindow( "Mck_D3D"
		, "D3D CreateDevice"
		, dStyle
		, 30
		, 30
		, (rc.right - rc.left)
		, (rc.bottom - rc.top)
		, GetDesktopWindow()
		, NULL
		, m_hInst
		, NULL );
	
	
	// D3D����
	if( NULL == ( m_pD3D = Direct3DCreate9( D3D_SDK_VERSION ) ) )
		return -1;
	
	
	
	// D3D�� ���ؼ� ȭ�� ��带 ã�´�.
	D3DDISPLAYMODE d3ddm={0};
	if( FAILED( m_pD3D->GetAdapterDisplayMode( D3DADAPTER_DEFAULT, &d3ddm ) ) )
		return -1;
	
	// ����̽� �ɷ�
	D3DCAPS9 pCaps;
	m_pD3D->GetDeviceCaps(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, &pCaps);
	
	// ������Ʈ �Ķ���� ����ü ����
	D3DPRESENT_PARAMETERS d3dpp={0};
	
	d3dpp.Windowed				= TRUE;
	d3dpp.SwapEffect			= D3DSWAPEFFECT_DISCARD;
	d3dpp.EnableAutoDepthStencil= TRUE;
	
	d3dpp.BackBufferFormat		= d3ddm.Format;		// ���� ȭ�� �ػ󵵷� ������ ���
	d3dpp.BackBufferFormat		= D3DFMT_X8R8G8B8;	// ������ ����
	
	d3dpp.AutoDepthStencilFormat= D3DFMT_D24S8;		// Depth-Stencil ���� ����
	d3dpp.PresentationInterval	= D3DPRESENT_INTERVAL_IMMEDIATE;
	
	
	
	//	��Ƽ ���ø� �ִ� ���� ã��
	DWORD dQualityLevels;
	
	for(int nType=D3DMULTISAMPLE_16_SAMPLES; nType>=0; --nType)
	{
		if(SUCCEEDED(m_pD3D->CheckDeviceMultiSampleType(D3DADAPTER_DEFAULT
			, D3DDEVTYPE_HAL
			, d3dpp.BackBufferFormat
			, TRUE
			, (D3DMULTISAMPLE_TYPE)nType
			, &dQualityLevels)))
		{
			d3dpp.MultiSampleType		= (D3DMULTISAMPLE_TYPE)nType;
			d3dpp.MultiSampleQuality	= dQualityLevels-1;
			
			break;
		}
	}
	
	
	// ����̽� ����
	if( FAILED( m_pD3D->CreateDevice(	D3DADAPTER_DEFAULT
		,	D3DDEVTYPE_HAL
		,	m_hWnd
		,	D3DCREATE_MIXED_VERTEXPROCESSING
		,	&d3dpp
		,	&m_pd3dDevice ) ) )
	{
		if( FAILED( m_pD3D->CreateDevice(	D3DADAPTER_DEFAULT
			,	D3DDEVTYPE_HAL
			,	m_hWnd
			,	D3DCREATE_SOFTWARE_VERTEXPROCESSING
			,	&d3dpp
			,	&m_pd3dDevice ) ) )
		{
			m_pD3D->Release();
			return -1;
		}
	}
	
	
	
	//m_pd3dDevice->GetDeviceCaps(&pCaps);
	
	ShowWindow( m_hWnd, SW_SHOWDEFAULT );
	UpdateWindow( m_hWnd );
	
	
	return S_OK;
}


void CMain::Cleanup()
{
	if( m_pd3dDevice != NULL) 
		m_pd3dDevice->Release();
	
	if( m_pD3D != NULL)
		m_pD3D->Release();
}


void CMain::Render()
{
	if( NULL == m_pd3dDevice )
		return;
	
	// ���������δ� ����(�����: ����, ����, ���ٽ�)�� ����� ���� �ƴ϶� ä��� ��
	m_pd3dDevice->Clear( 0, NULL, (D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER|D3DCLEAR_STENCIL), D3DCOLOR_XRGB(0,128,200), 1.0f, 0 );


	// BeginScene�� EndScene�� ������
	if( FAILED( m_pd3dDevice->BeginScene() ) )
		return;
	
	// Rendering
	
	// End the scene
	m_pd3dDevice->EndScene();
	
	
	// �ĸ���۸� ������۷� ��ü( flipping)
	m_pd3dDevice->Present( NULL, NULL, NULL, NULL );
}



LRESULT WINAPI CMain::WndProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
	return CMain::g_pD3DApp->MsgProc(hWnd, msg, wParam, lParam);
}


LRESULT CMain::MsgProc( HWND m_hWnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
	switch( msg )
	{
	case WM_DESTROY:
		Cleanup();
		PostQuitMessage( 0 );
		return 0;
		
	case WM_PAINT:
		Render();
		ValidateRect( m_hWnd, NULL );
		return 0;
	}
	
	return DefWindowProc( m_hWnd, msg, wParam, lParam );
}

INT CMain::Run()
{	    
	// Enter the message loop
	MSG msg; 
	while( GetMessage( &msg, NULL, 0, 0 ) )
	{
		TranslateMessage( &msg );
		DispatchMessage( &msg );
	}
	
	return 0;
}

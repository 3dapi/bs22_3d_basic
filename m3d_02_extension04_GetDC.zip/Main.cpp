// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMain::CMain()

{
	m_pD3DXFont	= NULL;
	m_pTx		= NULL;
	m_pTxSf		= NULL;

}



HRESULT CMain::Init()

{
	if( FAILED( D3DXCreateFont( GDEVICE, 16, 0, FW_BOLD, 1, 0, HANGUL_CHARSET, OUT_DEFAULT_PRECIS, ANTIALIASED_QUALITY, FF_DONTCARE, "Arial", &m_pD3DXFont ) ) )
		return -1;


	m_iSfW = 760;
	m_iSfH = 280;

//	D3DXCreateTexture(GDEVICE, m_iSfW, m_iSfW, 1, 1, D3DFMT_A8R8G8B8, D3DPOOL_MANAGED, &m_pTx);
	D3DXCreateTexture(GDEVICE, m_iSfW, m_iSfH, 0, 0, D3DFMT_X8R8G8B8, D3DPOOL_MANAGED, &m_pTx);

	
	m_pTx->GetSurfaceLevel(0, &m_pTxSf);


	D3DSURFACE_DESC dsc;

	m_pTxSf->GetDesc(&dsc);

	D3DLOCKED_RECT rt;
	m_pTxSf->LockRect(&rt, 0, 0);

	DWORD*	pData = (DWORD*) rt.pBits;

	memset(pData, 0x55, sizeof(DWORD)* dsc.Width * dsc.Height);

	for(int i=0; i<200; ++i)
	{
		for(int j=0; j<dsc.Width; ++j)
		{
//			int nIdx = i * rt.Pitch/ 4 + j;
			int nIdx = i * dsc.Width + j;

			pData[nIdx] = 0xaaaaaaaa;
		}
	}

	m_pTxSf->UnlockRect();

	return S_OK;

}


HRESULT CMain::Destroy()

{
	SAFE_RELEASE( m_pD3DXFont	);

	SAFE_RELEASE(	m_pTx		);
	SAFE_RELEASE(	m_pTxSf		);

	return S_OK;

}




HRESULT CMain::Restore()
{	
	m_pD3DXFont->OnResetDevice();
	return S_OK;

}


HRESULT CMain::Invalidate()

{
	m_pD3DXFont->OnLostDevice();
	return S_OK;

}



HRESULT CMain::FrameMove()

{
	D3DSURFACE_DESC dsc;

	m_pTxSf->GetDesc(&dsc);

	D3DLOCKED_RECT rt;

	m_pTxSf->LockRect(&rt, 0, 0);
	DWORD*	pData = (DWORD*) rt.pBits;

	memset(pData, 0xaa, sizeof(DWORD)* dsc.Width * 200);
	m_pTxSf->UnlockRect();

	// DC�� ���� ����.. 
	HDC hDC = NULL;
	
	m_pTxSf->GetDC(&hDC);

	if(hDC)
	{
//		ColorFill
		char sMsg[1024];
		SetBkMode(hDC, TRANSPARENT);
		SetTextColor(hDC, RGB(128,255,255));

		sprintf(sMsg, "%s", "�ؽ�ó�� DC�� ���ڿ� ���");
		TextOut(hDC, 15, 10, sMsg, strlen(sMsg));

		sprintf(sMsg, "%s", m_strDeviceStats);
		TextOut(hDC, 15, 30, sMsg, strlen(sMsg));

		sprintf(sMsg, "%s", m_strFrameStats);
		TextOut(hDC, 15, 50, sMsg, strlen(sMsg));


		m_pTxSf->ReleaseDC(hDC);
	}


	return S_OK;

}



HRESULT CMain::Render()

{
	MATA	mtW;
	D3DXMatrixIdentity(&mtW);
	GDEVICE->SetTransform(D3DTS_WORLD, &mtW);


	m_pd3dDevice->Clear( 0L, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER|D3DCLEAR_STENCIL, 0xFF006699, 1.0f, 0L);


	if( FAILED( m_pd3dDevice->BeginScene() ) )

		return -1;


	GDEVICE->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
	GDEVICE->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);


	RECT rt;

	rt.left = 0;
	rt.right = rt.left + 512;
	rt.top = 0;
	rt.bottom = rt.top + 280;

	VEC3	pos;

	pos.x = 50;
	pos.y = 50;
	pos.z = 0;

	GSPRITE->Begin(D3DXSPRITE_ALPHABLEND);
	GSPRITE->Draw(m_pTx, &rt, NULL, &pos, D3DXCOLOR(1,1,1,1));
	GSPRITE->End();

	GDEVICE->SetRenderState(D3DRS_ZENABLE, D3DZB_TRUE);

	RenderText();

	m_pd3dDevice->EndScene();


	return S_OK;

}


HRESULT CMain::RenderText()

{
	m_pd3dDevice->SetRenderState(D3DRS_LIGHTING, FALSE);
	m_pd3dDevice->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
	m_pd3dDevice->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);

	m_pd3dDevice->SetTexture( 0, 0);


	CHAR szMsg[MAX_PATH];
	RECT rc;
	rc.left   = 2;
	rc.right  = m_d3dsdBackBuffer.Width - 20;
	rc.top = 3;
	rc.bottom = rc.top + 20;

	sprintf(szMsg, "%s %s",m_strDeviceStats, m_strFrameStats );

	
	m_pD3DXFont->DrawText(NULL, szMsg, -1, &rc, 0, D3DXCOLOR(1,1,0,1) );


	return S_OK;

}


LRESULT CMain::MsgProc( HWND hWnd, UINT msg, WPARAM wParam,LPARAM lParam)

{
	WPARAM	wparHi;
	WPARAM	wparLo;

	wparHi = HIWORD(wParam);
	wparLo = LOWORD(wParam);


	switch( msg )
	{
		case WM_PAINT:
		{
			if( m_bLoadingApp )

			{
				HDC hDC = GetDC( hWnd );
				RECT rc;
				GetClientRect( hWnd, &rc );
				ReleaseDC( hWnd, hDC );
			}
			break;
		}
	}


	return CD3DApplication::MsgProc( hWnd, msg, wParam, lParam );

}










































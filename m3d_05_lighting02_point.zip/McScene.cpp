// Implementation of the CMcScene class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"



CMcObject::CMcObject()
{
	m_pMsh	= NULL;
	memset(&m_Mtrl, 0, sizeof(D3DMATERIAL9));
	D3DXMatrixIdentity(&m_mtWld);
}


CMcObject::~CMcObject()
{
	if(m_pMsh)
	{
		m_pMsh->Release();
		m_pMsh	= NULL;
	}
}


void CMcObject::Render(LPDIRECT3DDEVICE9 pDev)
{
	// ���� ����
	pDev->SetMaterial(&m_Mtrl);

	// ����̽��� ���� ��� ����
	pDev->SetTransform(D3DTS_WORLD, &m_mtWld);
	m_pMsh->DrawSubset(0);
}



void CMcObject::SetMesh(LPD3DXMESH pMesh)
{
	m_pMsh = pMesh;
}

void CMcObject::SetMaterial(const D3DMATERIAL9* pMtrl)
{
	memcpy(&m_Mtrl, pMtrl, sizeof(D3DMATERIAL9));
}

void CMcObject::SetWorld(const D3DXMATRIX* mtWld)
{
	memcpy(&m_mtWld, mtWld, sizeof(D3DXMATRIX));
}



CMcScene::CMcScene()
{
	m_pObj = NULL;
}

CMcScene::~CMcScene()
{
	Destroy();
}

void CMcScene::Destroy()
{
	SAFE_DELETE_ARRAY(	m_pObj	);
}

INT CMcScene::Create(LPDIRECT3DDEVICE9 pDev)
{
	m_pDev	= pDev;

	m_pObj = new CMcObject[4];


	// ������Ʈ �ν��Ͻ� ����
	LPD3DXMESH pMesh;
	D3DXCreateTeapot(m_pDev,							&pMesh, 0);	m_pObj[0].SetMesh(pMesh);
	D3DXCreateSphere(m_pDev, 1.0f, 20, 20,				&pMesh, 0);	m_pObj[1].SetMesh(pMesh);
	D3DXCreateTorus(m_pDev, 0.5f, 1.0f, 20, 20,			&pMesh, 0);	m_pObj[2].SetMesh(pMesh);
	D3DXCreateCylinder(m_pDev, 0.5f, 0.5f, 2.f, 20, 20,	&pMesh, 0);	m_pObj[3].SetMesh(pMesh);

	
	// ����� �����ϱ� ���� ������Ʈ�� ���� ��� ����
	D3DXMATRIX	mtWld;
	D3DXMatrixTranslation(&mtWld,  0.0f,  2.0f, 0.0f);	m_pObj[0].SetWorld(&mtWld);
	D3DXMatrixTranslation(&mtWld,  0.0f, -2.0f, 0.0f);	m_pObj[1].SetWorld(&mtWld);
	D3DXMatrixTranslation(&mtWld, -3.0f,  0.0f, 0.0f);	m_pObj[2].SetWorld(&mtWld);
	D3DXMatrixTranslation(&mtWld,  3.0f,  0.0f, 0.0f);	m_pObj[3].SetWorld(&mtWld);

	
	// ������Ʈ ��Ƽ���� ����
	//	Diffuse, Ambient, Specular, Emissive, Power

	const D3DMATERIAL9 WHITE_MTRL  = { {1,1,1,1}, {1,1,1,1}, {1,1,1,1}, {0.1f,0.1f,0.1f,1}, 3.F};
	const D3DMATERIAL9 RED_MTRL    = { {1,0,0,1}, {1,0,0,1}, {1,0,0,1}, {0.1f,   0,   0,1}, 3.F};
	const D3DMATERIAL9 GREEN_MTRL  = { {0,1,0,1}, {0,1,0,1}, {0,1,0,1}, {   0,0.1f,   0,1}, 3.F};
	const D3DMATERIAL9 BLUE_MTRL   = { {0,0,1,1}, {0,0,1,1}, {0,0,1,1}, {   0,   0,0.1f,1}, 3.F};
	const D3DMATERIAL9 MAGENTA_MTRL= { {1,0,1,1}, {1,0,1,1}, {1,0,1,1}, {0.1f,   0,0.1f,1}, 3.F};

	m_pObj[0].SetMaterial(&RED_MTRL);
	m_pObj[1].SetMaterial(&GREEN_MTRL);
	m_pObj[2].SetMaterial(&BLUE_MTRL);
	m_pObj[3].SetMaterial(&MAGENTA_MTRL);




	// �� ��� ���ϱ�
	D3DXVECTOR3 vcEye ( 0, 0, -7.5F);
	D3DXVECTOR3 vcLook( 0, 0,  0);
	D3DXVECTOR3 vcUp  ( 0, 1,  0);

	D3DXMatrixLookAtLH(&m_mtViw, &vcEye, &vcLook, &vcUp);


	// ���� ��� �����
	FLOAT	fScreenW = 800.f;
	FLOAT	fScreenH = 600.f;
	FLOAT	fFOV	= D3DX_PI/4.0f;
	FLOAT	fAspect	= fScreenW/fScreenH;
	FLOAT	fNear	= 1.f;
	FLOAT	fFar	= 5000.f;
	
	D3DXMatrixPerspectiveFovLH(&m_mtPrj, fFOV, fAspect, fNear, fFar);

	return 0;
}


INT CMcScene::FrameMove()
{
	return 0;
}


void CMcScene::Render()
{
	// �����, ���� ��� ����
	m_pDev->SetTransform(D3DTS_VIEW, &m_mtViw);
	m_pDev->SetTransform(D3DTS_PROJECTION, &m_mtPrj);


	// ������ ����
	D3DLIGHT9	Light;
	D3DXCOLOR   Color(1,1,1,1);

	memset(&Light, 0, sizeof(D3DLIGHT9));

	Light.Type      = D3DLIGHT_POINT;
	Light.Ambient   = Color * 0.3f;
	Light.Diffuse   = Color;
	Light.Specular  = Color*0.2f;
	Light.Position  = D3DXVECTOR3 (0.0f, 0.0f, 0.0f);
	Light.Range        = 2000.0f;
	Light.Falloff      = 1.0f;
	Light.Attenuation0 = 0.5f;
	Light.Attenuation1 = 0.1f;
	Light.Attenuation2 = 0.1f;



	// ������ ����
	m_pDev->SetLight(0, &Light);
	m_pDev->LightEnable(0, TRUE);

	// ������ ���� ����
	m_pDev->SetRenderState(D3DRS_LIGHTING, TRUE);
	m_pDev->SetRenderState(D3DRS_NORMALIZENORMALS, TRUE);
	m_pDev->SetRenderState(D3DRS_SPECULARENABLE, TRUE);

	// �� ������
	for(int i = 0; i < 4; i++)
		m_pObj[i].Render(m_pDev);



	// ���� ����� �ʱ�ȭ
	static D3DXMATRIX	mtI;
	D3DXMatrixIdentity(&mtI);
	m_pDev->SetTransform(D3DTS_WORLD, &mtI);
}


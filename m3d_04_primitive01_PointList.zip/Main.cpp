// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


#define SAFE_DELETE(p)       { if(p) { delete (p);     (p)=NULL; } }
#define SAFE_DELETE_ARRAY(p) { if(p) { delete[] (p);   (p)=NULL; } }
#define SAFE_RELEASE(p)      { if(p) { (p)->Release(); (p)=NULL; } }


CMain::CMain()
{
	strcpy(m_sCls, "Mck_D3D");

	m_hInst			= NULL;
	m_hWnd			= NULL;
	m_pD3D			= NULL;
	m_pd3dDevice	= NULL;

	m_dWinStyle		= WS_OVERLAPPED | WS_CAPTION |WS_SYSMENU|WS_VISIBLE;
	m_dScnX			= 800;
	m_dScnY			= 600;


	m_pVB			= NULL;
}


CMain::~CMain()
{
}


INT CMain::Init()
{
	::SetWindowText(m_hWnd, "Primitive Point List");

	m_dwSizeVertices = sizeof(VtxRHWD) * 6;

	HRESULT hr=0;

	hr = m_pd3dDevice->CreateVertexBuffer(
						m_dwSizeVertices
						, 0			//D3DUSAGE_POINTS
						, FVF_VTXDRHW
						, D3DPOOL_MANAGED
						, &m_pVB, 0 );


	if( FAILED( hr ) )
		return -1;


	// Initialize to render a quad
	VtxRHWD pVtx[6];

	pVtx[0] = VtxRHWD(  50.f,  470.f, 0xFFFF0000 );
	pVtx[1] = VtxRHWD( 210.f,  180.f, 0xFF00FF00 );
	pVtx[2] = VtxRHWD( 340.f,  450.f, 0xFF0000FF );
	pVtx[3] = VtxRHWD( 400.f,  130.f, 0xFFFFFF00 );
	pVtx[4] = VtxRHWD( 540.f,  470.f, 0xFF00FFFF );
	pVtx[5] = VtxRHWD( 630.f,  140.f, 0xFFFF00FF );


	VtxRHWD* pVertices;


	if( FAILED( m_pVB->Lock( 0, 0, (void**)&pVertices, 0 ) ) )
		return -1;

	memcpy( pVertices, pVtx, m_dwSizeVertices);

	m_pVB->Unlock();

	return 0;
}

void CMain::Destroy()
{
	SAFE_RELEASE( m_pVB );
}


INT CMain::FrameMove()
{
	return 0;
}


INT CMain::Render()
{
	if( NULL == m_pd3dDevice )
		return -1;

	m_pd3dDevice->Clear( 0, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, 0xFF006699, 1.f, 0 );

	if( FAILED( m_pd3dDevice->BeginScene() ) )
		return -1;



	float	fPointSize = 40.F;
	m_pd3dDevice ->SetRenderState( D3DRS_POINTSIZE, *((DWORD*)&fPointSize));

	
	m_pd3dDevice->SetStreamSource( 0, m_pVB, 0, sizeof(VtxRHWD) );
	m_pd3dDevice->SetFVF( FVF_VTXDRHW );
	m_pd3dDevice->DrawPrimitive( D3DPT_POINTLIST, 0, 6);


	
	
	// End the scene
	m_pd3dDevice->EndScene();

	m_pd3dDevice->Present( NULL, NULL, NULL, NULL );							// ���������� �ĸ���۸� ������۷� ��ü�Ѵ�.( flipping)

	return 0;
}
// Interface for the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _MAIN_H_
#define _MAIN_H_


LRESULT WINAPI WndProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam );



// ���� ����ü
struct VtxRHWD
{
    Vector3	p;			// ��ġ
	float	rhw;		// reciprocal homogeneous w
    DWORD	color;		// ����

	VtxRHWD(){}
	VtxRHWD(float X, float Y, float Z, float RHW, DWORD COLOR)
	{
		p.x = X;
		p.y = Y;
		p.z = Z;
		
		rhw = RHW;
		color = COLOR;
	}


	VtxRHWD(Vector3 P, float RHW, DWORD COLOR)
	{
		p = P;
		rhw = RHW;
		color = COLOR;
	}
};



// Our custom FVF, which describes our custom vertex structure
#define D3DFVF_VTXST (D3DFVF_XYZRHW|D3DFVF_DIFFUSE)


class CMain
{
public:
	HINSTANCE				m_hInst			;
	HWND					m_hWnd			;
	LPDIRECT3D9             m_pD3D			;									// D3D
	LPDIRECT3DDEVICE9       m_pd3dDevice	;									// Device

public:
	LPDIRECT3DVERTEXBUFFER9 m_pVB			;									// ���� ����

public:
	INT		Init();
	void	Destroy();
	void	Render();

	INT		FrameMove();

	CMain();
	virtual ~CMain();

	INT		Create( HINSTANCE hInst);
	INT		Run();
	void	Cleanup();
	
	LRESULT MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam );
};

extern CMain*	g_pApp;

#endif

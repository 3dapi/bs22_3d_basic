#ifndef _MCMATH_H_
#define _MCMATH_H_

#include <math.h>

struct Vector3
{
	union
	{
		struct
		{
			float	x;
			float	y;
			float	z;
		};
		
		float m[3];
	};
	
	
	Vector3()				{					x = 0;	y = 0;			z = 0;		}
	Vector3(const float* v)	{	if(!v) return;	x = v[0];	y = v[1];	z = v[2];	}
	Vector3(const Vector3& v){					x = v.x;	y = v.y;	z = v.z;	}
	
	Vector3(const Vector3* v){	if(!v) 	return;	x = v->x;	y = v->y;	z = v->z;	}
	Vector3(float X, float Y, float Z) : x(X), y(Y), z(Z)	{}
	
	operator float*()			{	return(float*)&x;		}
	operator const float*() const{	return(const float*)&x;	}
	
	float& operator[](INT n){		return *((&x)+ n);		}
	
	// assignment operators
	Vector3& operator +=(const Vector3& v){	x += v.x; y += v.y; z += v.z; return *this;	}
	Vector3& operator -=(const Vector3& v){ x -= v.x; y -= v.y;	z -= v.z; return *this;	}
	Vector3& operator *=(float v)		{	x *= v;	y *= v;	z *= v;		  return *this;	}
	Vector3& operator /=(float v)		{	v=1.f/v; x*=v; y*=v; z *= v;  return *this;	}
	
	
	Vector3 operator +() const	{	return *this;				}
	Vector3 operator -() const	{	return Vector3(-x, -y, -z);	}
	

	Vector3 operator +(const Vector3& v) const	{	return Vector3(x + v.x, y + v.y, z + v.z);	}
	Vector3 operator -(const Vector3& v) const	{	return Vector3(x - v.x, y - v.y, z - v.z);	}
	Vector3 operator *(float v) const			{	return Vector3(x * v, y * v, z * v);			}
	Vector3 operator /(float v) const{ v = 1.f/v;	return Vector3(x * v, y * v, z * v);			}
	
	friend Vector3 operator *(float f, const Vector3& v){			return Vector3(f * v.x, f * v.y, f * v.z);	}
	friend Vector3 operator /(float f, const Vector3& v){f=1.f/f;	return Vector3(f * v.x, f * v.y, f * v.z);	}
	
	BOOL operator ==(const Vector3& v) const	{	return x == v.x && y == v.y && z == v.z;	}
	BOOL operator !=(const Vector3& v) const	{	return x != v.x || y != v.y || z != v.z;	}
	
	// Dot Product
	float operator *(const Vector3& v)
	{
		return x * v.x + y * v.y + z * v.z;
	}
	
	
	// Dot Product
	friend float operator *(const Vector3& v1, const Vector3& v2)
	{
		return v1.x * v2.x + v1.y * v2.y + v1.z * v2.z;
	}
	
	// Cross Product
	Vector3 operator ^(const Vector3& v)
	{
		return Vector3(y * v.z  -  z * v.y
					, z * v.x  -  x * v.z
					, x * v.y  -  y * v.x	);
	}

	// Cross Product
	friend Vector3 operator ^(const Vector3& v1, const Vector3& v2)
	{
		return Vector3(v1.y * v2.z  -  v1.z * v2.y
				, v1.z * v2.x  -  v1.x * v2.z
				, v1.x * v2.y  -  v1.y * v2.x	);
	}
	
	
	// Transform: vector * Matrix
	Vector3 operator *(const float* v)
	{
		float X = x * v[0] + y * v[4] + z * v[ 8] + v[12];
		float Y = x * v[1] + y * v[5] + z * v[ 9] + v[13];
		float Z = x * v[2] + y * v[6] + z * v[10] + v[14];
		float W = x * v[3] + y * v[7] + z * v[11] + v[15];
		
		W = 1.F/W;
		
		return Vector3(X * W, Y * W, Z* W);
	}
	
	// Transform: Matrix * vector;
	friend Vector3 operator *(const float* v1, const Vector3& v2)
	{
		float X = v2.x * v1[ 0] + v2.y * v1[ 1] + v2.z * v1[ 2] + v1[ 3];
		float Y = v2.x * v1[ 4] + v2.y * v1[ 5] + v2.z * v1[ 6] + v1[ 7];
		float Z = v2.x * v1[ 8] + v2.y * v1[ 9] + v2.z * v1[10] + v1[11];
		float W = v2.x * v1[12] + v2.y * v1[13] + v2.z * v1[14] + v1[15];
		
		W = 1.F/W;
		
		return Vector3(X * W, Y * W, Z* W);
	}
	
	
	// Length
	float Length()
	{
		return sqrtf(x*x + y*y + z*z);
	}
	
	// Length Square
	float LengthSq()
	{
		return(x*x + y*y + z*z);
	}
	
	
	Vector3 Normalize()
	{
		float l  = this->Length();
		if(l == 0)
			return *this;
		
		l = 1.f/l;
		x *= l;	y *= l;	z *= l;
		
		return *this;
	}
	
	
	Vector3 Normalize(const Vector3* v)
	{
		float l  = 0;
		
		*this = v;
		l  = this->Length();
		
		if(l == 0)
			return *this;
		
		l = 1.f/l;
		x *= l;	y *= l;	z *= l;
		
		return *this;
	}
	
	
	Vector3 Cross(const Vector3* v1, const Vector3* v2)
	{
		x  = (v1->y * v2->z  -  v1->z * v2->y);
		y  = (v1->z * v2->x  -  v1->x * v2->z);
		z  = (v1->x * v2->y  -  v1->y * v2->x);
		
		return *this;
	}
	
	
};


inline float	Vector3Dot(const Vector3* p1, const Vector3* p2)
{
	return (p1->x * p2->x + p1->y * p2->y + p1->z * p2->z);
}

inline Vector3	Vector3Normalize(const Vector3* p1)
{
	float fL = sqrtf(p1->x * p1->x  +  p1->y * p1->y  +  p1->z * p1->z);
	
	fL = 1.f/fL;
	
	return Vector3(p1->x * fL, p1->y * fL, p1->z * fL);
}


inline Vector3	Vector3Cross(const Vector3* p1, const Vector3* p2)
{
	return Vector3(	p1->y * p2->z  - p1->z * p2->y
		,	p1->z * p2->x  - p1->x * p2->z
		,	p1->x * p2->y  - p1->y * p2->x);
}


struct Matrix
{
	union
	{
		struct
		{
			float	_11, _12, _13, _14;
			float	_21, _22, _23, _24;
			float	_31, _32, _33, _34;
			float	_41, _42, _43, _44;
		};
		
		float m[4][4];
	};
	
	
	Matrix()
	{
		_11=1.f, _12=0.f, _13=0.f, _14=0.f;
		_21=0.f, _22=1.f, _23=0.f, _24=0.f;
		_31=0.f, _32=0.f, _33=1.f, _34=0.f;
		_41=0.f, _42=0.f, _43=0.f, _44=1.f;
	}
	
	operator float*()
	{
		return (float*)&_11;
	}
};

inline Matrix MatrixMulti(Matrix* p1, Matrix* p2)
{
	Matrix mat;
	
	for(int i=0; i<4; ++i)
	{
		for(int j=0; j<4; ++j)
		{
			for(int k=0; i<4; ++k)
			{
				mat.m[i][j] = p1->m[i][k] * p2->m[k][j];
			}
		}
	}
	
	return mat;
}


inline void MatrixIdentity(Matrix& p)
{
	memset(&p, 0, sizeof(Matrix));
	
	for(int i=0; i<4; ++i)
	{
		p.m[i][i] = 1.f;
	}
}



#endif


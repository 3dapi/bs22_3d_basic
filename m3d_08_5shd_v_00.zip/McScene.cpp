// Implementation of the CMcScene class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMcScene::CMcScene()
{
	m_pDev		= NULL;
	m_pVtx		= NULL;
}


CMcScene::~CMcScene()
{
	Destroy();
}

void CMcScene::Destroy()
{
	SAFE_DELETE_ARRAY(	m_pVtx	);
}


INT CMcScene::Create(LPDIRECT3DDEVICE9 pDev)
{
	HRESULT hr=-1;
	INT		i;

	m_pDev = pDev;


	m_pVtx = new Vtx[50*2];

    for(i=0; i<50; i++ )
    {
        FLOAT theta = (2*D3DX_PI*i)/(50-1);
        m_pVtx[2*i+1].p	= D3DXVECTOR3( sinf(theta),-1.0f, cosf(theta) );
        m_pVtx[2*i+0].p	= D3DXVECTOR3( sinf(theta), 1.0f, cosf(theta) );

		m_pVtx[2*i+0].p	*= 100;
        m_pVtx[2*i+1].p	*= 100;

		m_pVtx[2*i+0].p.y += 80;
		m_pVtx[2*i+1].p.y += 80;
    }



	// ������ ȭ�鿡 ���� ������ ���´�. ȭ�� ������ ������� ����̽��� �����
	// ������ �ڵ��� ã�´�.
	D3DDEVICE_CREATION_PARAMETERS Parameters;
	m_pDev->GetCreationParameters(&Parameters);

	// �����쿡 �ش��ϴ� ȭ�� ������ ��´�.
	RECT rc;
	GetClientRect(Parameters.hFocusWindow, &rc);

	FLOAT	sx = FLOAT(rc.right - rc.left);
	FLOAT	sy = FLOAT(rc.bottom- rc.top );



	m_pRhw[0].p = D3DXVECTOR4(  0, sy, 0.0f, 1.0f );
	m_pRhw[1].p = D3DXVECTOR4(  0,  0, 0.0f, 1.0f );
	m_pRhw[2].p = D3DXVECTOR4( sx, sy, 0.0f, 1.0f );
	m_pRhw[3].p = D3DXVECTOR4( sx,  0, 0.0f, 1.0f );

	m_pRhw[0].d = 0xAfFF0000;
	m_pRhw[1].d = 0xAf00FF00;
	m_pRhw[2].d = 0xAf0000FF;
	m_pRhw[3].d = 0xAfFF00FF;

	return 0;
}


INT CMcScene::FrameMove()
{
	CLcInput*	pInput = GMAIN->GetInput();
	
	if(pInput->KeyState(VK_UP))
		m_mtObject._43 +=1.f;

	if(pInput->KeyState(VK_DOWN))
		m_mtObject._43 -=1.f;

	if(pInput->KeyState(VK_RIGHT))
		m_mtObject._41 +=1.f;

	if(pInput->KeyState(VK_LEFT))
		m_mtObject._41 -=1.f;

	return 0;
}


void CMcScene::Render()
{
	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
	m_pDev->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE );
	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );
	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE );
	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_MODULATE );
	
	
	m_pDev->SetRenderState( D3DRS_LIGHTING, FALSE );
	m_pDev->SetRenderState( D3DRS_FOGENABLE, FALSE );




	m_pDev->SetRenderState( D3DRS_ZWRITEENABLE,  FALSE );			// Z-buffer�� �������� �ʴ´�.
	m_pDev->SetRenderState( D3DRS_COLORWRITEENABLE, FALSE);			// ���� ���۸� �������� �ʴ´�.

	// ���� �ո� ����
	m_pDev->SetRenderState( D3DRS_STENCILENABLE, TRUE );			// ���ٽ� Ȱ��ȭ
	m_pDev->SetRenderState( D3DRS_STENCILREF, 0x1 );
	m_pDev->SetRenderState( D3DRS_STENCILMASK, 0xffffffff );
	m_pDev->SetRenderState( D3DRS_STENCILWRITEMASK, 0xffffffff );
	m_pDev->SetRenderState( D3DRS_STENCILFUNC, D3DCMP_ALWAYS );		// �׽�Ʈ�� ������ ���

	m_pDev->SetRenderState( D3DRS_STENCILZFAIL,	D3DSTENCILOP_KEEP);
	m_pDev->SetRenderState( D3DRS_STENCILFAIL,	D3DSTENCILOP_KEEP);
	m_pDev->SetRenderState( D3DRS_STENCILPASS,  D3DSTENCILOP_INCR);	// ���ٽ� ���� 1 ����

	// ���� �ո� �׸���
	m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);
	m_pDev->SetTexture(0, NULL);
	m_pDev->SetFVF(Vtx::FVF);
	m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2*50-2, m_pVtx, sizeof(Vtx));


	// ���� �޸� ����
	m_pDev->SetRenderState( D3DRS_STENCILFUNC, D3DCMP_ALWAYS);		// �׽�Ʈ�� ������ ���
	m_pDev->SetRenderState( D3DRS_STENCILZFAIL,	D3DSTENCILOP_KEEP);
	m_pDev->SetRenderState( D3DRS_STENCILFAIL,	D3DSTENCILOP_KEEP);
	m_pDev->SetRenderState( D3DRS_STENCILPASS,  D3DSTENCILOP_DECR);	// ���ٽ� ���� 1 ����

	// ���� �޸� �׸���
	m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_CW);
	m_pDev->SetTexture(0, NULL);
	m_pDev->SetFVF(Vtx::FVF);
	m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2*50-2, m_pVtx, sizeof(Vtx));


	m_pDev->SetRenderState( D3DRS_COLORWRITEENABLE, 0xF);
	m_pDev->SetRenderState( D3DRS_ZWRITEENABLE,     TRUE );
	m_pDev->SetRenderState( D3DRS_CULLMODE,  D3DCULL_CCW );



	// RHW�� ȭ�� ��ü�� �׸���.
	m_pDev->SetRenderState( D3DRS_STENCILENABLE,    TRUE );

	m_pDev->SetRenderState( D3DRS_STENCILREF,  0x1 );
	m_pDev->SetRenderState( D3DRS_STENCILFUNC, D3DCMP_LESSEQUAL);	// 1 �� ���ٽ� ���� ��
	m_pDev->SetRenderState( D3DRS_STENCILPASS, D3DSTENCILOP_KEEP );

	m_pDev->SetTexture(0, NULL);
	m_pDev->SetFVF( VtxRHWD::FVF );
	m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLESTRIP, 2, m_pRhw, sizeof(VtxRHWD) );


	m_pDev->SetRenderState( D3DRS_STENCILENABLE,    FALSE );
}


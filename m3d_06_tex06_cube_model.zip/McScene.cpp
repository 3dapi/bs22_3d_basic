// Implementation of the CMcScene class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMcScene::CMcScene()
{
	m_pDev	= NULL;

	m_pVtx	= NULL;
	m_pIdx	= NULL;
	m_pTx	= NULL;
}

CMcScene::~CMcScene()
{
	Destroy();
}

INT CMcScene::Create(LPDIRECT3DDEVICE9 pDev)
{
	m_pDev	= pDev;

	m_pVtx	= new VtxNUV1[24];

	float	fSize = 10;

	m_pVtx[ 0] = VtxNUV1(-1.f, -1.f, -1.f, 0.f, 0.f, -1.f,  0.f, 1.f);
	m_pVtx[ 1] = VtxNUV1(-1.f,  1.f, -1.f, 0.f, 0.f, -1.f,  0.f, 0.f);
	m_pVtx[ 2] = VtxNUV1( 1.f,  1.f, -1.f, 0.f, 0.f, -1.f,  1.f, 0.f);
	m_pVtx[ 3] = VtxNUV1( 1.f, -1.f, -1.f, 0.f, 0.f, -1.f,  1.f, 1.f);

	// the back face vertex data
	m_pVtx[ 4] = VtxNUV1(-1.f, -1.f, 1.f, 0.f, 0.f, 1.f,  0.f, 1.f);
	m_pVtx[ 5] = VtxNUV1( 1.f, -1.f, 1.f, 0.f, 0.f, 1.f,  0.f, 0.f);
	m_pVtx[ 6] = VtxNUV1( 1.f,  1.f, 1.f, 0.f, 0.f, 1.f,  1.f, 0.f);
	m_pVtx[ 7] = VtxNUV1(-1.f,  1.f, 1.f, 0.f, 0.f, 1.f,  1.f, 1.f);

	// the top face vertex data
	m_pVtx[ 8] = VtxNUV1(-1.f, 1.f, -1.f, 0.f, 1.f, 0.f, 0.f, 1.f);
	m_pVtx[ 9] = VtxNUV1(-1.f, 1.f,  1.f, 0.f, 1.f, 0.f, 0.f, 0.f);
	m_pVtx[10] = VtxNUV1( 1.f, 1.f,  1.f, 0.f, 1.f, 0.f, 1.f, 0.f);
	m_pVtx[11] = VtxNUV1( 1.f, 1.f, -1.f, 0.f, 1.f, 0.f, 1.f, 1.f);

	// the bottom face vertex data
	m_pVtx[12] = VtxNUV1(-1.f, -1.f, -1.f, 0.f, -1.f, 0.f, 0.f, 1.f);
	m_pVtx[13] = VtxNUV1( 1.f, -1.f, -1.f, 0.f, -1.f, 0.f, 0.f, 0.f);
	m_pVtx[14] = VtxNUV1( 1.f, -1.f,  1.f, 0.f, -1.f, 0.f, 1.f, 0.f);
	m_pVtx[15] = VtxNUV1(-1.f, -1.f,  1.f, 0.f, -1.f, 0.f, 1.f, 1.f);

	// the left face vertex data
	m_pVtx[16] = VtxNUV1(-1.f, -1.f,  1.f, -1.f, 0.f, 0.f, 0.f, 1.f);
	m_pVtx[17] = VtxNUV1(-1.f,  1.f,  1.f, -1.f, 0.f, 0.f, 0.f, 0.f);
	m_pVtx[18] = VtxNUV1(-1.f,  1.f, -1.f, -1.f, 0.f, 0.f, 1.f, 0.f);
	m_pVtx[19] = VtxNUV1(-1.f, -1.f, -1.f, -1.f, 0.f, 0.f, 1.f, 1.f);

	// the right face vertex data
	m_pVtx[20] = VtxNUV1( 1.f, -1.f, -1.f, 1.f, 0.f, 0.f, 0.f, 1.f);
	m_pVtx[21] = VtxNUV1( 1.f,  1.f, -1.f, 1.f, 0.f, 0.f, 0.f, 0.f);
	m_pVtx[22] = VtxNUV1( 1.f,  1.f,  1.f, 1.f, 0.f, 0.f, 1.f, 0.f);
	m_pVtx[23] = VtxNUV1( 1.f, -1.f,  1.f, 1.f, 0.f, 0.f, 1.f, 1.f);

	for(int i=0; i<24; ++i)
	{
		m_pVtx[i].p *=fSize;
	}

	
	m_pIdx = new VtxIdx[12];

	// the front face index data
	m_pIdx[0] = VtxIdx(0, 1, 2);
	m_pIdx[1] = VtxIdx(0, 2, 3);

	// the back face index data
	m_pIdx[2] = VtxIdx(4, 5, 6);
	m_pIdx[3] = VtxIdx(4, 6, 7);

	// the top face index data
	m_pIdx[4] = VtxIdx( 8,  9, 10);
	m_pIdx[5] = VtxIdx( 8, 10, 11);

	// the bottom face index data
	m_pIdx[6] = VtxIdx(12, 13, 14);
	m_pIdx[7] = VtxIdx(12, 14, 15);

	// the left face index data
	m_pIdx[8] = VtxIdx(16, 17, 18);
	m_pIdx[9] = VtxIdx(16, 18, 19);

	// the right face index data
	m_pIdx[10] = VtxIdx(20, 21, 22);
	m_pIdx[11] = VtxIdx(20, 22, 23);


	D3DXCreateTextureFromFile(m_pDev, "Texture/dx5_logo.bmp", &m_pTx);

	return 0;
}


void CMcScene::Destroy()
{
	SAFE_DELETE(	m_pVtx	);
	SAFE_DELETE(	m_pIdx	);
	SAFE_RELEASE(	m_pTx	);
}

INT CMcScene::FrameMove()
{
	return 0;
}

void CMcScene::Render()
{
	m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
	m_pDev->SetRenderState(D3DRS_LIGHTING, FALSE);
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);

	m_pDev->SetTexture(0, m_pTx);

	m_pDev->SetFVF(VtxNUV1::FVF);
	m_pDev->DrawIndexedPrimitiveUP(D3DPT_TRIANGLELIST
									, 0
									, 24
									, 12
									, m_pIdx
									, D3DFMT_INDEX16
									, m_pVtx
									, sizeof(VtxNUV1));
}



#ifndef _VTXFMT_H_
#define _VTXFMT_H_


struct VtxD
{
	D3DXVECTOR3	p;
	DWORD		d;		// Diffuse Color
	
	VtxD()						: p(0,0,0), d(0xFFFFFFFF){}
	VtxD(FLOAT X,FLOAT Y,FLOAT Z,DWORD D) : p(X,Y,Z),d(D){}

	enum { FVF = (D3DFVF_XYZ|D3DFVF_DIFFUSE),};
};



#endif
// Implementation of the CMcScene class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMcScene::CMcScene()
{
	m_pDev	= NULL;
	
	m_nVtx	= 0;
	m_nIdx	= 0;
	m_pVtx	= NULL;
	m_pIdx	= NULL;
	
	m_pTxTiger	= NULL;
	m_pTxLogo	= NULL;
	
	
	m_nType	= 2;
}

CMcScene::~CMcScene()
{
	Destroy();
}

INT CMcScene::Create(LPDIRECT3DDEVICE9 pDev)
{
	HRESULT hr;
	m_pDev	= pDev;
	
	
	LPD3DXMESH		pMdlS=NULL;
	if( FAILED( D3DXLoadMeshFromX( "xFile/Tiger.x",	D3DXMESH_SYSTEMMEM,	m_pDev, NULL, NULL, NULL, NULL, &pMdlS ) ) )
		return -1;
	
	D3DXCreateTextureFromFile(m_pDev, "xFile/tiger.bmp", &m_pTxTiger);
	
	
	LPD3DXMESH pMdlD=NULL;
	hr = pMdlS->CloneMeshFVF(D3DXMESH_SYSTEMMEM, VtxUV1::FVF, m_pDev, &pMdlD);
	pMdlS->Release();
	
	m_nVtx = pMdlD->GetNumVertices();
	m_nIdx = pMdlD->GetNumFaces();
	
	//	DWORD dFVF = pMdlD->GetFVF();
	
	m_pVtx = new VtxUV1[m_nVtx];
	m_pIdx = new VtxIdx[m_nIdx];
	
	void* pVtx= NULL;
	hr = pMdlD->LockVertexBuffer(0, &pVtx);
	
	memcpy(m_pVtx, pVtx, m_nVtx * sizeof(VtxUV1));
	
	hr = pMdlD->UnlockVertexBuffer();
	
	void* pIdx= NULL;
	hr = pMdlD->LockIndexBuffer(0, &pIdx);
	
	memcpy(m_pIdx, pIdx, m_nIdx * sizeof(VtxIdx));
	
	hr = pMdlD->UnlockIndexBuffer();
	
	pMdlD->Release();
	
	
	float fSCale=15;
	for(int i=0; i<m_nVtx; ++i)
	{
		m_pVtx[i].p *= fSCale;
	}
	
	D3DXCreateTextureFromFile(m_pDev, "Texture/dx5_logo.bmp", &m_pTxLogo);
	
	return 0;
}


void CMcScene::Destroy()
{
	SAFE_DELETE_ARRAY(	m_pVtx		);
	SAFE_DELETE_ARRAY(	m_pIdx		);
	SAFE_RELEASE(	m_pTxTiger	);
	SAFE_RELEASE(	m_pTxLogo	);
}

INT CMcScene::FrameMove()
{
	if(::GetAsyncKeyState('1') & 0X8000)
	{
		m_nType	= 1;
	}
	
	if(::GetAsyncKeyState('2') & 0X8000)
	{
		m_nType	= 2;
	}
	
	
	
	return 0;
}

void CMcScene::Render()
{
	m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
	m_pDev->SetRenderState(D3DRS_LIGHTING, FALSE);
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
	
	
	if(1 == m_nType)
	{
		D3DXMATRIX mtTex;
		D3DXMATRIX mtPrj;
		
		m_pDev->GetTransform( D3DTS_PROJECTION, &mtPrj );
		
		mtTex	= D3DXMATRIX(0.5F,     0,  0,	0,
			0, -0.5F,  0,	0,
			0,     0,  1,	0,
			0.5F,  0.5F,  0,	1
			);
		mtTex = mtPrj * mtTex;
		
		m_pDev->SetTransform( D3DTS_TEXTURE0, &mtTex );
		m_pDev->SetTextureStageState( 0, D3DTSS_TEXTURETRANSFORMFLAGS, D3DTTFF_COUNT4 | D3DTTFF_PROJECTED );
		m_pDev->SetTextureStageState( 0, D3DTSS_TEXCOORDINDEX, D3DTSS_TCI_CAMERASPACEPOSITION );
		
		m_pDev->SetFVF(D3DFVF_XYZ);
		m_pDev->SetTexture(0, m_pTxLogo);
	}
	
	if(2 == m_nType)
	{
		m_pDev->SetFVF(VtxUV1::FVF);
		m_pDev->SetTexture(0, m_pTxTiger);
	}
	
	
	
	m_pDev->DrawIndexedPrimitiveUP(D3DPT_TRIANGLELIST
		, 0
		, m_nVtx
		, m_nIdx
		, m_pIdx
		, D3DFMT_INDEX16
		, m_pVtx
		, sizeof(VtxUV1));
	
	D3DXMATRIX mtI;
	D3DXMatrixIdentity(&mtI);
	m_pDev->SetTransform(D3DTS_TEXTURE0, &mtI);
	m_pDev->SetTexture(0, NULL);
	m_pDev->SetTextureStageState( 0, D3DTSS_TEXTURETRANSFORMFLAGS, D3DTTFF_DISABLE);
	m_pDev->SetTextureStageState( 0, D3DTSS_TEXCOORDINDEX, D3DTSS_TCI_PASSTHRU );
}



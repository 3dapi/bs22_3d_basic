// Interface for the CMcScene class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _McScene_H_
#define _McScene_H_

class CMcScene
{
protected:
	LPDIRECT3DDEVICE9		m_pDev;

	INT						m_nVtx;
	INT						m_nIdx;
	VtxUV1*					m_pVtx;
	VtxIdx*					m_pIdx;

	LPDIRECT3DTEXTURE9		m_pTxTiger;
	LPDIRECT3DTEXTURE9		m_pTxLogo;

	INT						m_nType;
	
public:
	CMcScene();
	virtual ~CMcScene();

	INT		Create(LPDIRECT3DDEVICE9 pDev);
	void	Destroy();

	INT		FrameMove();
	void	Render();
};

#endif
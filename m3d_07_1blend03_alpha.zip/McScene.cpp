// Implementation of the CMcScene class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMcScene::CMcScene()
{
	m_pDev	= NULL;
	m_pTex	= NULL;
}

CMcScene::~CMcScene()
{
	Destroy();
}

INT CMcScene::Create(LPDIRECT3DDEVICE9 pDev)
{
	m_pDev	= pDev;
	
	
	m_pVtx[0] = VtxDUV1(-6.f,  5.f, 5.f,    0.f, 0.f,  D3DXCOLOR(1,0,0,0));
	m_pVtx[1] = VtxDUV1( 6.f,  5.f, 5.f,    1.f, 0.f,  D3DXCOLOR(1,0,0,1));
	m_pVtx[2] = VtxDUV1( 6.f, -5.f, 5.f,    1.f, 1.f,  D3DXCOLOR(1,0,0,1));
	m_pVtx[3] = VtxDUV1(-6.f, -5.f, 5.f,    0.f, 1.f,  D3DXCOLOR(1,0,0,0));


	D3DXCreateTextureFromFile(m_pDev, "Texture/env3_alpha.png", &m_pTex);

	return 0;
}


void CMcScene::Destroy()
{
	SAFE_RELEASE(	m_pTex	);
}

INT CMcScene::FrameMove()
{
	return 0;
}

void CMcScene::Render()
{
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);

	m_pDev->SetRenderState(D3DRS_LIGHTING, FALSE);
	m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);


	// ���� �������� �� �ȵ� ��쿡�� ���� �ؽ�ó ó��
	// ����Ʈ ���� Ȯ���� ���� �Ѵ�.
	//
	DWORD v;
	m_pDev->GetTextureStageState(0, D3DTSS_ALPHAARG1, &v);		// Default�� Texture�� �Ǿ� ����
	m_pDev->GetTextureStageState(0, D3DTSS_ALPHAARG2, &v);		// Default�� Current�� �Ǿ� ����
	m_pDev->GetTextureStageState(0, D3DTSS_ALPHAOP, &v);		// Default�� SelectArg1���� �Ǿ� ����


	// Default ������ �����Ѵ�.
	m_pDev->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
	m_pDev->SetTextureStageState(0, D3DTSS_COLORARG2, D3DTA_DIFFUSE);
	m_pDev->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_MODULATE);

	m_pDev->SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
	m_pDev->SetTextureStageState(0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE);
	m_pDev->SetTextureStageState(0, D3DTSS_ALPHAOP,	 D3DTOP_MODULATE);



	m_pDev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	
	m_pDev->SetTexture(0, m_pTex);
	m_pDev->SetFVF(VtxDUV1::FVF);
	m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLEFAN, 2, m_pVtx, sizeof(VtxDUV1));


	m_pDev->SetTexture(0, NULL);

	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
	m_pDev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
}



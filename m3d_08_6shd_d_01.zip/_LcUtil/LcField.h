// Interface for the CLcField class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LcField_H_
#define _LcField_H_

class CLcField
{
public:
	struct VtxUV1
	{
		D3DXVECTOR3	p;

		FLOAT		u, v;

		VtxUV1() : p(0,0,0), u(0), v(0)	{}
		VtxUV1(FLOAT X, FLOAT Y, FLOAT Z, FLOAT U,FLOAT V) : p(X,Y,Z), u(U), v(V){}

		enum	{FVF = (D3DFVF_XYZ|D3DFVF_TEX1),};
	};

protected:
	LPDIRECT3DDEVICE9	 m_pDev;
	LPDIRECT3DTEXTURE9	m_pTex;

	VtxUV1		m_pVtx[4];

public:
	CLcField();
	virtual ~CLcField();

	INT		Create(LPDIRECT3DDEVICE9 pDev);
	void	Destroy();

	INT		FrameMove();
	void	Render();
};

#endif
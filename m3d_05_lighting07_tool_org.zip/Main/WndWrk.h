// Interface for the CWndWrk class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _WNDWRK_H_
#define _WNDWRK_H_


class CWndWrk
{
public:
	HWND		m_hWnd		;
	HWND		m_hWndPrn	;

public:
	DCLR		m_xcAmb		;
	DMTL		m_Mtl		;
	
	DWORD		m_dShade	;
	DWORD		m_dFill		;
	
	DWORD		m_bLighting	;
	DWORD		m_bNormalize;
	DWORD		m_bSpecular	;
	DWORD		m_bDithering;
	DWORD		m_bColorVtx	;

	


public:
	CLSS_DLG_DECLEAR( CWndWrk );

	INT		Init();
	void	Destroy();

	INT		FrameMove();
	void	SetState();

	INT		Create(HWND hWnd);
	LRESULT	MsgPrc(HWND, UINT, WPARAM, LPARAM);
};

#endif
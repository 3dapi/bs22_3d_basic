// Implementation of the CDlgLgt class.
//
//////////////////////////////////////////////////////////////////////


#include "../_StdAfx.h"


CLSS_DLG_DEFINE(CWndLgt, MsgPrc);


INT CWndLgt::Init()
{
	m_hWnd	= 0;
	m_bLg	= TRUE;
	
	return 0;
}


INT CWndLgt::Create(HWND hWnd)
{
	RECT	rt1;
	RECT	rt2;
	INT		iWidth;
	INT		iHeight;
	INT		iX;
	INT		iY;
	
	if(m_hWnd)
		return 0;

	
	m_hWPrn= hWnd;
	m_hWnd = CreateDialog( GetModuleHandle(NULL),MAKEINTRESOURCE(IDD_LGT), m_hWPrn, CLSS_DLG_WNDPROC(CWndLgt));

	
	// 1. Setting Lighting
	CHECKBOX_SETVALUE(m_hWnd, IDC_LGT_ENABLE, TRUE);


	// 2. Setting Window Rect

	GetWindowRect(m_hWPrn, &rt1);
	GetWindowRect(m_hWnd, &rt2);
	
	iWidth = rt2.right - rt2.left;
	iHeight=  rt2.bottom- rt2.top;

	iX = rt1.left;
	iY = rt1.bottom;
	
	MoveWindow(m_hWnd, iX, iY, iWidth, iHeight, TRUE);
	ShowWindow(m_hWnd, SW_SHOW);


	m_Lgt.Type			=  (D3DLIGHTTYPE)3;

	m_Lgt.Ambient.r		=  0.000f;
	m_Lgt.Ambient.g		=  0.000f;
	m_Lgt.Ambient.b		=  0.000f;
	m_Lgt.Ambient.a		=  1.000f;

	m_Lgt.Diffuse.r		=  1.000f;
	m_Lgt.Diffuse.g		=  1.000f;
	m_Lgt.Diffuse.b		=  1.000f;
	m_Lgt.Diffuse.a		=  1.000;

	m_Lgt.Specular.r	=  1.000f;
	m_Lgt.Specular.g	=  1.000f;
	m_Lgt.Specular.b	=  1.000f;
	m_Lgt.Specular.a	=  1.000f;

	m_Lgt.Position.x	=  0.62f;
	m_Lgt.Position.y	=  0.75f;
	m_Lgt.Position.z	=  -0.18f;

	m_Lgt.Direction.x	=  -0.6200f;
	m_Lgt.Direction.y	=  -0.7500f;
	m_Lgt.Direction.z	=  0.1800f;

	m_Lgt.Range			=  1000.00f;
	m_Lgt.Falloff		=  1.000f;

	m_Lgt.Attenuation0	=  1.0000f;
	m_Lgt.Attenuation1	=  2.0000f;
	m_Lgt.Attenuation2	=  3.0000f;

	m_Lgt.Theta			=  10.0000f;
	m_Lgt.Phi			=  30.0000f;

	DWORD	r, g, b;

	
	CheckRadioButton(m_hWnd, IDC_LGT_TYPE_PNT, IDC_LGT_TYPE_PNT+2, IDC_LGT_TYPE_PNT+ m_Lgt.Type - 1);

	r = McUtil_D3DColorGetR(D3DXCOLOR(m_Lgt.Ambient));
	g = McUtil_D3DColorGetG(D3DXCOLOR(m_Lgt.Ambient));
	b = McUtil_D3DColorGetB(D3DXCOLOR(m_Lgt.Ambient));
	SetDlgItemInt(m_hWnd, IDC_LGT_AMBI_R, r,0);
	SetDlgItemInt(m_hWnd, IDC_LGT_AMBI_G, g,0);
	SetDlgItemInt(m_hWnd, IDC_LGT_AMBI_B, b,0);
	McUtil_FillRect(GetDlgItem(m_hWnd, IDC_LGT_AMBI_C), RGB(r, g, b));
	
	r = McUtil_D3DColorGetR(D3DXCOLOR(m_Lgt.Diffuse));
	g = McUtil_D3DColorGetG(D3DXCOLOR(m_Lgt.Diffuse));
	b = McUtil_D3DColorGetB(D3DXCOLOR(m_Lgt.Diffuse));
	SetDlgItemInt(m_hWnd, IDC_LGT_DIFF_R, r,0);
	SetDlgItemInt(m_hWnd, IDC_LGT_DIFF_G, g,0);
	SetDlgItemInt(m_hWnd, IDC_LGT_DIFF_B, b,0);
	McUtil_FillRect(GetDlgItem(m_hWnd, IDC_LGT_DIFF_C), RGB(r, g, b));
	
	r = McUtil_D3DColorGetR(D3DXCOLOR(m_Lgt.Specular));
	g = McUtil_D3DColorGetG(D3DXCOLOR(m_Lgt.Specular));
	b = McUtil_D3DColorGetB(D3DXCOLOR(m_Lgt.Specular));
	SetDlgItemInt(m_hWnd, IDC_LGT_SPEC_R, r,0);
	SetDlgItemInt(m_hWnd, IDC_LGT_SPEC_G, g,0);
	SetDlgItemInt(m_hWnd, IDC_LGT_SPEC_B, b,0);
	McUtil_FillRect(GetDlgItem(m_hWnd, IDC_LGT_SPEC_C), RGB(r, g, b));


	SetDlgItemFlt(m_hWnd, IDC_LGT_POS_X,	m_Lgt.Position.x, 2);
	SetDlgItemFlt(m_hWnd, IDC_LGT_POS_Y,	m_Lgt.Position.y, 2);
	SetDlgItemFlt(m_hWnd, IDC_LGT_POS_Z,	m_Lgt.Position.z, 2);

	SetDlgItemFlt(m_hWnd, IDC_LGT_DIR_X,	m_Lgt.Direction.x, 4);
	SetDlgItemFlt(m_hWnd, IDC_LGT_DIR_Y,	m_Lgt.Direction.y, 4);
	SetDlgItemFlt(m_hWnd, IDC_LGT_DIR_Z,	m_Lgt.Direction.z, 4);

	SetDlgItemFlt(m_hWnd, IDC_LGT_RANGE,	m_Lgt.Range, 2);
	SetDlgItemFlt(m_hWnd, IDC_LGT_FALL,		m_Lgt.Falloff, 4);
	
	SetDlgItemFlt(m_hWnd, IDC_LGT_ATTN0,	m_Lgt.Attenuation0, 5);
	SetDlgItemFlt(m_hWnd, IDC_LGT_ATTN1,	m_Lgt.Attenuation1, 5);
	SetDlgItemFlt(m_hWnd, IDC_LGT_ATTN2,	m_Lgt.Attenuation2, 5);

	SetDlgItemFlt(m_hWnd, IDC_LGT_THETA,	m_Lgt.Theta, 7);
	SetDlgItemFlt(m_hWnd, IDC_LGT_PHI,		m_Lgt.Phi, 7);

	return 0;
}


void CWndLgt::Destroy()
{
	SAFE_DESTROY_WIN(m_hWnd);
}



INT CWndLgt::FrameMove()
{
	DWORD	r, g, b;

	
	r = McUtil_D3DColorGetR(D3DXCOLOR(m_Lgt.Ambient));
	g = McUtil_D3DColorGetG(D3DXCOLOR(m_Lgt.Ambient));
	b = McUtil_D3DColorGetB(D3DXCOLOR(m_Lgt.Ambient));
	McUtil_FillRect(GetDlgItem(m_hWnd, IDC_LGT_AMBI_C), RGB(r, g, b));
	
	r = McUtil_D3DColorGetR(D3DXCOLOR(m_Lgt.Diffuse));
	g = McUtil_D3DColorGetG(D3DXCOLOR(m_Lgt.Diffuse));
	b = McUtil_D3DColorGetB(D3DXCOLOR(m_Lgt.Diffuse));
	McUtil_FillRect(GetDlgItem(m_hWnd, IDC_LGT_DIFF_C), RGB(r, g, b));
	
	r = McUtil_D3DColorGetR(D3DXCOLOR(m_Lgt.Specular));
	g = McUtil_D3DColorGetG(D3DXCOLOR(m_Lgt.Specular));
	b = McUtil_D3DColorGetB(D3DXCOLOR(m_Lgt.Specular));
	McUtil_FillRect(GetDlgItem(m_hWnd, IDC_LGT_SPEC_C), RGB(r, g, b));

	return 0;
}


void CWndLgt::SetState()
{
	for(int i=0; i<9; ++i)
		GDEVICE->LightEnable(i, FALSE);

	GDEVICE->LightEnable(0, m_bLg);
	GDEVICE->SetLight(0, &m_Lgt);
	GDEVICE->SetRenderState(D3DRS_LIGHTING, m_bLg);
}



LRESULT CWndLgt::MsgPrc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	WPARAM		wparHi = HIWORD(wParam);
	WPARAM		wparLo = LOWORD(wParam);

	switch( uMsg )
	{
		case WM_COMMAND:
		{
			switch(wparLo)
			{
				#define MSG_COL_SET(MSG_ID1, R_COLOR, MSG_ID2, MSG_ID3, MSG_ID4)	\
				case MSG_ID1 :														\
				{																	\
					switch(wparHi)													\
					{																\
						case EN_CHANGE:												\
						{															\
							DWORD ClrR = GetDlgItemInt(hWnd, MSG_ID2, 0, 0);		\
							DWORD ClrG = GetDlgItemInt(hWnd, MSG_ID3, 0, 0);		\
							DWORD ClrB = GetDlgItemInt(hWnd, MSG_ID4, 0, 0);		\
							DWORD dC1 = RGB(ClrR, ClrG, ClrB);						\
							R_COLOR	= D3DXCOLOR(D3DCOLOR_XRGB(ClrR, ClrG, ClrB));	\
																					\
							break;													\
						}															\
					}																\
																					\
					break;															\
				}

				#define GET_MSG_FLT(SET_VALUE, MSG_ID)					\
				case MSG_ID :												\
				{															\
					switch(wparHi)											\
					{														\
						case EN_CHANGE:										\
						{													\
							(SET_VALUE) = GetDlgItemFlt(hWnd, MSG_ID);		\
							break;											\
						}													\
					}														\
																			\
					break;													\
				}


				MSG_COL_SET( IDC_LGT_AMBI_R, m_Lgt.Ambient, IDC_LGT_AMBI_R, IDC_LGT_AMBI_G, IDC_LGT_AMBI_B);
				MSG_COL_SET( IDC_LGT_AMBI_G, m_Lgt.Ambient, IDC_LGT_AMBI_R, IDC_LGT_AMBI_G, IDC_LGT_AMBI_B);
				MSG_COL_SET( IDC_LGT_AMBI_B, m_Lgt.Ambient, IDC_LGT_AMBI_R, IDC_LGT_AMBI_G, IDC_LGT_AMBI_B);

				MSG_COL_SET( IDC_LGT_DIFF_R, m_Lgt.Diffuse, IDC_LGT_DIFF_R, IDC_LGT_DIFF_G, IDC_LGT_DIFF_B);
				MSG_COL_SET( IDC_LGT_DIFF_G, m_Lgt.Diffuse, IDC_LGT_DIFF_R, IDC_LGT_DIFF_G, IDC_LGT_DIFF_B);
				MSG_COL_SET( IDC_LGT_DIFF_B, m_Lgt.Diffuse, IDC_LGT_DIFF_R, IDC_LGT_DIFF_G, IDC_LGT_DIFF_B);

				MSG_COL_SET( IDC_LGT_SPEC_R, m_Lgt.Specular, IDC_LGT_SPEC_R, IDC_LGT_SPEC_G, IDC_LGT_SPEC_B);
				MSG_COL_SET( IDC_LGT_SPEC_G, m_Lgt.Specular, IDC_LGT_SPEC_R, IDC_LGT_SPEC_G, IDC_LGT_SPEC_B);
				MSG_COL_SET( IDC_LGT_SPEC_B, m_Lgt.Specular, IDC_LGT_SPEC_R, IDC_LGT_SPEC_G, IDC_LGT_SPEC_B);

				GET_MSG_FLT(m_Lgt.Position.x, IDC_LGT_POS_X);
				GET_MSG_FLT(m_Lgt.Position.y, IDC_LGT_POS_Y);
				GET_MSG_FLT(m_Lgt.Position.z, IDC_LGT_POS_Z);

				GET_MSG_FLT(m_Lgt.Direction.x, IDC_LGT_DIR_X);
				GET_MSG_FLT(m_Lgt.Direction.y, IDC_LGT_DIR_Y);
				GET_MSG_FLT(m_Lgt.Direction.z, IDC_LGT_DIR_Z);

				GET_MSG_FLT(m_Lgt.Range			, IDC_LGT_RANGE	);	
				GET_MSG_FLT(m_Lgt.Falloff			, IDC_LGT_FALL	);
				GET_MSG_FLT(m_Lgt.Attenuation0	, IDC_LGT_ATTN0	);
				GET_MSG_FLT(m_Lgt.Attenuation1	, IDC_LGT_ATTN1	);
				GET_MSG_FLT(m_Lgt.Attenuation2	, IDC_LGT_ATTN2	);
				GET_MSG_FLT(m_Lgt.Theta			, IDC_LGT_THETA	);
				GET_MSG_FLT(m_Lgt.Phi				, IDC_LGT_PHI	);


				case IDC_LGT_TYPE_PNT:
					m_Lgt.Type = D3DLIGHT_POINT;
					break;

				case IDC_LGT_TYPE_SPT:
					m_Lgt.Type = D3DLIGHT_SPOT;
					break;

				case IDC_LGT_TYPE_DIR:
					m_Lgt.Type = D3DLIGHT_DIRECTIONAL;
					break;


				case IDC_LGT_ENABLE:
				{
					m_bLg	= CHECKBOX_GETVALUE(hWnd, IDC_LGT_ENABLE);
					break;
				}
			}//switch

			break;
		}

	}

	return(FALSE);
}
// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#include "../_StdAfx.h"


CMain::CMain()
{
	strcpy(m_strClassName, "Mck");

	m_dwCreationW	=800;
	m_dwCreationH	=600;
	m_iScnPosX		=260;
	m_iScnPosY		=0;
	
	m_dRscIcon		= 32512;//IDI_APPLICATION;
	m_dRscMenu		= IDR_MENU;
	m_dRscAccel		= IDR_MAIN_ACCEL;

	m_dRscDevice	= IDM_CHANGEDEVICE;
	m_dRscToggle	= IDM_TOGGLEFULLSCREEN;
	m_dRscExit		= IDM_EXIT;


	m_pD3DXFont		= NULL;
	m_pInput		= NULL;
	m_pCam			= NULL;

	m_pGrid			= NULL;

	m_dFVF			= 0;
	m_TeapotO		= NULL;
	m_TeapotD		= NULL;
}


HRESULT CMain::Init()
{
	SAFE_NEWCREATE1(	m_pInput,	CLcInput,	m_hWnd	);
	SAFE_NEWCREATE1(	m_pCam,		CLcCam,		m_pd3dDevice);
	SAFE_NEWCREATE1(	m_pGrid,	CLcGrid,	m_pd3dDevice);

	m_pCam->SetParamView( D3DXVECTOR3(20.f, 20.f, -50.f )
						, D3DXVECTOR3( 5.f, 10.f,   0.f )
						, D3DXVECTOR3( 0.f,  1.f,   0.f ));

	m_pCam->SetParamProj(D3DX_PI/4.f, m_dwCreationW, m_dwCreationH, 1.f, 5000.f);

	m_WndWrk.Create(m_hWnd);
	m_WndLgt.Create(m_hWnd);
	SetFocus(GHWND);



	LPD3DXMESH		pMshS = NULL;
	LPD3DXBUFFER	pAdjS = NULL;
	LPD3DXBUFFER	pAdjD = NULL;
	
	::D3DXCreateTeapot(m_pd3dDevice, &pMshS, &pAdjS);
	::D3DXTessellateNPatches(pMshS
							, (DWORD*)pAdjS->GetBufferPointer()
							, 3.0f
							, true
							,	&m_TeapotO, &pAdjD);

	m_TeapotO->OptimizeInplace(D3DXMESHOPT_ATTRSORT
								, (DWORD*)pAdjD->GetBufferPointer()
								, NULL
								, NULL
								, NULL);

	pMshS->Release();
	pAdjS->Release();
	pAdjD->Release();

	MeshSetup( (D3DFVF_XYZ| D3DFVF_NORMAL) );

	D3DXFONT_DESC hFont =
	{
		14, 0
		, FW_BOLD, 1, FALSE
		, HANGUL_CHARSET
		, OUT_DEFAULT_PRECIS, ANTIALIASED_QUALITY, FF_DONTCARE
		, "����ü"
	};

	if( FAILED( D3DXCreateFontIndirect(m_pd3dDevice, &hFont, &m_pD3DXFont) ) )
		return -1;

	return S_OK;
}


HRESULT CMain::Destroy()
{
	SAFE_RELEASE( m_pD3DXFont	);
	SAFE_DELETE(	m_pInput	);
	SAFE_DELETE(	m_pCam		);
	SAFE_DELETE(	m_pGrid		);

	SAFE_DESTROY(	&m_WndWrk	);
	SAFE_DESTROY(	&m_WndLgt	);

	SAFE_RELEASE( m_TeapotO		);
	SAFE_RELEASE( m_TeapotD		);
	
	return S_OK;
}


HRESULT CMain::Restore()
{
	m_pD3DXFont->OnResetDevice();

	return S_OK;
}



HRESULT CMain::Invalidate()
{
	m_pD3DXFont->OnLostDevice();

	return S_OK;
}



HRESULT CMain::FrameMove()
{
	SAFE_FRMOV(	m_pInput	);

	HWND hWndFocus = GetFocus();

	if(m_hWnd == hWndFocus)
	{
		FLOAT	fElapsed = m_fElapsedTime;
		VEC3	vcDelta = m_pInput->GetMouseEps();

		FLOAT	fSpeedMov  = 200.f * fElapsed;
		FLOAT	fSpeedRot  =  0.1f;
		FLOAT	fSpeedWheel=  40.f * fElapsed;

		if(vcDelta.z !=0.f)
		{
			m_pCam->MoveForward(-vcDelta.z* fSpeedWheel, 1.f);
		}

		if(m_pInput->KeyPress('W'))					// W
		{
			m_pCam->MoveForward( fSpeedMov, 1.f);
		}

		if(m_pInput->KeyPress('S'))					// S
		{
			m_pCam->MoveForward(-fSpeedMov, 1.f);
		}

		if(m_pInput->KeyPress('A'))					// A
		{
			m_pCam->MoveSideward(-fSpeedMov);
		}

		if(m_pInput->KeyPress('D'))					// D
		{
			m_pCam->MoveSideward(fSpeedMov);
		}

		if(m_pInput->BtnPress(1))
		{
			m_pCam->Rotation(vcDelta.x, vcDelta.y, fSpeedRot);
		}
	}

	SAFE_FRMOV(	m_pCam		);


	if(this->IsWindowMode())
	{
		SAFE_FRMOV(	&m_WndWrk	);
		SAFE_FRMOV(	&m_WndLgt	);
	}


	return S_OK;
}




HRESULT CMain::Render()
{
	m_pCam->SetTransformViw();
	m_pCam->SetTransformPrj();
	
	m_WndLgt.SetState();
	m_WndWrk.SetState();

	m_pd3dDevice->Clear( 0L, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER|D3DCLEAR_STENCIL, 0xFF006699, 1.0f, 0L);
	
	if( FAILED( m_pd3dDevice->BeginScene() ) )
		return -1;


	SAFE_RENDER(	m_pGrid		);

	m_TeapotD->DrawSubset(0);

	::LcUtil_SetWorldIdentity(GDEVICE);


	RenderText();

	m_pd3dDevice->EndScene();

	
	
	return S_OK;
}



HRESULT CMain::RenderText()
{
	m_pd3dDevice->SetRenderState(D3DRS_LIGHTING, FALSE);
	m_pd3dDevice->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
	m_pd3dDevice->SetTexture( 0, 0);

	TCHAR szMsg[MAX_PATH];
	RECT rc;
	rc.left   = 2;
	rc.right  = m_d3dsdBackBuffer.Width - 20;
	rc.top = 3;
	rc.bottom = rc.top + 20;
	
	sprintf(szMsg, "%s %s",m_strDeviceStats, m_strFrameStats );


	m_pD3DXFont->DrawText(NULL, szMsg, -1, &rc, 0, D3DXCOLOR(1,1,0,1) );


	rc.top = 23;
	rc.bottom = rc.top + 20;

	VEC3 vcCamPos = m_pCam->GetEye();
	
	sprintf(szMsg, "Camera Pos: %.f %.f %.f",vcCamPos.x, vcCamPos.y, vcCamPos.z );
	m_pD3DXFont->DrawText(NULL, szMsg, -1, &rc, 0, D3DXCOLOR(1,1,0,1) );


	
	return S_OK;
}


LRESULT CMain::MsgProc( HWND hWnd, UINT msg, WPARAM wParam,LPARAM lParam)
{
	switch( msg )
	{
	case WM_PAINT:
		{
			if( m_bLoadingApp )
			{
				HDC hDC = GetDC( hWnd );
				ReleaseDC( hWnd, hDC );
			}
			break;
		}
		
	}
	
	return CD3DApplication::MsgProc( hWnd, msg, wParam, lParam );
}


void CMain::MeshSetup(DWORD dFVF, DWORD Diffuse, DWORD Specular)
{
	if(m_TeapotD)
	{
		m_TeapotD->Release();
		m_TeapotD = NULL;
	}

	m_dFVF |= dFVF;

	if(!m_dFVF)
		m_dFVF	= (D3DFVF_XYZ | D3DFVF_NORMAL);

	m_TeapotO->CloneMeshFVF(D3DXMESH_MANAGED,  m_dFVF, m_pd3dDevice,&m_TeapotD);

	FLOAT	fScl = 15;
	D3DXVECTOR3	vcPos(0, 15, 0);
	INT		nVtx = m_TeapotD->GetNumVertices();
	
	if( D3DFVF_DIFFUSE == dFVF)
	{
		VtxND* pVtx = NULL;
		m_TeapotD->LockVertexBuffer(0, (void**)&pVtx);

		for(INT i=0; i < nVtx; ++i)
		{
			pVtx[i].p *= fScl;
			pVtx[i].p += vcPos;
			pVtx[i].d = Diffuse;
		}

		m_TeapotD->UnlockVertexBuffer();
	}

	else if( D3DFVF_SPECULAR == dFVF)
	{
		VtxNS* pVtx = NULL;
		m_TeapotD->LockVertexBuffer(0, (void**)&pVtx);

		D3DXVECTOR3 vcMin;
		D3DXVECTOR3 vcMax;
		::D3DXComputeBoundingBox((D3DXVECTOR3*)pVtx
								, nVtx
								, D3DXGetFVFVertexSize(m_dFVF)
								, &vcMin
								, &vcMax);
	

		for(INT i=0; i < nVtx; ++i)
		{
			pVtx[i].p *= fScl;
			pVtx[i].p += vcPos;
			pVtx[i].s = Specular;
		}

		m_TeapotD->UnlockVertexBuffer();
	}

	else if( (D3DFVF_DIFFUSE | D3DFVF_SPECULAR) == dFVF)
	{
		VtxNDS* pVtx = NULL;
		m_TeapotD->LockVertexBuffer(0, (void**)&pVtx);

		D3DXVECTOR3 vcMin;
		D3DXVECTOR3 vcMax;
		::D3DXComputeBoundingBox((D3DXVECTOR3*)pVtx
								, nVtx
								, D3DXGetFVFVertexSize(m_dFVF)
								, &vcMin
								, &vcMax);

		for(INT i=0; i < nVtx; ++i)
		{
			pVtx[i].p *= fScl;
			pVtx[i].p += vcPos;
			pVtx[i].d = Diffuse;
			pVtx[i].s = Specular;
		}

		m_TeapotD->UnlockVertexBuffer();
	}

	else
	{
		VtxN* pVtx = NULL;
		m_TeapotD->LockVertexBuffer(0, (void**)&pVtx);

		for(INT i=0; i < nVtx; ++i)
		{
			pVtx[i].p *= fScl;
			pVtx[i].p += vcPos;
		}

		m_TeapotD->UnlockVertexBuffer();
	}
}


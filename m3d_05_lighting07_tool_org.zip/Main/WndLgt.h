// Interface for the CWndLgt class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _WNDLGT_H_
#define _WNDLGT_H_

typedef	D3DXCOLOR		DCLR;

typedef D3DLIGHT9		DLGT;
typedef	D3DMATERIAL9	DMTL;

class CWndLgt
{
public:
	HWND		m_hWnd		;
	HWND		m_hWPrn		;

public:
	BOOL		m_bLg		;
	DLGT		m_Lgt		;
	
public:
	CLSS_DLG_DECLEAR( CWndLgt );

	INT		Init();
	void	Destroy();

	INT		FrameMove();
	void	SetState();

	INT		Create(HWND hWnd);
	LRESULT	MsgPrc(HWND, UINT, WPARAM, LPARAM);
};

#endif

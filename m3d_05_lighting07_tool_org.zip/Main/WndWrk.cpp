// Implementation of the CWndWrk class.
//
////////////////////////////////////////////////////////////////////////////////


#include "../_StdAfx.h"


CLSS_DLG_DEFINE(CWndWrk, MsgPrc);


INT CWndWrk::Init()
{
	m_hWnd			= NULL;
	m_hWndPrn		= NULL;

//	AmbLC	0.700 0.700 0.700 1.000
//	MtrlS	0 1 2 0
//	MtrlI	1.000 1.000 1.000 1.000		0.100 0.100 0.100 1.000		1.000 1.000 1.000 1.000		0.000 0.000 0.000 1.000		30.00
//
//	LnRc*	 0	3		1.000 1.000 1.000 1.000		1.000 1.000 1.000 1.000		0.000 0.000 0.000 1.000		  0.62   0.75  -0.18		-0.6200 -0.7500 0.1800		1000.000  0.000		0.0000 0.0000 0.0000		0.0000 0.0000
//	LnRc*	 1	3		
//	LnRc*	 2	3		0.427 0.427 0.427 1.000		0.000 1.000 1.000 1.000		0.000 0.000 0.000 1.000		 -0.87  -0.43  -0.25		0.8700 0.0000 0.2500		1000.000  0.000		0.0000 0.0000 0.0000		0.0000 0.0000

	return 0;
}


INT CWndWrk::Create(HWND hWnd)
{
	m_hWndPrn	= hWnd;

	// can't select arbitrary color sources?
	D3DCAPS9 caps;
	GDEVICE->GetDeviceCaps(&caps);
	bool enable = (caps.VertexProcessingCaps & D3DVTXPCAPS_MATERIALSOURCE7) != 0;

	RECT	rt1;
	RECT	rt2;

	INT		iWd;
	INT		iHg;
	INT		iX;
	INT		iY;
	DWORD	r, g, b;

	m_hWnd = CreateDialog( GetModuleHandle(NULL), MAKEINTRESOURCE(IDD_WRK), hWnd, CLSS_DLG_WNDPROC(CWndWrk));

	// 1. Setting Render State
	m_dShade		=D3DSHADE_GOURAUD;
	m_dFill			=D3DFILL_SOLID;
	
	m_bLighting		=1;
	m_bColorVtx		=1;
	m_bNormalize	=1;
	m_bSpecular		=1;
	m_bDithering	=1;

	m_dShade	= D3DSHADE_GOURAUD;
	m_dFill		= D3DFILL_SOLID;

	CHECKBOX_SETVALUE(m_hWnd, IDC_OPT_LIGHT			, m_bLighting);
	CHECKBOX_SETVALUE(m_hWnd, IDC_OPT_COL_VTX		, m_bColorVtx);
	CHECKBOX_SETVALUE(m_hWnd, IDC_OPT_NORMAL		, m_bNormalize);
	CHECKBOX_SETVALUE(m_hWnd, IDC_OPT_SPEC_ENABLE	, m_bSpecular);
	CHECKBOX_SETVALUE(m_hWnd, IDC_OPT_DITHER		, m_bDithering);


	// 3. Setting Ambient Light color and Material
	m_xcAmb = D3DXCOLOR(0.7f, 0.7f, 0.7f, 1.0f);

	m_Mtl.Ambient.r = 0.10f;
	m_Mtl.Ambient.g = 0.40f;
	m_Mtl.Ambient.b = 0.10f;
	m_Mtl.Ambient.a = 1.00f;
	
	m_Mtl.Diffuse.r = 1.00f; 
	m_Mtl.Diffuse.g = 1.00f;
	m_Mtl.Diffuse.b = 0.80f;
	m_Mtl.Diffuse.a = 1.00f;

	m_Mtl.Specular.r= 1.00f;
	m_Mtl.Specular.g= 1.00f;
	m_Mtl.Specular.b= 1.00f;
	m_Mtl.Specular.a= 1.00f;

	m_Mtl.Emissive.r= 0.01f;
	m_Mtl.Emissive.g= 0.05f;
	m_Mtl.Emissive.b= 0.01f;
	m_Mtl.Emissive.a= 1.00f;

	m_Mtl.Power		= 20.0f;


	r = McUtil_D3DColorGetR(m_xcAmb);
	g = McUtil_D3DColorGetG(m_xcAmb);
	b = McUtil_D3DColorGetB(m_xcAmb);

	SetDlgItemInt(m_hWnd, IDC_OPT_AMBI_R, r,0);
	SetDlgItemInt(m_hWnd, IDC_OPT_AMBI_G, g,0);
	SetDlgItemInt(m_hWnd, IDC_OPT_AMBI_B, b,0);


	r = McUtil_D3DColorGetR(D3DXCOLOR(m_Mtl.Ambient));
	g = McUtil_D3DColorGetG(D3DXCOLOR(m_Mtl.Ambient));
	b = McUtil_D3DColorGetB(D3DXCOLOR(m_Mtl.Ambient));
	SetDlgItemInt(m_hWnd, IDC_MTL_AMBI_R, r,0);
	SetDlgItemInt(m_hWnd, IDC_MTL_AMBI_G, g,0);
	SetDlgItemInt(m_hWnd, IDC_MTL_AMBI_B, b,0);
	McUtil_FillRect(GetDlgItem(m_hWnd, IDC_MTL_AMBI_C), RGB(r, g, b));
	
	r = McUtil_D3DColorGetR(D3DXCOLOR(m_Mtl.Diffuse));
	g = McUtil_D3DColorGetG(D3DXCOLOR(m_Mtl.Diffuse));
	b = McUtil_D3DColorGetB(D3DXCOLOR(m_Mtl.Diffuse));
	SetDlgItemInt(m_hWnd, IDC_MTL_DIFF_R, r,0);
	SetDlgItemInt(m_hWnd, IDC_MTL_DIFF_G, g,0);
	SetDlgItemInt(m_hWnd, IDC_MTL_DIFF_B, b,0);
	McUtil_FillRect(GetDlgItem(m_hWnd, IDC_MTL_DIFF_C), RGB(r, g, b));
	
	r = McUtil_D3DColorGetR(D3DXCOLOR(m_Mtl.Specular));
	g = McUtil_D3DColorGetG(D3DXCOLOR(m_Mtl.Specular));
	b = McUtil_D3DColorGetB(D3DXCOLOR(m_Mtl.Specular));
	SetDlgItemInt(m_hWnd, IDC_MTL_SPEC_R, r,0);
	SetDlgItemInt(m_hWnd, IDC_MTL_SPEC_G, g,0);
	SetDlgItemInt(m_hWnd, IDC_MTL_SPEC_B, b,0);
	McUtil_FillRect(GetDlgItem(m_hWnd, IDC_MTL_SPEC_C), RGB(r, g, b));

	r = McUtil_D3DColorGetR(D3DXCOLOR(m_Mtl.Emissive));
	g = McUtil_D3DColorGetG(D3DXCOLOR(m_Mtl.Emissive));
	b = McUtil_D3DColorGetB(D3DXCOLOR(m_Mtl.Emissive));
	SetDlgItemInt(m_hWnd, IDC_MTL_EMIS_R, r,0);
	SetDlgItemInt(m_hWnd, IDC_MTL_EMIS_G, g,0);
	SetDlgItemInt(m_hWnd, IDC_MTL_EMIS_B, b,0);
	McUtil_FillRect(GetDlgItem(m_hWnd, IDC_MTL_EMIS_C), RGB(r, g, b));

	SetDlgItemFlt(m_hWnd, IDC_MTL_SPEC_POW, m_Mtl.Power, 2);


	GetWindowRect(GHWND, &rt1);
	GetWindowRect(m_hWnd, &rt2);
	
	iWd = rt2.right - rt2.left;
	iHg=  rt2.bottom- rt2.top;

	iX = rt1.left - iWd;
	iY = rt1.top;
	
	MoveWindow(m_hWnd, iX, iY, iWd, iHg, TRUE);
	GetWindowRect(m_hWnd, &rt2);

	ShowWindow(m_hWnd, SW_SHOW);
	
	return 0;
}


void CWndWrk::Destroy()
{
	SAFE_DESTROY_WIN(m_hWnd);
}



INT CWndWrk::FrameMove()
{
	DWORD	r = McUtil_D3DColorGetR(m_xcAmb);
	DWORD	g = McUtil_D3DColorGetG(m_xcAmb);
	DWORD	b = McUtil_D3DColorGetB(m_xcAmb);
	McUtil_FillRect(GetDlgItem(m_hWnd, IDC_OPT_AMBI_C), RGB(r, g, b));

	r = McUtil_D3DColorGetR(D3DXCOLOR(m_Mtl.Ambient));
	g = McUtil_D3DColorGetG(D3DXCOLOR(m_Mtl.Ambient));
	b = McUtil_D3DColorGetB(D3DXCOLOR(m_Mtl.Ambient));
	McUtil_FillRect(GetDlgItem(m_hWnd, IDC_MTL_AMBI_C), RGB(r, g, b));
	
	r = McUtil_D3DColorGetR(D3DXCOLOR(m_Mtl.Diffuse));
	g = McUtil_D3DColorGetG(D3DXCOLOR(m_Mtl.Diffuse));
	b = McUtil_D3DColorGetB(D3DXCOLOR(m_Mtl.Diffuse));
	McUtil_FillRect(GetDlgItem(m_hWnd, IDC_MTL_DIFF_C), RGB(r, g, b));
	
	r = McUtil_D3DColorGetR(D3DXCOLOR(m_Mtl.Specular));
	g = McUtil_D3DColorGetG(D3DXCOLOR(m_Mtl.Specular));
	b = McUtil_D3DColorGetB(D3DXCOLOR(m_Mtl.Specular));
	McUtil_FillRect(GetDlgItem(m_hWnd, IDC_MTL_SPEC_C), RGB(r, g, b));

	r = McUtil_D3DColorGetR(D3DXCOLOR(m_Mtl.Emissive));
	g = McUtil_D3DColorGetG(D3DXCOLOR(m_Mtl.Emissive));
	b = McUtil_D3DColorGetB(D3DXCOLOR(m_Mtl.Emissive));
	McUtil_FillRect(GetDlgItem(m_hWnd, IDC_MTL_EMIS_C), RGB(r, g, b));

	return 0;
}



void CWndWrk::SetState()
{
	GDEVICE->SetMaterial(&m_Mtl);

	GDEVICE->SetRenderState(D3DRS_AMBIENT					,	m_xcAmb		);
	GDEVICE->SetRenderState(D3DRS_COLORVERTEX				,	m_bColorVtx	);
	GDEVICE->SetRenderState(D3DRS_LIGHTING					,	m_bLighting	);
	GDEVICE->SetRenderState(D3DRS_NORMALIZENORMALS			,	m_bNormalize);
	GDEVICE->SetRenderState(D3DRS_SPECULARENABLE			,	m_bSpecular	);
	GDEVICE->SetRenderState(D3DRS_SHADEMODE					,	m_dShade	);
	GDEVICE->SetRenderState(D3DRS_FILLMODE					,	m_dFill		);
	GDEVICE->SetRenderState(D3DRS_ALPHATESTENABLE			,	FALSE		);
	GDEVICE->SetRenderState(D3DRS_STENCILENABLE				,	FALSE		);
	GDEVICE->SetRenderState(D3DRS_ZENABLE					,	D3DZB_TRUE	);
	GDEVICE->SetRenderState(D3DRS_ZFUNC						,	D3DCMP_LESS	);
	GDEVICE->SetRenderState(D3DRS_ZWRITEENABLE				,	TRUE		);
	GDEVICE->SetRenderState(D3DRS_ALPHABLENDENABLE			,	FALSE		);
	GDEVICE->SetRenderState(D3DRS_DITHERENABLE				,	m_bDithering);
}


LRESULT CWndWrk::MsgPrc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	WPARAM	wparHi = HIWORD(wParam);
	WPARAM	wparLo = LOWORD(wParam);

	switch( uMsg )
	{
		case WM_PAINT:
		{
			break;
		}

		case WM_COMMAND:
		{
			switch(wparLo)
			{
				case IDC_OPT_LIGHT:
					m_bLighting = CHECKBOX_GETVALUE(hWnd, IDC_OPT_LIGHT);
					break;

				case IDC_OPT_COL_VTX:
					m_bColorVtx= CHECKBOX_GETVALUE(hWnd, IDC_OPT_COL_VTX);
					break;

				case IDC_OPT_NORMAL:
					m_bNormalize= CHECKBOX_GETVALUE(hWnd, IDC_OPT_NORMAL);
					break;

				case IDC_OPT_SPEC_ENABLE:
					m_bSpecular= CHECKBOX_GETVALUE(hWnd, IDC_OPT_SPEC_ENABLE);
					break;

				case IDC_OPT_DITHER:
					m_bDithering= CHECKBOX_GETVALUE(hWnd, IDC_OPT_DITHER);
					break;

				#define MSG_COL_SET(MSG_ID1, R_COLOR, MSG_ID2, MSG_ID3, MSG_ID4)	\
				case MSG_ID1 :														\
				{																	\
					switch(wparHi)													\
					{																\
						case EN_CHANGE:												\
						{															\
							DWORD ClrR = GetDlgItemInt(hWnd, MSG_ID2, 0, 0);		\
							DWORD ClrG = GetDlgItemInt(hWnd, MSG_ID3, 0, 0);		\
							DWORD ClrB = GetDlgItemInt(hWnd, MSG_ID4, 0, 0);		\
							DWORD dC1 = RGB(ClrR, ClrG, ClrB);						\
							R_COLOR	= D3DXCOLOR(D3DCOLOR_XRGB(ClrR, ClrG, ClrB));	\
																					\
							break;													\
						}															\
					}																\
																					\
					break;															\
				}


				MSG_COL_SET( IDC_OPT_AMBI_R, m_xcAmb, IDC_OPT_AMBI_R, IDC_OPT_AMBI_G, IDC_OPT_AMBI_B);
				MSG_COL_SET( IDC_OPT_AMBI_G, m_xcAmb, IDC_OPT_AMBI_R, IDC_OPT_AMBI_G, IDC_OPT_AMBI_B);
				MSG_COL_SET( IDC_OPT_AMBI_B, m_xcAmb, IDC_OPT_AMBI_R, IDC_OPT_AMBI_G, IDC_OPT_AMBI_B);

				MSG_COL_SET( IDC_MTL_AMBI_R, m_Mtl.Ambient, IDC_MTL_AMBI_R, IDC_MTL_AMBI_G, IDC_MTL_AMBI_B);
				MSG_COL_SET( IDC_MTL_AMBI_G, m_Mtl.Ambient, IDC_MTL_AMBI_R, IDC_MTL_AMBI_G, IDC_MTL_AMBI_B);
				MSG_COL_SET( IDC_MTL_AMBI_B, m_Mtl.Ambient, IDC_MTL_AMBI_R, IDC_MTL_AMBI_G, IDC_MTL_AMBI_B);

				MSG_COL_SET( IDC_MTL_DIFF_R, m_Mtl.Diffuse, IDC_MTL_DIFF_R, IDC_MTL_DIFF_G, IDC_MTL_DIFF_B);
				MSG_COL_SET( IDC_MTL_DIFF_G, m_Mtl.Diffuse, IDC_MTL_DIFF_R, IDC_MTL_DIFF_G, IDC_MTL_DIFF_B);
				MSG_COL_SET( IDC_MTL_DIFF_B, m_Mtl.Diffuse, IDC_MTL_DIFF_R, IDC_MTL_DIFF_G, IDC_MTL_DIFF_B);

				MSG_COL_SET( IDC_MTL_SPEC_R, m_Mtl.Specular, IDC_MTL_SPEC_R, IDC_MTL_SPEC_G, IDC_MTL_SPEC_B);
				MSG_COL_SET( IDC_MTL_SPEC_G, m_Mtl.Specular, IDC_MTL_SPEC_R, IDC_MTL_SPEC_G, IDC_MTL_SPEC_B);
				MSG_COL_SET( IDC_MTL_SPEC_B, m_Mtl.Specular, IDC_MTL_SPEC_R, IDC_MTL_SPEC_G, IDC_MTL_SPEC_B);

				MSG_COL_SET( IDC_MTL_EMIS_R, m_Mtl.Emissive, IDC_MTL_EMIS_R, IDC_MTL_EMIS_G, IDC_MTL_EMIS_B);
				MSG_COL_SET( IDC_MTL_EMIS_G, m_Mtl.Emissive, IDC_MTL_EMIS_R, IDC_MTL_EMIS_G, IDC_MTL_EMIS_B);
				MSG_COL_SET( IDC_MTL_EMIS_B, m_Mtl.Emissive, IDC_MTL_EMIS_R, IDC_MTL_EMIS_G, IDC_MTL_EMIS_B);

				#define GET_MSG_FLT(SET_VALUE, MSG_ID)					\
				case MSG_ID :												\
				{															\
					switch(wparHi)											\
					{														\
						case EN_CHANGE:										\
						{													\
							(SET_VALUE) = GetDlgItemFlt(hWnd, MSG_ID);		\
							break;											\
						}													\
					}														\
																			\
					break;													\
				}

				GET_MSG_FLT(m_Mtl.Power, IDC_MTL_SPEC_POW);
			}
			
			break;
		}

	}// switch

	return(FALSE);
}
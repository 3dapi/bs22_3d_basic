// Interface for the CMain class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MAIN_H_
#define _MAIN_H_

typedef std::vector<DLGT >	lsLgt;
typedef lsLgt::iterator		itLgt;


class CMain : public CD3DApplication
{
public:
	ID3DXFont*		m_pD3DXFont	;
	CLcInput*		m_pInput	;
	CLcCam*			m_pCam		;
	CLcGrid*		m_pGrid		;
	
public:
	CMain();

	virtual HRESULT Init();
	virtual HRESULT Destroy();

	virtual HRESULT Restore();
	virtual HRESULT Invalidate();
	
	virtual HRESULT FrameMove();
	virtual HRESULT Render();
	
	HRESULT RenderText();
	
public:
	LRESULT MsgProc( HWND, UINT, WPARAM, LPARAM);

public:
	lsLgt			m_vLgt		;
	DLGT*			m_pLgt		;

	CWndWrk			m_WndWrk	;				// Left Window
	CWndLgt			m_WndLgt	;				// Bottom Window

	DWORD			m_dFVF		;
	LPD3DXMESH		m_TeapotO	;				// Original Teapot
	LPD3DXMESH		m_TeapotD	;				// Destination Teapot

	void			MeshSetup(DWORD dFVF, DWORD Diffuse=0xFFFF0000, DWORD Specular=0xFF00FF00);
};


extern CMain*	g_pApp;
#define GMAIN	g_pApp


#endif
// Interface for Utilities.
//
////////////////////////////////////////////////////////////////////////////////

#if _MSC_VER >=1200
  #pragma warning(disable: 4996)
#endif

#ifndef _LcUtil_H_
#define _LcUtil_H_


#include <vector>


typedef WNDPROC									LPWNDPROC;						// for Window Message
typedef DLGPROC									LPDLGPROC;						// for Dialog Message


#if _MSC_VER >=1200
  #pragma warning(disable: 4996)
#endif

#ifndef ONE_RADtoDEG
#	define ONE_RADtoDEG	57.295779513082321f
#endif

#if _MSC_VER >=1200
  #pragma warning(disable: 4996)
#endif

#ifndef ONE_DEGtoRAD
#	define ONE_DEGtoRAD	0.0174532925199433f
#endif

#if _MSC_VER >=1200
  #pragma warning(disable: 4996)
#endif

#ifndef PI_RAD
#	define PI_RAD		3.1415926535897932f
#endif

#if _MSC_VER >=1200
  #pragma warning(disable: 4996)
#endif

#ifndef DEG90toRAD
#	define DEG90toRAD	1.5707963267948966f
#endif

#if _MSC_VER >=1200
  #pragma warning(disable: 4996)
#endif

#ifndef RADtoDEG
#	define RADtoDEG(p) ( (p)*ONE_RADtoDEG)
#endif

#if _MSC_VER >=1200
  #pragma warning(disable: 4996)
#endif

#ifndef DEGtoRAD
#	define DEGtoRAD(p) ( (p)*ONE_DEGtoRAD)
#endif


#if _MSC_VER >=1200
  #pragma warning(disable: 4996)
#endif

#ifndef LN_ROUNDING_EPSILON
#	define LN_ROUNDING_EPSILON	0.0001f
#endif














#define	SAFE_FREE(p)	{ if(p) { free(p);		(p)=NULL; } }

#if _MSC_VER >=1200
  #pragma warning(disable: 4996)
#endif

#ifndef SAFE_RELEASE
#define SAFE_RELEASE(p)	{	if(p){(p)->Release();p = NULL;	}}
#endif

#if _MSC_VER >=1200
  #pragma warning(disable: 4996)
#endif

#ifndef SAFE_DELETE
#define SAFE_DELETE(p)	{	if(p){delete (p);p = NULL;	}}
#endif

#if _MSC_VER >=1200
  #pragma warning(disable: 4996)
#endif

#ifndef SAFE_DELETE_ARRAY
#define SAFE_DELETE_ARRAY(p){	if(p){delete [] (p);p = NULL;	}}
#endif



#define SAFE_NEW(p, CLASSTYPE)												\
{																			\
	if(NULL == (p))															\
	{																		\
		p = new CLASSTYPE;													\
	}																		\
}


#define _SAFE_NEWINIT(p, CLASSTYPE)											\
{																			\
	if(NULL == (p))															\
	{																		\
		p = new CLASSTYPE;													\
		if(!(p))	{	return;		}										\
		if(FAILED((p)->Init()))	{	delete p;	p = NULL;	return;		}	\
	}																		\
}


#define SAFE_NEWINIT(p, CLASSTYPE)											\
{																			\
	if(NULL == (p))															\
	{																		\
		p = new CLASSTYPE;													\
		if(!(p))	{	return -1;	}										\
																			\
		if(FAILED((p)->Init()))	{	delete p;	p = NULL;	return -1;	}	\
	}																		\
}


#define SAFE_NEWCREATE1(p, CLASSTYPE, PARAM1)								\
{																			\
	if(NULL == (p))															\
	{																		\
		p = new CLASSTYPE;													\
		if(!(p))	{	return -1;	}										\
																			\
		if(FAILED((p)->Create(PARAM1)))	{ delete p; p=0;	return -1;	}	\
	}																		\
}


#define SAFE_NEWCREATE2(p, CLASSTYPE, PARAM1, PARAM2)						\
{																			\
	if(NULL == (p))															\
	{																		\
		p = new CLASSTYPE;													\
		if(!(p))	{	return -1;	}										\
																			\
		if(FAILED((p)->Create(PARAM1, PARAM2))){delete p; p=0; return -1; }	\
	}																		\
}


#define SAFE_NEWCREATE3(p, CLASSTYPE, PARAM1, PARAM2, PARAM3)				\
{																			\
	if(NULL == (p))															\
	{																		\
		p = new CLASSTYPE;													\
		if(!(p))	{	return -1;	}										\
																			\
		if(FAILED((p)->Create(PARAM1, PARAM2, PARAM3))){delete p; p=0; return -1; }	\
	}																		\
}


#define SAFE_RESTORE(p)	{ if(p){ if(FAILED((p)->Restore())){ return -1;	}}}
#define SAFE_FRMOV(p)	{ if(p){ if(FAILED((p)->FrameMove())){return -1;}}}
#define SAFE_UPDATE(p)	{ if(p){ if(FAILED((p)->Update())){ return -1;	}}}

#define SAFE_DESTROY(p)	{ if(p){(p)->Destroy();			}}
#define SAFE_INVALID(p)	{ if(p){(p)->Invalidate();		}}
#define SAFE_RENDER(p)	{ if(p){(p)->Render();			}}
#define SAFE_RENDERS(p)	{ if(p){(p)->RenderS();			}}

#define SAFE_ONFRMMOV(p){ if(p){(p)->OnFrmMov();		}}
#define SAFE_ONRENDER(p){ if(p){(p)->OnRender();		}}


#define	SAFE_DESTROY_WIN(p){ if(p){DestroyWindow(p);	}}



#define SAFE_DEL_OBJ_ARRAY(p, iSIZE)										\
{																			\
	int i_IDX_OBJ_=0;														\
																			\
	for(i_IDX_OBJ_=0; i_IDX_OBJ_ < (iSIZE) ; ++i_IDX_OBJ_)					\
	{																		\
		if(p[i_IDX_OBJ_])													\
		{																	\
			DeleteObject(p[i_IDX_OBJ_]);									\
			p[i_IDX_OBJ_] = NULL;											\
		}																	\
	}																		\
}


// Vector delete all in list
#define SAFE_DEL_LST(p)												\
{																	\
	if(!p.empty())													\
	{																\
		int iSizeList = p.size();									\
		for(int indexList=0; indexList<iSizeList; ++indexList)		\
			SAFE_DELETE(p[indexList]);								\
		p.clear();													\
	}																\
}


#define SAFE_PT_ERASE(p, nIdx, ITERATOR)							\
{																	\
	ITERATOR ITERATOR##_it = p.begin() + nIdx;						\
	SAFE_DELETE( (* ITERATOR##_it) );								\
																	\
	p.erase((ITERATOR##_it));										\
}


// Vector FrameMove
#define SAFE_FRMOV_LST(p)											\
{																	\
	if(!p.empty())													\
	{																\
		int iSizeList = p.size();									\
		for(int indexList=0; indexList<iSizeList; ++indexList)		\
		{															\
			SAFE_FRMOV(p[indexList]);								\
		}															\
	}																\
}

// Vector Rendering
#define SAFE_REN_LST(p)												\
{																	\
	if(!p.empty())													\
	{																\
		int iSizeList = p.size();									\
		for(int indexList=0; indexList<iSizeList; ++indexList)		\
		{															\
			SAFE_RENDER(p[indexList]);								\
		}															\
	}																\
}




#define CLASS_DESTROY(CLASS_NAME)									\
CLASS_NAME::~CLASS_NAME()											\
{																	\
	Destroy();														\
}



#define CLASS_CLEAN_ALL(CLASS_NAME)									\
CLASS_NAME::~CLASS_NAME()											\
{																	\
	Invalidate();													\
	Destroy();														\
}




#define	GAME_LOOP_FR(	PhaseName	)								\
INT CMain::OnFrm##PhaseName ()										\
{																	\
	strcat(m_sMsg, " " #PhaseName "");								\
	SAFE_FRMOV(	m_pGm##PhaseName	);								\
	return 0;														\
}																	\
																	\
void CMain::OnRnd##PhaseName ()										\
{																	\
	SAFE_RENDER(	m_pGm##PhaseName	);							\
}																	\
																	\
void CMain::OnRns##PhaseName ()										\
{																	\
	SAFE_RENDERS(	m_pGm##PhaseName	);							\
}



#define CLSS_DLG_DECLEAR(CLASS)											\
CLASS ();																\
virtual ~CLASS ();														\
static INT_PTR	CLASS##WndPrc (HWND hW, UINT uM, WPARAM wP, LPARAM lP);

#define CLSS_DLG_DEFINE(CLASS, MSGPROC)									\
static CLASS*	g_pWndDialog##CLASS;									\
INT_PTR CLASS :: CLASS##WndPrc (HWND hW, UINT uM, WPARAM wP, LPARAM lP)	\
{																		\
	return (g_pWndDialog##CLASS)-> MSGPROC (hW, uM, wP, lP);			\
}																		\
																		\
CLASS :: CLASS ()		{	g_pWndDialog##CLASS = this;	Init();	}		\
CLASS:: ~ CLASS (){}

#define CLSS_DLG_WNDPROC( CLASS )	(LPDLGPROC)((CLASS##WndPrc))



// Error MessageBox
void LcUtil_ErrMsgBox(HWND hWnd, char *format,...);

//������ Ÿ��Ʋ
void LcUtil_SetWindowTitle(HWND hWnd, char *format,...);

void	SetDlgItemFlt(HWND hWnd, UINT id, FLOAT z, INT decimal=6);
FLOAT	GetDlgItemFlt(HWND hWnd, UINT id);
void	SetDlgItemHex(HWND hWnd, UINT id, INT val);


char*	LnUtil_Forming(const char *fmt, ...);
void	LnUtil_ReadFileLine(FILE *fp, CHAR *str);
void	LnUtil_ReadLineQuot(CHAR *strOut, CHAR *strIn, INT iC='\"');
void	LcUtil_SetWorldIdentity(void* pDev);


struct VtxN
{
	D3DXVECTOR3 p;
	D3DXVECTOR3 n;
};


struct VtxND
{
	D3DXVECTOR3 p;
	D3DXVECTOR3 n;
	DWORD d;
};


struct VtxNS
{
	D3DXVECTOR3 p;
	D3DXVECTOR3 n;
	DWORD s;
};


struct VtxNDS
{
	D3DXVECTOR3 p;
	D3DXVECTOR3 n;
	DWORD d;
	DWORD s;
};


inline DWORD	McUtil_D3DColorGetR(D3DXCOLOR c)	{	return (DWORD)(c.r * 255);	}
inline DWORD	McUtil_D3DColorGetG(D3DXCOLOR c)	{	return (DWORD)(c.g * 255);	}
inline DWORD	McUtil_D3DColorGetB(D3DXCOLOR c)	{	return (DWORD)(c.b * 255);	}
inline DWORD	McUtil_D3DColorGetA(D3DXCOLOR c)	{	return (DWORD)(c.a * 255);	}


inline DWORD	McUtil_BGRColorGetR(DWORD c)	{	return (0X000000FF & c);		}
inline DWORD	McUtil_BGRColorGetG(DWORD c)	{	return (0X0000FF00 & c)>>8;		}
inline DWORD	McUtil_BGRColorGetB(DWORD c)	{	return (0X00FF0000 & c)>>16;	}



#define CHECKBOX_GETVALUE( hWindowHandle, Msg_ID)			\
::SendMessage(::GetDlgItem(hWindowHandle, Msg_ID), BM_GETCHECK, 0, 0)

#define CHECKBOX_SETVALUE( hWindowHandle, Msg_ID, MSGVALUE)	\
::SendMessage(::GetDlgItem(hWindowHandle, Msg_ID), BM_SETCHECK, MSGVALUE, 0)


inline
void McUtil_FillRect(HWND hWnd, DWORD c)
{
	RECT	rc;
	HBRUSH	hbr;
	HDC		hdc;

	hbr= CreateSolidBrush(c);

	hdc		= GetDC(hWnd);
	GetClientRect(hWnd, &rc);
	FillRect(hdc, &rc, hbr);

	DeleteObject(hbr);
	ReleaseDC(hWnd, hdc);
}


#endif


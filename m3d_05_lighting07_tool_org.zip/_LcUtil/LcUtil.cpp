//
//
////////////////////////////////////////////////////////////////////////////////

#pragma warning(disable: 4996)

#include <windows.h>
#include <commctrl.h>
#include <stdio.h>

#include <d3d9.h>
#include <d3dx9.h>

#include "LcUtil.h"


void LcUtil_ErrMsgBox(HWND hWnd, char *format,...)
{
	va_list ap;
	char s[2048];
	
	if (format == NULL) return;
	
	va_start(ap, format);
	vsprintf((char *)s, format, ap);
	va_end(ap);
	
	if (s == NULL)	return;
	
	MessageBox(hWnd, s, "Err", MB_OK | MB_ICONERROR);
}


void LcUtil_SetWindowTitle(HWND hWnd, char *format,...)
{
	va_list ap;
	char s[2048];
	
	if (format == NULL) return;
	
	va_start(ap, format);
	vsprintf((char *)s, format, ap);
	va_end(ap);
	
	if (s == NULL)	return;
	
	SetWindowText(hWnd, s);
}


void SetDlgItemFlt(HWND hWnd, UINT id, float z, INT decimal)
{
	char s[128];
	char f[64];
	
	sprintf(f,"%%.%df", decimal);
	memset(s, 0, sizeof(s));
	sprintf(s, f, z);
	SetDlgItemText(hWnd,id,s);
}

FLOAT GetDlgItemFlt(HWND hWnd, UINT id)
{
	char s[256];
	memset(s, 0, sizeof(s));

	GetDlgItemText(hWnd, id, s, sizeof(s));
	return (FLOAT)atof(s);
}

void SetDlgItemHex(HWND hWnd, UINT id, INT val)
{
	char	buf[64] = "0x";
	char	s[32];
	char*	pDst;
	memset(s, 0, sizeof(s));
	sprintf(s, "0000000000%X", val);
	pDst = s + strlen(s) - 8;

	strcat(buf, pDst);
	SetDlgItemText(hWnd,id,buf);
}



char*	LnUtil_Forming(const char *fmt, ...)
{
#define FORMING_1CALL_STR_TOTAL 1024
#define FORMING_RECALL_TOTAL 32
#define FORMING_BUF_TOTAL (FORMING_1CALL_STR_TOTAL * FORMING_RECALL_TOTAL)

	static char formingbuf[FORMING_BUF_TOTAL], formingfmt[FORMING_1CALL_STR_TOTAL + 1];
	static INT index_formingbuf;
	va_list arglist;
	char *strp;
	
	va_start(arglist, fmt);
	vsprintf(formingfmt, fmt, arglist);
	va_end(arglist);

	if (index_formingbuf + strlen(formingfmt) + 1 >= FORMING_BUF_TOTAL)
		index_formingbuf = 0;

	strp = formingbuf + index_formingbuf;
	strcpy(strp, formingfmt);
	index_formingbuf += strlen(formingfmt) + 1;

	return(strp);
}


void LnUtil_ReadFileLine(FILE *fp, CHAR *str)
{
	static CHAR sTmp[512];
	
	INT nSize;
	INT nBgn, nEnd;
	INT i;

	memset(sTmp,0, sizeof(sTmp));
	fgets(sTmp, 512, fp);

	nSize = strlen(sTmp);
	
	for(i=0; i<nSize; ++i)
	{
		if('\t' == sTmp[i])
			sTmp[i] =' ';
		
		if('\n' == sTmp[i] || '\r' == sTmp[i])
		{
			sTmp[i] = 0;
		}
	}
	
	nBgn=0;
	nEnd= strlen(sTmp);

	if(0 == nEnd)
	{
		str[0] =0;
		return;
	}
	
	for(i=0; i<=nEnd; ++i)
	{
		if(' ' != sTmp[i])
		{
			nBgn =i;
			break;
		}
	}
	
	strncpy(str, sTmp + nBgn, nEnd-nBgn);
	str[nEnd-nBgn] = 0;
}


void LnUtil_ReadLineQuot(CHAR *strOut, CHAR *strIn, INT iC)
{
	INT iB;
	INT iE;
	INT	i;

	// Search forward
	
	INT	iLen= strlen(strIn);

	for(i=0;i<iLen; ++i)
	{
		if(iC == strIn[i])
		{
			iB = i;
			break;
		}
	}

	for(i=iLen-1;i>=0; --i)
	{
		if(iC == strIn[i])
		{
			iE = i;
			break;
		}
	}

	if(iB == (iE-1))															// ���۰� �����̿� ���ڰ� ����.
	{
		strOut[0]=0;
		return;
	}

	strncpy(strOut, strIn+iB+1, iE-iB-1);
}


void LcUtil_SetWorldIdentity(void* _pDev)
{
	static	D3DXMATRIX	mtI(1,0,0,0,  0,1,0,0,  0,0,1,0,  0,0,0,1);
	LPDIRECT3DDEVICE9	pDev = (LPDIRECT3DDEVICE9)_pDev;
	pDev->SetTransform(D3DTS_WORLD, &mtI);
}
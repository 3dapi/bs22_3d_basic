//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Mck.rc
//
#define IDR_MAIN_ACCEL                  113
#define IDR_MENU                        141
#define IDD_WRK                         142
#define IDD_LGT                         143
#define IDC_OPT_AMBI_C                  1020
#define IDC_OPT_AMBI_R                  1021
#define IDC_OPT_AMBI_G                  1022
#define IDC_OPT_AMBI_B                  1023
#define IDC_OPT_LIGHT                   1024
#define IDC_OPT_COL_VTX                 1025
#define IDC_OPT_NORMAL                  1026
#define IDC_OPT_SPEC_ENABLE             1027
#define IDC_OPT_DITHER                  1028
#define IDC_VTX_DIF                     1029
#define IDC_VTX_DIF_R                   1030
#define IDC_VTX_DIF_G                   1031
#define IDC_VTX_DIF_B                   1032
#define IDC_VTX_SPC                     1033
#define IDC_VTX_SPC_R                   1034
#define IDC_VTX_SPC_G                   1035
#define IDC_VTX_SPC_B                   1036
#define IDC_MTL_AMBI_C                  1061
#define IDC_MTL_AMBI_R                  1062
#define IDC_MTL_AMBI_G                  1063
#define IDC_MTL_AMBI_B                  1064
#define IDC_MTL_AMBI_MT                 1065
#define IDC_MTL_AMBI_C1                 1066
#define IDC_MTL_AMBI_C2                 1067
#define IDC_MTL_DIFF_C                  1068
#define IDC_MTL_DIFF_R                  1069
#define IDC_MTL_DIFF_G                  1070
#define IDC_MTL_DIFF_B                  1071
#define IDC_MTL_DIFF_MT                 1072
#define IDC_MTL_DIFF_C1                 1073
#define IDC_MTL_DIFF_C2                 1074
#define IDC_MTL_SPEC_C                  1079
#define IDC_MTL_SPEC_R                  1080
#define IDC_MTL_SPEC_G                  1081
#define IDC_MTL_SPEC_B                  1082
#define IDC_MTL_SPEC_MT                 1083
#define IDC_MTL_SPEC_C1                 1084
#define IDC_MTL_SPEC_C2                 1085
#define IDC_MTL_EMIS_C                  1086
#define IDC_MTL_EMIS_R                  1087
#define IDC_MTL_EMIS_G                  1088
#define IDC_MTL_EMIS_B                  1089
#define IDC_MTL_EMIS_MT                 1090
#define IDC_MTL_EMIS_C1                 1091
#define IDC_MTL_EMIS_C2                 1092
#define IDC_MTL_SPEC_POW                1093
#define IDC_LGT_ENABLE                  1102
#define IDC_LGT_TYPE_PNT                1103
#define IDC_LGT_TYPE_SPT                1104
#define IDC_LGT_TYPE_DIR                1105
#define IDC_LGT_AMBI_C                  1106
#define IDC_LGT_AMBI_R                  1107
#define IDC_LGT_AMBI_G                  1108
#define IDC_LGT_AMBI_B                  1109
#define IDC_LGT_DIFF_C                  1110
#define IDC_LGT_DIFF_R                  1111
#define IDC_LGT_DIFF_G                  1112
#define IDC_LGT_DIFF_B                  1113
#define IDC_LGT_SPEC_C                  1114
#define IDC_LGT_SPEC_R                  1115
#define IDC_LGT_SPEC_G                  1116
#define IDC_LGT_SPEC_B                  1117
#define IDC_LGT_POS_X                   1118
#define IDC_LGT_POS_Y                   1119
#define IDC_LGT_POS_Z                   1120
#define IDC_LGT_DIR_X                   1121
#define IDC_LGT_DIR_Y                   1122
#define IDC_LGT_DIR_Z                   1123
#define IDC_LGT_RANGE                   1124
#define IDC_LGT_FALL                    1125
#define IDC_LGT_ATTN0                   1126
#define IDC_LGT_ATTN1                   1127
#define IDC_LGT_ATTN2                   1128
#define IDC_LGT_THETA                   1129
#define IDC_LGT_PHI                     1130
#define IDM_CHANGEDEVICE                40010
#define IDM_TOGGLEFULLSCREEN            40011
#define IDM_EXIT                        40012
#define IDM_BACK                        40013
#define IDM_RETURN                      40014
#define IDM_RETURN_CTRL                 40015
#define IDM_TAB                         40016
#define IDM_TAB_BACK                    40017
#define IDM_RETURN_SHIFT                40018
#define IDM_ESC                         40019
#define IDM_SOLID                       40023
#define IDM_LGT                         40024
#define IDM_FOG                         40025
#define IDM_NEW                         40026

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        161
#define _APS_NEXT_COMMAND_VALUE         40027
#define _APS_NEXT_CONTROL_VALUE         1130
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif

// Implementation of the CMcScene class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMcScene::CMcScene()
{
	m_pDev		= NULL;

	m_pTxDif0	= NULL;
	m_pTxEnv0	= NULL;
	m_pTxEnv1	= NULL;
	m_pTxDetail	= NULL;

	m_nType		= -1;
}

CMcScene::~CMcScene()
{
	Destroy();
}

INT CMcScene::Create(LPDIRECT3DDEVICE9 pDev)
{
	m_pDev = pDev;


	DWORD arg1;
	DWORD arg2;
	DWORD op;

	m_pDev->GetTextureStageState( 0, D3DTSS_COLORARG1, &arg1 );
	m_pDev->GetTextureStageState( 0, D3DTSS_COLORARG2, &arg2 );
	m_pDev->GetTextureStageState( 0, D3DTSS_COLOROP,   &op);


	m_pVtx[0] = VtxUV1(-5.0f, -5.0f, 5.f,  0.f,  1.0f);
	m_pVtx[1] = VtxUV1(-5.0f,  5.0f, 5.f,  0.f,  0.0f);
	m_pVtx[2] = VtxUV1( 5.0f,  5.0f, 5.f,  1.f,  0.0f);
	m_pVtx[3] = VtxUV1( 5.0f, -5.0f, 5.f,  1.f,  1.0f);

	D3DXCreateTextureFromFile(m_pDev, "Texture/stones.png"	, &m_pTxDif0);

	D3DXCreateTextureFromFile(m_pDev, "Texture/env0.png"	, &m_pTxEnv0);
	D3DXCreateTextureFromFile(m_pDev, "Texture/env1.png"	, &m_pTxEnv1);
	D3DXCreateTextureFromFile(m_pDev, "Texture/detail.png"	, &m_pTxDetail);

	return 0;
}


void CMcScene::Destroy()
{
	SAFE_RELEASE(	m_pTxDif0		);
	SAFE_RELEASE(	m_pTxEnv0		);
	SAFE_RELEASE(	m_pTxEnv1		);
	SAFE_RELEASE(	m_pTxDetail		);
}


INT CMcScene::FrameMove()
{
	if( ::GetAsyncKeyState('R') & 0x8000 )
		m_nType = -1;

	if( ::GetAsyncKeyState('1') & 0x8000 )
		m_nType = 1;

	if( ::GetAsyncKeyState('2') & 0x8000 )
		m_nType = 2;

	if( ::GetAsyncKeyState('3') & 0x8000 )
		m_nType = 3;

	if( ::GetAsyncKeyState('4') & 0x8000 )
		m_nType = 4;

	if( ::GetAsyncKeyState('5') & 0x8000 )
		m_nType = 5;

	if( ::GetAsyncKeyState('6') & 0x8000 )
		m_nType = 6;

	if( ::GetAsyncKeyState('7') & 0x8000 )
		m_nType = 7;

	if( ::GetAsyncKeyState('8') & 0x8000 )
		m_nType = 8;

	if( ::GetAsyncKeyState('9') & 0x8000 )
		m_nType = 9;

	if( ::GetAsyncKeyState('0') & 0x8000 )
		m_nType = 0;

	return 0;
}


void CMcScene::Render()
{
	m_pDev->SetRenderState(D3DRS_LIGHTING, FALSE);

	for(int i=0; i<4;++i)
	{
		m_pDev->SetSamplerState( i, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP);
		m_pDev->SetSamplerState( i, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);
		m_pDev->SetSamplerState( i, D3DSAMP_ADDRESSW, D3DTADDRESS_WRAP);

		m_pDev->SetSamplerState( i, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
		m_pDev->SetSamplerState( i, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
		m_pDev->SetSamplerState( i, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
	}


	m_pDev->SetTextureStageState( 1, D3DTSS_TEXCOORDINDEX,   0 );
	m_pDev->SetTextureStageState( 2, D3DTSS_TEXCOORDINDEX,   0 );
	m_pDev->SetTextureStageState( 3, D3DTSS_TEXCOORDINDEX,   0 );


	if( 1 == m_nType)
	{
		m_pDev->SetTexture(0, m_pTxDif0);
		m_pDev->SetTexture(1, m_pTxEnv0);

		m_pDev->SetTextureStageState( 1, D3DTSS_COLORARG1, D3DTA_CURRENT );
		m_pDev->SetTextureStageState( 1, D3DTSS_COLORARG2, D3DTA_TEXTURE );
		m_pDev->SetTextureStageState( 1, D3DTSS_COLOROP,   D3DTOP_MODULATE );
		m_pDev->SetTextureStageState( 2, D3DTSS_COLOROP,   D3DTOP_DISABLE );

		
//		����ó���� ������ ���� ó��
//		m_pDev->SetTextureStageState( 1, D3DTSS_ALPHAARG1, D3DTA_CURRENT );
//		m_pDev->SetTextureStageState( 1, D3DTSS_ALPHAARG2, D3DTA_TEXTURE );
//		m_pDev->SetTextureStageState( 1, D3DTSS_ALPHAOP,   D3DTOP_MODULATE );
//		m_pDev->SetTextureStageState( 2, D3DTSS_ALPHAOP,   D3DTOP_DISABLE );
	}

	else if( 2 == m_nType)
	{
		m_pDev->SetTexture(0, m_pTxDif0);
		m_pDev->SetTexture(1, m_pTxEnv0);
		m_pDev->SetTextureStageState( 1, D3DTSS_COLORARG1, D3DTA_CURRENT );
		m_pDev->SetTextureStageState( 1, D3DTSS_COLORARG2, D3DTA_TEXTURE );
		m_pDev->SetTextureStageState( 1, D3DTSS_COLOROP,   D3DTOP_MODULATE2X );
		m_pDev->SetTextureStageState( 2, D3DTSS_COLOROP,   D3DTOP_DISABLE );
	}

	else if( 3 == m_nType)
	{
		m_pDev->SetTexture(0, m_pTxDif0);
		m_pDev->SetTexture(1, m_pTxEnv0);
		m_pDev->SetTextureStageState( 1, D3DTSS_COLORARG1, D3DTA_CURRENT );
		m_pDev->SetTextureStageState( 1, D3DTSS_COLORARG2, D3DTA_TEXTURE );
		m_pDev->SetTextureStageState( 1, D3DTSS_COLOROP,   D3DTOP_MODULATE4X );
		m_pDev->SetTextureStageState( 2, D3DTSS_COLOROP,   D3DTOP_DISABLE );
	}

	else if( 4 == m_nType)
	{
		m_pDev->SetTexture(0, m_pTxDif0);
		m_pDev->SetTexture(1, m_pTxEnv0);
		m_pDev->SetTextureStageState( 1, D3DTSS_COLORARG1, D3DTA_CURRENT );
		m_pDev->SetTextureStageState( 1, D3DTSS_COLORARG2, D3DTA_TEXTURE );
		m_pDev->SetTextureStageState( 1, D3DTSS_COLOROP,   D3DTOP_ADD );
		m_pDev->SetTextureStageState( 2, D3DTSS_COLOROP,   D3DTOP_DISABLE );
	}

	else if( 5 == m_nType)
	{
		m_pDev->SetTexture(0, m_pTxDif0);
		m_pDev->SetTexture(1, m_pTxEnv0);
		m_pDev->SetTextureStageState( 1, D3DTSS_COLORARG1, D3DTA_CURRENT );
		m_pDev->SetTextureStageState( 1, D3DTSS_COLORARG2, D3DTA_TEXTURE );
		m_pDev->SetTextureStageState( 1, D3DTSS_COLOROP,   D3DTOP_SUBTRACT );
		m_pDev->SetTextureStageState( 2, D3DTSS_COLOROP,   D3DTOP_DISABLE );
	}


	else if( 6 == m_nType)
	{
		m_pDev->SetTexture(0, m_pTxDif0);
		m_pDev->SetTexture(1, m_pTxDetail);
		m_pDev->SetTextureStageState( 1, D3DTSS_COLORARG1, D3DTA_CURRENT );
		m_pDev->SetTextureStageState( 1, D3DTSS_COLORARG2, D3DTA_TEXTURE );
		m_pDev->SetTextureStageState( 1, D3DTSS_COLOROP,   D3DTOP_ADDSIGNED );
		m_pDev->SetTextureStageState( 2, D3DTSS_COLOROP,   D3DTOP_DISABLE );
	}

	else if( 7 == m_nType)
	{
		m_pDev->SetTexture(0, m_pTxDif0);
		m_pDev->SetTexture(1, m_pTxDetail);
		m_pDev->SetTextureStageState( 1, D3DTSS_COLORARG1, D3DTA_CURRENT );
		m_pDev->SetTextureStageState( 1, D3DTSS_COLORARG2, D3DTA_TEXTURE );
		m_pDev->SetTextureStageState( 1, D3DTSS_COLOROP,   D3DTOP_ADDSIGNED2X );
		m_pDev->SetTextureStageState( 2, D3DTSS_COLOROP,   D3DTOP_DISABLE );
	}

	else if( 8 == m_nType)
	{
		m_pDev->SetTexture(0, m_pTxDif0);
		m_pDev->SetTexture(1, m_pTxDetail);
		m_pDev->SetTextureStageState( 1, D3DTSS_TEXCOORDINDEX, 0);
		m_pDev->SetTextureStageState( 1, D3DTSS_COLORARG1, D3DTA_CURRENT );
		m_pDev->SetTextureStageState( 1, D3DTSS_COLORARG2, D3DTA_TEXTURE );
		m_pDev->SetTextureStageState( 1, D3DTSS_COLOROP,   D3DTOP_ADDSMOOTH );
		m_pDev->SetTextureStageState( 2, D3DTSS_COLOROP,   D3DTOP_DISABLE );
	}

	else if( 9 == m_nType)
	{
		m_pDev->SetTexture(0, m_pTxDif0);
		m_pDev->SetTexture(1, m_pTxEnv1);
		m_pDev->SetTexture(2, m_pTxDetail);

		m_pDev->SetTextureStageState( 1, D3DTSS_COLORARG1, D3DTA_TEXTURE );
		m_pDev->SetTextureStageState( 1, D3DTSS_COLOROP,   D3DTOP_SELECTARG1);
		m_pDev->SetTextureStageState( 1, D3DTSS_RESULTARG, D3DTA_TEMP );

		m_pDev->SetTextureStageState( 2, D3DTSS_COLORARG0, D3DTA_CURRENT );
		m_pDev->SetTextureStageState( 2, D3DTSS_COLORARG1, D3DTA_TEMP );
		m_pDev->SetTextureStageState( 2, D3DTSS_COLORARG2, D3DTA_TEXTURE );
		m_pDev->SetTextureStageState( 2, D3DTSS_COLOROP,   D3DTOP_MULTIPLYADD );
		m_pDev->SetTextureStageState( 3, D3DTSS_COLOROP,   D3DTOP_DISABLE );
	}

	else if( 0 == m_nType)
	{
		m_pDev->SetTexture(0, m_pTxDif0);
		m_pDev->SetTexture(1, m_pTxEnv1);
		m_pDev->SetTexture(2, m_pTxDetail);

		m_pDev->SetTextureStageState( 1, D3DTSS_COLORARG1, D3DTA_TEXTURE );
		m_pDev->SetTextureStageState( 1, D3DTSS_COLOROP,   D3DTOP_SELECTARG1);
		m_pDev->SetTextureStageState( 1, D3DTSS_RESULTARG, D3DTA_TEMP );

		m_pDev->SetTextureStageState( 2, D3DTSS_COLORARG0, D3DTA_CURRENT );
		m_pDev->SetTextureStageState( 2, D3DTSS_COLORARG1, D3DTA_TEMP );
		m_pDev->SetTextureStageState( 2, D3DTSS_COLORARG2, D3DTA_TEXTURE );
		m_pDev->SetTextureStageState( 2, D3DTSS_COLOROP,   D3DTOP_LERP );
		m_pDev->SetTextureStageState( 3, D3DTSS_COLOROP,   D3DTOP_DISABLE );
	}
	else
	{
		m_pDev->SetTexture(0, m_pTxDif0);
		m_pDev->SetTextureStageState( 1, D3DTSS_COLOROP,   D3DTOP_DISABLE );
		m_pDev->SetTextureStageState( 2, D3DTSS_COLOROP,   D3DTOP_DISABLE );
	}


	m_pDev->SetFVF(VtxUV1::FVF);
	m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLEFAN, 2, m_pVtx, sizeof(VtxUV1));


	m_pDev->SetTexture(0, NULL);
	m_pDev->SetTexture(1, NULL);
	m_pDev->SetTexture(2, NULL);
	m_pDev->SetTextureStageState( 1, D3DTSS_COLOROP,   D3DTOP_DISABLE );
	m_pDev->SetTextureStageState( 2, D3DTSS_COLOROP,   D3DTOP_DISABLE );
	m_pDev->SetTextureStageState( 1, D3DTSS_RESULTARG, D3DTA_CURRENT);
	m_pDev->SetTextureStageState( 2, D3DTSS_RESULTARG, D3DTA_CURRENT);

}


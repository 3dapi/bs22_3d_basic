#ifndef _VTXFMT_H_
#define _VTXFMT_H_


struct VtxN
{
    D3DXVECTOR3	p;
    D3DXVECTOR3	n;

	VtxN(){}
	VtxN(D3DXVECTOR3 P,D3DXVECTOR3 N)	{	p=P; n=N;	}
	enum { FVF = (D3DFVF_XYZ|D3DFVF_NORMAL)};
};


struct VtxD
{
	D3DXVECTOR3	p;
	DWORD	d;

	VtxD() : d(0xFFFFFFFF){}
	VtxD(FLOAT X, FLOAT Y, FLOAT Z, DWORD D) : p(X,Y,Z), d(D){}
	enum { FVF = (D3DFVF_XYZ|D3DFVF_DIFFUSE)};
};



#endif _VTXFMT_H_
// Interface for the CMcScene class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _McScene_H_
#define _McScene_H_

class CMcScene
{
public:
	PDEV	m_pDev;
	PDVB	m_pVB;																// Vertex for Height 

	FLOAT	m_fW;

	VEC3	m_vcI;																// Start position
	
public:
	CMcScene();
	virtual ~CMcScene();

	INT		Create(PDEV pDev);
	void	Destroy();

	INT		FrameMove();
	void	Render();

};

#endif


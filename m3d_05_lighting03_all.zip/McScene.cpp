// Implementation of the CMcScene class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


D3DLIGHT9 m_light;


CMcScene::CMcScene()
{
	m_pDev	= NULL;
	m_pVB	= NULL;
}

CMcScene::~CMcScene()
{
	Destroy();
}


INT	CMcScene::Create(PDEV pDev)
{
	m_pDev	= pDev;

	m_fW	= 10.f;

	m_vcI	= -VEC3(1, 0, 1) * 100.f;

	HRESULT hr;
	// Create the vertex buffer
	if( FAILED( hr = m_pDev->CreateVertexBuffer( 64* 64 * 3 * 2 * sizeof(VtxN)
		, 0
		, VtxN::FVF
		, D3DPOOL_MANAGED
		, &m_pVB
		, NULL ) ) )

		return -1;

	INT	nIdx;

	VEC3	p0;
	VEC3	p1;
	VEC3	p2;
	VEC3	p3;

	VEC3	n = VEC3(0,1,0);


	VtxN* pVtx = (VtxN* )malloc( 64* 64 * 3 * 2 * sizeof(VtxN) );

	for(int j=0; j<64; ++j)
	{
		for(int i=0; i<64; ++i)
		{
			nIdx = j * 64 + i;

			p0 = m_vcI + VEC3( i+0.f, 0.1f, j+0.f) * m_fW;
			p1 = m_vcI + VEC3( i+0.f, 0.1f, j+1.f) * m_fW;
			p2 = m_vcI + VEC3( i+1.f, 0.1f, j+0.f) * m_fW;
			p3 = m_vcI + VEC3( i+1.f, 0.1f, j+1.f) * m_fW;

			pVtx[nIdx *6 + 0] = VtxN( p0, n);
			pVtx[nIdx *6 + 1] = VtxN( p1, n);
			pVtx[nIdx *6 + 2] = VtxN( p2, n);
			pVtx[nIdx *6 + 3] = VtxN( p3, n);

			pVtx[nIdx *6 + 4] = pVtx[nIdx *6 + 2];
			pVtx[nIdx *6 + 5] = pVtx[nIdx *6 + 1];
		}
	}

	void *p;

	if( FAILED( hr = m_pVB->Lock( 0, 0, &p, 0 ) ) )
		return -1;

	memcpy(p, pVtx, 64* 64 * 3 * 2 * sizeof(VtxN));
	m_pVB->Unlock();

	free (pVtx);


	return 0;
}


void	CMcScene::Destroy()
{
	SAFE_RELEASE(	m_pVB	);
}

INT		CMcScene::FrameMove()
{
	return 0;
}

void	CMcScene::Render()
{
	ZeroMemory( &m_light, sizeof(m_light) );
	m_light.Type = D3DLIGHT_POINT;
	m_light.Direction = D3DXVECTOR3( 0.f, -1.f, 0.f );
	m_light.Range = 2500;
	m_light.Position = VEC3(100, 20, 300);
	m_light.Diffuse = D3DXCOLOR( 1, 0, 0, 1);

	m_light.Theta        = 0.3f;
    m_light.Phi          = 1.0f;
    m_light.Falloff      = 1.0f;
    m_light.Attenuation0 = 1.0f;

	m_pDev->SetLight( 0, &m_light );


	m_light.Position = VEC3(20, 20, 20);
	m_light.Diffuse = D3DXCOLOR( 0, 1, 0, 1);
	m_pDev->SetLight( 1, &m_light );


	m_light.Position = VEC3(300, 20, 20);
	m_light.Diffuse = D3DXCOLOR( 0, 0, 1, 1);
	m_light.Range		 = 100;
    m_light.Falloff      = 1.f;
    m_light.Attenuation0 = .0f;
	m_light.Attenuation1 = .1f;
	
	m_pDev->SetLight( 2, &m_light );


	m_light.Type = D3DLIGHT_SPOT;
	m_light.Position = VEC3(450, 250, 450);
	m_light.Diffuse = D3DXCOLOR( 0, 1, 1, 0);

	m_light.Range		 = 2500;
	m_light.Theta        = 0.1f;
    m_light.Phi          = 1.8f;
    m_light.Falloff      = 1.0f;
    m_light.Attenuation0 = 1.0f;
	m_light.Attenuation1 = 0.0f;
	
	

	m_pDev->SetLight( 3, &m_light );



	m_light.Type = D3DLIGHT_DIRECTIONAL;
	m_light.Diffuse = D3DXCOLOR( 0.2f, 0.2f, 0.2f, 1);
	m_pDev->SetLight( 4, &m_light );

	m_pDev->LightEnable( 0, TRUE );
	m_pDev->LightEnable( 1, TRUE );
	m_pDev->LightEnable( 2, TRUE );
	m_pDev->LightEnable( 3, TRUE );
	m_pDev->LightEnable( 4, TRUE );


	// Setup a material
	D3DMATERIAL9 mtrl={0};
	D3DXCOLOR	Color(1,1,1,1);

    mtrl.Diffuse = Color;
    mtrl.Specular= Color*.9f;
    mtrl.Ambient = Color*.4f;
    mtrl.Emissive= D3DXCOLOR(0.0f, 0.1f, .2f, 1);

	m_pDev->SetMaterial( &mtrl );



	m_pDev->SetRenderState( D3DRS_AMBIENT, D3DXCOLOR(0.2F, 0.1F, 0.9F, 1.F));


//	m_pDev->SetRenderState(D3DRS_FILLMODE, D3DFILL_WIREFRAME);
//	m_pDev->SetRenderState( D3DRS_DITHERENABLE,   FALSE );

	m_pDev->SetRenderState( D3DRS_LIGHTING,  TRUE);
	m_pDev->SetRenderState( D3DRS_SPECULARENABLE, TRUE);
	m_pDev->SetRenderState( D3DRS_CULLMODE,  D3DCULL_NONE);


	m_pDev->SetTexture(0, NULL);
	m_pDev->SetFVF(VtxN::FVF);
	m_pDev->SetStreamSource(0, m_pVB, 0, sizeof(VtxN));
	m_pDev->DrawPrimitive(D3DPT_TRIANGLELIST, 0, 64 * 64 * 2);
}



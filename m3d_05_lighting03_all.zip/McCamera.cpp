// Implementation of the CMcCamera class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMcCamera::CMcCamera()
{
	m_pDev = NULL;
}

CMcCamera::~CMcCamera()
{

}


INT CMcCamera::Create(LPDIRECT3DDEVICE9 pDev)
{
	m_pDev		= pDev;

	m_fYaw		= 0.f;
	m_fPitch	= 0.f;
	m_vcEye		= VEC3(200,250,-280);
	m_vcLook	= VEC3(200,50,0);
	m_vcUp		= VEC3(0,1,0);

	D3DXMatrixPerspectiveFovLH(&m_mtPrj,D3DX_PI/4.f, 800.f/600.f, 1.f, 5000.f);
	D3DXMatrixLookAtLH(&m_mtViw, &m_vcEye, &m_vcLook, &m_vcUp);

	return 0;
}


INT CMcCamera::FrameMove()
{
	// Wheel mouse...
	VEC3 vcD = g_pApp->m_pInput->GetMouseDelta();

	if(vcD.z !=0.f)
	{
		MoveForward(-vcD.z* 1.f, 1.f);
		D3DXMatrixLookAtLH(&m_mtViw, &m_vcEye, &m_vcLook, &m_vcUp);
	}

	if(g_pApp->m_pInput->KeyState(DIK_W))					// W
	{
		MoveForward( 3.f, 1.f);
		D3DXMatrixLookAtLH(&m_mtViw, &m_vcEye, &m_vcLook, &m_vcUp);
	}

	if(g_pApp->m_pInput->KeyState(DIK_S))					// S
	{
		MoveForward(-3.f, 1.f);
		D3DXMatrixLookAtLH(&m_mtViw, &m_vcEye, &m_vcLook, &m_vcUp);
	}


	if(g_pApp->m_pInput->KeyState(DIK_A))					// A
	{
		MoveSideward(-3.f);
		D3DXMatrixLookAtLH(&m_mtViw, &m_vcEye, &m_vcLook, &m_vcUp);
	}

	if(g_pApp->m_pInput->KeyState(DIK_D))					// D
	{
		MoveSideward(3.f);
		D3DXMatrixLookAtLH(&m_mtViw, &m_vcEye, &m_vcLook, &m_vcUp);
	}


	if(g_pApp->m_pInput->GetMouseSt(1))
	{
		VEC3	vcDelta = g_pApp->m_pInput->GetMouseDelta();
		m_fYaw   = D3DXToRadian(vcDelta.x * 0.1f);
		m_fPitch   = D3DXToRadian(vcDelta.y * 0.1f);

		MATA rot;
		VEC3 vcZ = m_vcLook-m_vcEye;
		VEC3 vcX;
		D3DXMatrixRotationY(&rot, m_fYaw);
		D3DXVec3TransformCoord(&vcZ, &vcZ, &rot);
		D3DXVec3TransformCoord(&m_vcUp, &m_vcUp, &rot);

		m_vcLook = vcZ + m_vcEye;
		D3DXMatrixLookAtLH(&m_mtViw, &m_vcEye, &m_vcLook, &m_vcUp);


		vcZ = m_vcLook - m_vcEye;
		vcX =VEC3(m_mtViw._11, m_mtViw._21, m_mtViw._31);

		D3DXMatrixRotationAxis(&rot, & vcX, m_fPitch);
		D3DXVec3TransformCoord(&vcZ, &vcZ, &rot);
		D3DXVec3TransformCoord(&m_vcUp, &m_vcUp, &rot);

		m_vcLook = vcZ + m_vcEye;
		D3DXMatrixLookAtLH(&m_mtViw, &m_vcEye, &m_vcLook, &m_vcUp);
	}



	m_pDev->SetTransform(D3DTS_VIEW, &m_mtViw);
	m_pDev->SetTransform(D3DTS_PROJECTION, &m_mtPrj);

	return 0;
}

void CMcCamera::MoveSideward(FLOAT fSpeed)
{
	VEC3 tmp(m_mtViw._11, 0, m_mtViw._31);
	D3DXVec3Normalize(&tmp,&tmp);

	m_vcEye  += tmp * fSpeed;
	m_vcLook += tmp * fSpeed;
}


void CMcCamera::MoveForward(FLOAT fSpeed, FLOAT fY)
{
	VEC3 tmp(m_mtViw._13, m_mtViw._23*fY, m_mtViw._33);
	D3DXVec3Normalize(&tmp,&tmp);

	m_vcEye  += tmp * fSpeed;
	m_vcLook += tmp * fSpeed;
}
// Implementation of the CLcMesh class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <stdio.h>

#include <d3d9.h>
#include <d3dx9.h>

#include "LcMesh.h"


#define SAFE_DELETE(p)       { if(p) { delete (p);     (p)=NULL; } }
#define SAFE_DELETE_ARRAY(p) { if(p) { delete[] (p);   (p)=NULL; } }
#define SAFE_RELEASE(p)      { if(p) { (p)->Release(); (p)=NULL; } }


CLcMesh::CLcMesh()
{
	memset(m_sName, 0, sizeof m_sName);

	m_pDev			= NULL;

	m_pMeshSrc		= NULL;
	m_pMeshDst		= NULL;
	m_nMaterial		= 0L;
	m_pMaterial		= NULL;
	m_pTexture		= NULL;

	m_bMaterial		= TRUE;
	m_bOpaque		= TRUE;
	m_bAlpha		= TRUE;
}


CLcMesh::~CLcMesh()
{
	Destroy();
}


INT CLcMesh::Create(LPDIRECT3DDEVICE9 pDev, char* sFile, LPD3DXFILEDATA pFileData)
{
	HRESULT			hr = -1;
	LPD3DXBUFFER	pAdjacency	= NULL;
	LPD3DXBUFFER	pMaterial	= NULL;
	DWORD			dOption		= D3DXMESH_MANAGED;
	DWORD			dFlag		= D3DXMESHOPT_COMPACT | D3DXMESHOPT_ATTRSORT | D3DXMESHOPT_VERTEXCACHE;
	DWORD			dFVF		= 0;	

	m_pDev = pDev;
	
	if(sFile)
	{
		strcpy(m_sName, sFile );

		hr = D3DXLoadMeshFromX( m_sName
								, dOption
								, m_pDev
								, &pAdjacency
								, &pMaterial
								, NULL
								, &m_nMaterial
								, &m_pMeshSrc );
	
		if( FAILED(hr))
			return -1;
	}

	else if(pFileData)
	{
		DWORD	dLen;
		pFileData->GetName(m_sName, &dLen);
		hr = D3DXLoadMeshFromXof( pFileData
								, dOption
								, m_pDev
								, &pAdjacency
								, &pMaterial
								, NULL
								, &m_nMaterial
								, &m_pMeshSrc
								);

		if( FAILED(hr))
			return -1;
	}
	

	hr = m_pMeshSrc->OptimizeInplace( dFlag
									, (DWORD*)pAdjacency->GetBufferPointer()
									, NULL
									, NULL
									, NULL );

	if(FAILED(hr))
		return -1;
	
	
	if( pMaterial && m_nMaterial > 0 )
	{
		D3DXMATERIAL* d3dxMtrls = (D3DXMATERIAL*)pMaterial->GetBufferPointer();

		m_pMaterial = new D3DMATERIAL9[m_nMaterial];
		m_pTexture  = new LPDIRECT3DTEXTURE9[m_nMaterial];

		// Copy each material and create its texture
		for( DWORD i=0; i<m_nMaterial; i++ )
		{
			// Copy the material
			m_pMaterial[i]         = d3dxMtrls[i].MatD3D;
			m_pTexture[i]          = NULL;
			
			// Create a texture
			if( d3dxMtrls[i].pTextureFilename )
			{
				TCHAR strTexture[MAX_PATH];
				sprintf( strTexture, "model/%s", d3dxMtrls[i].pTextureFilename);
				
				if( FAILED( D3DXCreateTextureFromFile( m_pDev, strTexture, &m_pTexture[i] ) ) )
					m_pTexture[i] = NULL;
			}
		}
	}
	

	SAFE_RELEASE( pAdjacency );
	SAFE_RELEASE( pMaterial );


//	dFVF= m_pMeshSrc->GetFVF();	
//	hr	= m_pMeshSrc->CloneMeshFVF(dOption, dFVF, m_pDev, &m_pMeshDst);
//
//	if(FAILED(hr))
//		return -1;

	return 0;
}



void CLcMesh::Destroy()
{
	for( UINT i=0; i<m_nMaterial; i++ )
		SAFE_RELEASE( m_pTexture[i] );

	SAFE_DELETE_ARRAY( m_pTexture );
	SAFE_DELETE_ARRAY( m_pMaterial );
	

	SAFE_RELEASE( m_pMeshDst );
	SAFE_RELEASE( m_pMeshSrc );
	
	m_nMaterial = 0L;
}



INT CLcMesh::Restore()
{
	DWORD		dOption	= D3DXMESH_MANAGED;
	DWORD		dFVF	= m_pMeshSrc->GetFVF();	

	return m_pMeshSrc->CloneMeshFVF(dOption, dFVF, m_pDev, &m_pMeshDst);
}


void CLcMesh::Invalidate()
{
	SAFE_RELEASE( m_pMeshDst );
}



INT CLcMesh::FrameMove()
{
	return 0;
}



void CLcMesh::Render()
{
	if( m_bOpaque )
	{
		for( DWORD i=0; i<m_nMaterial; i++ )
		{
			if( m_bMaterial )
			{
				if( m_pMaterial[i].Diffuse.a < 1.0f )
					continue;
				
				m_pDev->SetMaterial( &m_pMaterial[i] );
				m_pDev->SetTexture( 0, m_pTexture[i] );
			}

			if(m_pMeshDst)
				m_pMeshDst->DrawSubset( i );
			else
				m_pMeshSrc->DrawSubset( i );
		}
	}
	
	if( m_bAlpha && m_bMaterial )
	{
		for( DWORD i=0; i<m_nMaterial; i++ )
		{
			if( m_pMaterial[i].Diffuse.a == 1.0f )
				continue;
			
			m_pDev->SetMaterial( &m_pMaterial[i] );
			m_pDev->SetTexture( 0, m_pTexture[i] );

			if(m_pMeshDst)
				m_pMeshDst->DrawSubset( i );
			else
				m_pMeshSrc->DrawSubset( i );
		}
	}
}



INT CLcMesh::SetFVF(DWORD dFVF)
{
	HRESULT		hr = 0;

	LPD3DXMESH	pMeshSrc	= NULL;
	LPD3DXMESH	pMeshDst	= NULL;
	DWORD		dOption		= D3DXMESH_MANAGED;
	
	if(m_pMeshSrc)
	{
		hr = m_pMeshSrc->CloneMeshFVF( dOption, dFVF, m_pDev, &pMeshSrc );

		if( FAILED(hr))
			return -1;
	}

	if(m_pMeshDst)
	{
		hr = m_pMeshDst->CloneMeshFVF( 0L, dFVF, m_pDev, &pMeshDst );

		if( FAILED(hr))
			return -1;
	}
	
	SAFE_RELEASE(	m_pMeshSrc	);
	SAFE_RELEASE(	m_pMeshDst	);
	
	m_pMeshSrc	= pMeshSrc;
	m_pMeshDst	= pMeshDst;
	
	D3DXComputeNormals( m_pMeshSrc, NULL);
	D3DXComputeNormals( m_pMeshDst, NULL);

	return 0;
}




INT CLcMesh::SetVertexDecl(D3DVERTEXELEMENT9* pDecl)
{
	HRESULT		hr = 0;

	LPD3DXMESH	pMeshSrc	= NULL;
	LPD3DXMESH	pMeshDst	= NULL;
	DWORD		dOption		= D3DXMESH_MANAGED;
	
	if( m_pMeshSrc )
	{
		hr = m_pMeshSrc->CloneMesh( dOption, pDecl, m_pDev, &pMeshSrc );

		if( FAILED(hr))
			return -1;
	}
	
	if( m_pMeshDst )
	{
		hr = m_pMeshDst->CloneMesh( 0L, pDecl, m_pDev, &pMeshDst );

		if( FAILED(hr))
			return -1;
	}
	
	SAFE_RELEASE( m_pMeshSrc );
	SAFE_RELEASE( m_pMeshDst );
	
	m_pMeshSrc = pMeshSrc;
	m_pMeshDst = pMeshDst;

	D3DXComputeNormals( m_pMeshSrc, NULL );
	D3DXComputeNormals( m_pMeshDst, NULL );

	return 0;
}





void CLcMesh::SetOpaqueSubsets(BOOL val)
{
	m_bOpaque	= val;
}

void CLcMesh::SetAlphaSubsets(BOOL val)
{
	m_bAlpha	= val;
}
	

void CLcMesh::UseMeshMaterials( BOOL bFlag )
{
	m_bMaterial= bFlag;
}


void* CLcMesh::GetMeshSrc()
{
	return m_pMeshSrc;
}


void* CLcMesh::GetMeshDst()
{
	return m_pMeshDst;
}
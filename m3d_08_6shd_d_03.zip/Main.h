// Interface for the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _MAIN_H_
#define _MAIN_H_


struct VtxRHWD
{
	D3DXVECTOR4 p;
	D3DCOLOR    d;
	
	enum {	FVF = (D3DFVF_XYZRHW | D3DFVF_DIFFUSE),};
};



class CMain : public CD3DApplication
{
protected:
	CLcInput*		m_pInput;
	CLcCam*			m_pCam;
	CLcGrid*		m_pGrid;
	ID3DXFont*      m_pD3DXFont;            // D3DX font

	CLcField*		m_pField;


	CLcMesh*		m_pAirplane;
	CLcShadow*		m_pShadow;
	
	D3DXMATRIX		m_mtObject;
	VtxRHWD			m_pRhw[4];

public:
	CMain();
    
	virtual HRESULT Init();
    virtual HRESULT Destroy();

    virtual HRESULT Restore();
    virtual HRESULT Invalidate();

    virtual HRESULT FrameMove();
    virtual HRESULT Render();

	virtual LRESULT MsgProc( HWND, UINT, WPARAM, LPARAM);

    HRESULT RenderText();

public:
	HRESULT DrawShadow();
	HRESULT RenderShadow();
};


extern CMain* g_pApp;

#endif




// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMain::CMain()
{
	strcpy(m_strClassName, "Mackerel");

	m_dwCreationWidth			= 800;
	m_dwCreationHeight			= 600;
	
	m_bStartFullscreen			= false;
	m_bShowCursorWhenFullscreen	= true;

	m_dRscMenu		= 0;
	m_dRscAccel		= IDR_MAIN_ACCEL;

	m_dRscDevice	= IDM_CHANGEDEVICE;
	m_dRscToggle	= IDM_TOGGLEFULLSCREEN;
	m_dRscExit		= IDM_EXIT;

	m_pInput		= NULL;
	m_pGrid			= NULL;
	m_pCam			= NULL;
	m_pD3DXFont		= NULL;

	m_pField		= NULL;

	m_pShadow		= NULL;
}



HRESULT CMain::Init()
{
	HRESULT hr=-1;

	// Input ����
	m_pInput = new CLcInput;
	m_pInput->Create(m_hWnd);

	// Grid����
	m_pGrid = new CLcGrid;
	m_pGrid->Create(m_pd3dDevice);

	// ī�޶� ����
	m_pCam = new CLcCam;
	m_pCam->Create(m_pd3dDevice);


	// Create a D3D font using D3DX
	D3DXFONT_DESC hFont =
	{
		16, 0
		, FW_NORMAL, 1, FALSE
		, HANGUL_CHARSET
		, OUT_DEFAULT_PRECIS
		, ANTIALIASED_QUALITY, FF_DONTCARE, "Arial"
	};

	if( FAILED( hr = D3DXCreateFontIndirect( m_pd3dDevice, &hFont, &m_pD3DXFont ) ) )
		return -1;


	m_pField	= new CLcField;
	if(FAILED(m_pField->Create(m_pd3dDevice, "data/Field_Height10.raw", "data/map_diffuse.png", "data/map_dtail.png")))
		return -1;



	D3DXMatrixIdentity(&m_mtObject);
	D3DXMATRIX	mtT;
	D3DXMATRIX	mtS;
	D3DXMatrixTranslation(&mtT, 400, 100, 300);
	D3DXMatrixScaling(&mtS, 10, 10, 10);

	m_mtObject	= mtS * mtT;

	m_pShadow = new CLcShadow;
	if( FAILED( m_pShadow->Create( m_pd3dDevice) ))
		return -1;

	m_pAirplane       = new CLcMesh;
	if( FAILED( m_pAirplane->Create( m_pd3dDevice, _T("Model/airplane 2.x") )	))
		return -1;

	DWORD	dFVF = (D3DFVF_XYZ | D3DFVF_NORMAL | D3DFVF_TEX1);
	m_pAirplane->SetFVF( dFVF );
	


	FLOAT sx = (FLOAT)m_d3dsdBackBuffer.Width;
	FLOAT sy = (FLOAT)m_d3dsdBackBuffer.Height;
	
	m_pRhw[0].p = D3DXVECTOR4(  0, sy, 0.0f, 1.0f );
	m_pRhw[1].p = D3DXVECTOR4(  0,  0, 0.0f, 1.0f );
	m_pRhw[2].p = D3DXVECTOR4( sx, sy, 0.0f, 1.0f );
	m_pRhw[3].p = D3DXVECTOR4( sx,  0, 0.0f, 1.0f );

	m_pRhw[0].d = 0xbf000000;
	m_pRhw[1].d = 0xbf000000;
	m_pRhw[2].d = 0xbf000000;
	m_pRhw[3].d = 0xbf000000;

	return S_OK;
}



HRESULT CMain::Destroy()
{
	SAFE_DELETE(	m_pGrid		);
	SAFE_DELETE(	m_pCam		);
	SAFE_DELETE(	m_pInput	);
	SAFE_RELEASE(	m_pD3DXFont	);

	SAFE_DELETE(	m_pField	);


	SAFE_DELETE( m_pAirplane );
	SAFE_DELETE( m_pShadow	);

	return S_OK;
}



HRESULT CMain::Restore()
{
	m_pD3DXFont->OnResetDevice();

	m_pd3dDevice->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP);
	m_pd3dDevice->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);

	m_pd3dDevice->SetSamplerState(0, D3DSAMP_MINFILTER , D3DTEXF_LINEAR);
	m_pd3dDevice->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pd3dDevice->SetSamplerState(0, D3DSAMP_MIPFILTER , D3DTEXF_LINEAR);

	m_pd3dDevice->SetRenderState( D3DRS_LIGHTING,  FALSE);
	m_pd3dDevice->SetRenderState( D3DRS_ALPHABLENDENABLE,  FALSE);
	m_pd3dDevice->SetRenderState( D3DRS_ALPHATESTENABLE,  FALSE);
	m_pd3dDevice->SetRenderState(D3DRS_FOGENABLE, FALSE);

	return S_OK;
}



HRESULT CMain::Invalidate()
{
	m_pD3DXFont->OnLostDevice();

	return S_OK;
}



HRESULT CMain::FrameMove()
{
	m_pInput->FrameMove();

	// Wheel mouse...
	D3DXVECTOR3 vcD = m_pInput->GetMouseEps();

	if(vcD.z !=0.f)
		m_pCam->MoveForward(-vcD.z* .1f, 1.f);

	if(m_pInput->KeyState('W'))					// W
		m_pCam->MoveForward( 4.f, 1.f);

	if(m_pInput->KeyState('S'))					// S
		m_pCam->MoveForward(-4.f, 1.f);

	if(m_pInput->KeyState('A'))					// A
		m_pCam->MoveSideward(-4.f);

	if(m_pInput->KeyState('D'))					// D
		m_pCam->MoveSideward(4.f);
	

	if(m_pInput->BtnPress(1))
	{
		D3DXVECTOR3 vcDelta = m_pInput->GetMouseEps();
		m_pCam->Rotation(vcDelta);		
	}


	if(m_pInput->KeyState(VK_UP))
		m_mtObject._43 +=1.f;

	if(m_pInput->KeyState(VK_DOWN))
		m_mtObject._43 -=1.f;

	if(m_pInput->KeyState(VK_RIGHT))
		m_mtObject._41 +=1.f;

	if(m_pInput->KeyState(VK_LEFT))
		m_mtObject._41 -=1.f;

	m_pCam->FrameMove();


	D3DXVECTOR3 vL;

	vL.x =   10;
	vL.y =   15;
	vL.z =    0;

	D3DXVec3Normalize( &vL, &vL);
	

	// Build the shadow volume
	m_pShadow->Reset();
	m_pShadow->Build( (LPD3DXMESH)m_pAirplane->GetMeshSrc(), m_mtObject, vL);

	return S_OK;
}


HRESULT CMain::Render()
{
	static D3DXMATRIX mtI(1,0,0,0,    0,1,0,0,    0,0,1,0,    0,0,0,1);
	m_pd3dDevice->Clear( 0L
						, NULL
						, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER | D3DCLEAR_STENCIL
						, 0x00006699
						, 1.0f
						, 0L );

	m_pCam->SetTransform();

	if( FAILED( m_pd3dDevice->BeginScene() ) )
		return -1;

	
	m_pd3dDevice->SetTransform(D3DTS_WORLD, &mtI);
	m_pField->Render();

	
	RenderShadow();
	DrawShadow();

	m_pd3dDevice->SetTransform( D3DTS_WORLD, &m_mtObject );
	m_pAirplane->Render();
	m_pd3dDevice->SetTransform( D3DTS_WORLD, &mtI );


	RenderText();

	m_pd3dDevice->EndScene();

	return S_OK;
}







HRESULT CMain::RenderText()
{
	D3DCOLOR fontColor		= D3DCOLOR_ARGB(255,255,255,0);
	TCHAR szMsg[MAX_PATH]	= {0};

	sprintf( szMsg, "%s %s", m_strDeviceStats, m_strFrameStats );

	

	RECT rct={ 10, 10, m_d3dsdBackBuffer.Width - 20, 10+30};
	m_pD3DXFont->DrawText(NULL, szMsg, -1, &rct, 0, fontColor );

	

	return S_OK;
}



LRESULT CMain::MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
	if(m_pInput)
		m_pInput->MsgProc(hWnd, msg, wParam, lParam);
	
	switch( msg )
	{
		case WM_PAINT:
		{
			if( m_bLoadingApp )
			{
				HDC hDC = GetDC( hWnd );
				TCHAR strMsg[MAX_PATH];
				wsprintf( strMsg, TEXT("Loading... Please wait") );
				RECT rct;
				GetClientRect( hWnd, &rct );
				DrawText( hDC, strMsg, -1, &rct, DT_CENTER|DT_VCENTER|DT_SINGLELINE );
				ReleaseDC( hWnd, hDC );
			}
			break;
		}

	}

	return CD3DApplication::MsgProc( hWnd, msg, wParam, lParam );
}









HRESULT CMain::RenderShadow()
{
	m_pd3dDevice->SetRenderState( D3DRS_ZWRITEENABLE,  FALSE );		// Z-buffer�� �������� �ʴ´�.
	m_pd3dDevice->SetRenderState( D3DRS_COLORWRITEENABLE, FALSE);	// ���� ���۸� �������� �ʴ´�.
	m_pd3dDevice->SetRenderState( D3DRS_STENCILENABLE, TRUE );		// ���ٽǸ� �����Ѵ�.


	m_pd3dDevice->SetRenderState( D3DRS_STENCILREF, 0x1);
	m_pd3dDevice->SetRenderState( D3DRS_STENCILMASK, 0xffffffff );
	m_pd3dDevice->SetRenderState( D3DRS_STENCILWRITEMASK, 0xffffffff );
	m_pd3dDevice->SetRenderState( D3DRS_STENCILFUNC, D3DCMP_ALWAYS );


	
	// With 2-sided stencil, we can avoid rendering twice:
	if( ( m_d3dCaps.StencilCaps & D3DSTENCILCAPS_TWOSIDED ) != 0 )
	{
		m_pd3dDevice->SetRenderState( D3DRS_TWOSIDEDSTENCILMODE, TRUE );		// ��� ���ٽ��� ����Ѵ�.
		m_pd3dDevice->SetRenderState( D3DRS_CULLMODE,  D3DCULL_NONE);			// ����� �׸���.

		m_pd3dDevice->SetRenderState( D3DRS_STENCILPASS,   D3DSTENCILOP_KEEP);
		m_pd3dDevice->SetRenderState( D3DRS_STENCILFAIL,   D3DSTENCILOP_KEEP);
		m_pd3dDevice->SetRenderState( D3DRS_STENCILZFAIL,  D3DSTENCILOP_INCR);	// CW�� �׸��� �ﰢ�� �߿��� Z-FAIL�� ���� 1 ����

		m_pd3dDevice->SetRenderState( D3DRS_CCW_STENCILPASS, D3DSTENCILOP_KEEP);
		m_pd3dDevice->SetRenderState( D3DRS_CCW_STENCILFAIL, D3DSTENCILOP_KEEP);
		m_pd3dDevice->SetRenderState( D3DRS_CCW_STENCILZFAIL,D3DSTENCILOP_DECR);// CCW�� �׸��� �ﰢ�� �߿��� Z-FAIL�� ���� 1 ����
		
		m_pShadow->Render();

		m_pd3dDevice->SetRenderState( D3DRS_TWOSIDEDSTENCILMODE, FALSE );
	}
	else
	{
		m_pd3dDevice->SetRenderState( D3DRS_STENCILZFAIL,	D3DSTENCILOP_INCR);	// �ո��� ���ٽ� ���� 1 ����
		m_pd3dDevice->SetRenderState( D3DRS_STENCILFAIL,	D3DSTENCILOP_KEEP);
		m_pd3dDevice->SetRenderState( D3DRS_STENCILPASS,    D3DSTENCILOP_KEEP);

		m_pd3dDevice->SetRenderState( D3DRS_CULLMODE,   D3DCULL_CCW );			// �ո��� �׸���.
		m_pShadow->Render();
		

		m_pd3dDevice->SetRenderState( D3DRS_STENCILZFAIL,	D3DSTENCILOP_DECR);	// �޸��� ���ٽ� ���� 1 ����
		m_pd3dDevice->SetRenderState( D3DRS_CULLMODE,   D3DCULL_CW );			// �޸��� �׸���.		
		m_pShadow->Render();
	}
	

	
	// ���� ���ٽ� ���� 0x1���� ũ�ų� ����.
	
	// Restore render states
	m_pd3dDevice->SetRenderState( D3DRS_COLORWRITEENABLE, 0xF);
	m_pd3dDevice->SetRenderState( D3DRS_CULLMODE,  D3DCULL_CCW );
	m_pd3dDevice->SetRenderState( D3DRS_ZWRITEENABLE,     TRUE );
	m_pd3dDevice->SetRenderState( D3DRS_STENCILENABLE,    FALSE );
	m_pd3dDevice->SetRenderState( D3DRS_ALPHABLENDENABLE, FALSE );


	static D3DXMATRIX mtI(1,0,0,0,    0,1,0,0,    0,0,1,0,    0,0,0,1);
	m_pd3dDevice->SetTransform( D3DTS_WORLD, &mtI );
	
	return S_OK;
}




HRESULT CMain::DrawShadow()
{
	m_pd3dDevice->SetRenderState( D3DRS_ZENABLE,          FALSE );
	m_pd3dDevice->SetRenderState( D3DRS_STENCILENABLE,    TRUE );
	m_pd3dDevice->SetRenderState( D3DRS_FOGENABLE,        FALSE );
	m_pd3dDevice->SetRenderState( D3DRS_ALPHABLENDENABLE, TRUE );
	m_pd3dDevice->SetRenderState( D3DRS_SRCBLEND,  D3DBLEND_SRCALPHA );
	m_pd3dDevice->SetRenderState( D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA );
	
	m_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	m_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
	m_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE );
	m_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );
	m_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE );
	m_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_MODULATE );
	
	// Only write where stencil val >= 1 (count indicates # of shadows that overlap that pixel)
	m_pd3dDevice->SetRenderState( D3DRS_STENCILREF,  0x1 );
	m_pd3dDevice->SetRenderState( D3DRS_STENCILFUNC, D3DCMP_LESS);
	m_pd3dDevice->SetRenderState( D3DRS_STENCILPASS, D3DSTENCILOP_KEEP );
	
	// Draw a big, gray square
	m_pd3dDevice->SetTexture(0, NULL);
	m_pd3dDevice->SetFVF( VtxRHWD::FVF );
	m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLESTRIP, 2, m_pRhw, sizeof(VtxRHWD) );
	
	// Restore render states
	m_pd3dDevice->SetRenderState( D3DRS_ZENABLE,          TRUE );
	m_pd3dDevice->SetRenderState( D3DRS_STENCILENABLE,    FALSE );
	m_pd3dDevice->SetRenderState( D3DRS_FOGENABLE,        FALSE );
	m_pd3dDevice->SetRenderState( D3DRS_ALPHABLENDENABLE, FALSE );
	
	m_pd3dDevice->SetRenderState( D3DRS_STENCILENABLE,    FALSE);

	return S_OK;
}
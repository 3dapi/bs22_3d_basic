// Implementation of the CMcInput class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMcInput::CMcInput()
{
	m_hWnd		= NULL;

	m_pDInput	= NULL;
	m_pDiKey	= NULL;
	m_pDiMs		= NULL;
}

CMcInput::~CMcInput()
{
	if(m_pDiKey)
	{
		m_pDiKey->Unacquire();
		m_pDiKey->Release();
		m_pDiKey	= NULL;
	}

	if(m_pDiMs)
	{
		m_pDiMs->Unacquire();
		m_pDiMs->Release();
		m_pDiMs	= NULL;
	}

	if(m_pDInput)
	{
		m_pDInput->Release();
		m_pDInput	= NULL;
	}
}


INT CMcInput::Create(HWND hWnd)
{
	m_hWnd	= hWnd;

	memset(KeyCur, 0, sizeof(KeyCur));
	memset(KeyOld, 0, sizeof(KeyOld));

	memset(&m_vcMsCur, 0, sizeof (m_vcMsCur));
	memset(&m_vcMsOld, 0, sizeof(m_vcMsOld));
	memset(&MsStCur, 0, sizeof(MsStCur));
	memset(&MsStOld, 0, sizeof(MsStOld));





	InitDInput();

	RECT  rct={0};
	::GetClientRect(m_hWnd, &rct);

	m_vcMsCur.x = float( (rct.right - rct.left)/2 );
	m_vcMsCur.y = float( (rct.bottom- rct.top )/2 );

	POINT Point={ int(m_vcMsCur.x), int(m_vcMsCur.y)};

	::ClientToScreen(m_hWnd, &Point);
	::SetCursorPos(Point.x, Point.y);
	

	m_vcMsOld.x = m_vcMsCur.x;
	m_vcMsOld.y = m_vcMsCur.y;

	return 0;
}

INT CMcInput::FrameMove()
{
	m_vcDelta = m_vcMsCur - m_vcMsOld;

	memcpy(KeyOld		, KeyCur	, sizeof(KeyCur		));
	memcpy(&m_vcMsOld	, &m_vcMsCur, sizeof(m_vcMsCur	));
	memcpy(&MsStOld		, &MsStCur	, sizeof(MsStCur	));
	
	memset(&MsStCur, 0  , sizeof(MsStCur));

//	UpdateGeneral();
	UpdateDInput();



	
	return 0;
}


BOOL CMcInput::GetKey(INT cKey)
{
	return (KeyCur[cKey] & 0x80 && KeyOld[cKey] != KeyCur[cKey]);
}

BOOL CMcInput::KeyState(INT cKey)
{
	return (KeyCur[cKey] & 0x80 && TRUE);
}

BOOL CMcInput::GetMouseSt(INT nBtn)
{
	return MsStOld.rgbButtons[nBtn]? TRUE: FALSE;
}

D3DXVECTOR3	CMcInput::GetMousePos()
{
	return m_vcMsCur;
}


D3DXVECTOR3	CMcInput::GetMouseDelta()
{
	return m_vcDelta;
}

INT CMcInput::InitDInput()
{
	HINSTANCE	hInst = (HINSTANCE) GetModuleHandle(NULL);

	// DirectInput Create
	if (FAILED(DirectInput8Create(	hInst,	DIRECTINPUT_VERSION,	IID_IDirectInput8,	(void **)&m_pDInput,	NULL)))
		return -1;


// Keyboard Device
if (FAILED(m_pDInput->CreateDevice(GUID_SysKeyboard, &m_pDiKey, NULL)))
{
	MessageBox(m_hWnd, "Create keboard device failed","Err" , MB_OK | MB_ICONERROR);
	return -1;
}

// Mouse Device
if (FAILED(m_pDInput->CreateDevice(GUID_SysMouse, &m_pDiMs, NULL)))
{
	MessageBox(0, "Create mouse device failed", "Err", MB_ICONERROR);
	return -1;
}


	// Setup Data Format
	if (FAILED(m_pDiKey->SetDataFormat(&c_dfDIKeyboard)))
	{
		MessageBox(m_hWnd, "Set Data format failed", "Err", MB_OK | MB_ICONERROR);
		return -1;
	}

	if (FAILED(m_pDiMs->SetDataFormat(&c_dfDIMouse)))
	{
		MessageBox(0, "Set mouse data format failed", "Err", MB_ICONERROR);
		return -1;
	}


	// Setup Cooperative Level	
	if (FAILED(m_pDiKey->SetCooperativeLevel(m_hWnd, DISCL_FOREGROUND | DISCL_NONEXCLUSIVE | DISCL_NOWINKEY)))
	{
		MessageBox(m_hWnd, "Set cooperativelevel failed", "Err", MB_OK | MB_ICONERROR);
		return -1;
	}

	if (FAILED(m_pDiMs->SetCooperativeLevel(m_hWnd, DISCL_FOREGROUND | DISCL_NONEXCLUSIVE | DISCL_NOWINKEY)))
	{
		MessageBox(0, "Set mouse cooperativelevel failed", "Err", MB_ICONERROR);
		return -1;
	}

	// Device Acquire
	m_pDiKey->Acquire();
	m_pDiMs->Acquire();
	
	return 0;
}


INT CMcInput::UpdateDInput()
{
	// Keyboard
	if (FAILED(m_pDiKey->GetDeviceState(sizeof(KeyCur), (LPVOID)KeyCur)))
	{
		memset(KeyCur, 0, sizeof(KeyCur));

		if (FAILED(m_pDiKey->Acquire()))
			return -1;	// Acquire�� �� �Ǹ� ���α׷� ���� �߻�

		if (FAILED(m_pDiKey->GetDeviceState(sizeof(KeyCur), (LPVOID)KeyCur)))
			return -1;	// Acquire�� �Ǿ GetDeviceState() ���и� ���α׷� ���� �߻�
	}


	// Mouse
	if (FAILED(m_pDiMs->GetDeviceState(sizeof(DIMOUSESTATE), &MsStCur)))
	{
		if (FAILED(m_pDiMs->Acquire()))
			return -1;

		if (FAILED(m_pDiMs->GetDeviceState(sizeof(DIMOUSESTATE), &MsStCur)))
			return -1;
	}


	// ���� ��ġ += D3DXVECTOR3(st.lX, st.lY, st.lZ);
	m_vcMsCur.x += FLOAT(MsStCur.lX);
	m_vcMsCur.y += FLOAT(MsStCur.lY);
	m_vcMsCur.z += FLOAT(MsStCur.lZ);


//	POINT	MsPos;
//	::GetCursorPos(&MsPos);
//	::ScreenToClient(m_hWnd, &MsPos);
//
//	//if Device Exist
//	//m_pd3dDevice->SetCursorPosition( MsPos.x, MsPos.y, 0 );
//
//	m_vcMsCur.x = FLOAT(MsPos.x);
//	m_vcMsCur.y = FLOAT(MsPos.y);


	// Ŀ���� ��ġ�� �ٽ� ����
	POINT Point={ int(m_vcMsCur.x), int(m_vcMsCur.y)};
	::ClientToScreen(m_hWnd, &Point);
	::SetCursorPos(Point.x, Point.y);

	return 0;
}
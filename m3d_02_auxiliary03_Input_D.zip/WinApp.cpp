// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


LRESULT WINAPI WndProc( HWND, UINT, WPARAM, LPARAM);


INT CMain::Create( HINSTANCE hInst)
{
	m_hInst	= hInst;
	

	// ������ Ŭ���� ���
	WNDCLASS wc =
	{
		CS_DBLCLKS
			, WndProc
			, 0
			, 0
			, m_hInst
			, LoadIcon(NULL, IDI_APPLICATION)
			, LoadCursor(NULL, IDC_ARROW)
			, (HBRUSH)GetSysColorBrush( COLOR_WINDOW )
			,	NULL
			, m_sCls
	};

	RegisterClass( &wc );

	
	// ������ ����

	RECT rc;
	
	SetRect( &rc, 0, 0, 800, 600);
	AdjustWindowRect( &rc, (WS_OVERLAPPED | WS_CAPTION |WS_SYSMENU|WS_VISIBLE), false );
		
	int iScnSysW = ::GetSystemMetrics(SM_CXSCREEN);
	int iScnSysH = ::GetSystemMetrics(SM_CYSCREEN);
	
	m_hWnd = CreateWindow( m_sCls
		, m_sCls
		, WS_OVERLAPPED | WS_CAPTION |WS_SYSMENU|WS_VISIBLE
		, (iScnSysW - (rc.right-rc.left))/2
		, (iScnSysH - (rc.bottom-rc.top))/2
		, (rc.right-rc.left)
		, (rc.bottom-rc.top)
		, 0
		, NULL
		, m_hInst
		, NULL );
	

	// Save window properties
	Init();
	
	ShowWindow( m_hWnd, SW_SHOW );
	UpdateWindow( m_hWnd );
	
	return S_OK;
}


void CMain::Cleanup()
{
	Destroy();

	ReleaseDC(m_hWnd, m_hDC);
}

INT CMain::Run()
{	    
	// Enter the message loop
	MSG msg;
	memset( &msg, 0, sizeof(msg) );
	
	while( msg.message!=WM_QUIT )
	{
		if( PeekMessage( &msg, NULL, 0U, 0U, PM_REMOVE ) )
		{
			TranslateMessage( &msg );
			DispatchMessage( &msg );
		}
		else
		{
			if(FAILED(FrameMove()))
			{
				SendMessage(m_hWnd, WM_CLOSE, 0,0);
				break;
			}

			if(FAILED(Render()))
			{
				SendMessage(m_hWnd, WM_CLOSE, 0,0);
				break;
			}
		}
	}

	Sleep(100);
	
	return 0;
}


LRESULT CMain::MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
	switch( msg )
	{
		case WM_CLOSE:
		{
			HMENU hMenu = NULL;
			hMenu = GetMenu(hWnd);

			if( hMenu != NULL )
				DestroyMenu( hMenu );
		}

		case WM_DESTROY:
		{
			Cleanup();
			PostQuitMessage( 0 );
			return 0;
		}
	}
	
	return DefWindowProc( hWnd, msg, wParam, lParam );
}
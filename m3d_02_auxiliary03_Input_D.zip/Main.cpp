// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMain::CMain()
{
	strcpy(m_sCls, "Mck_D3D");

	m_hInst			= NULL;
	m_hWnd			= NULL;
	m_hDC			= NULL;

	m_pInput		= NULL;
}

INT CMain::Init()
{
	if(NULL == m_pInput)
	{
		m_pInput = new CMcInput();

		if(FAILED(m_pInput->Create(m_hWnd)))
		{
			delete m_pInput;
			m_pInput	= NULL;

			return -1;
		};
	}

	::SetWindowText(m_hWnd, "Press Right Key or Left Button");

	return 0;
}

void CMain::Destroy()
{
	if(m_pInput)
	{
		delete m_pInput;
		m_pInput = NULL;
	}
}


INT CMain::FrameMove()
{
	if(m_pInput)
		m_pInput->FrameMove();

	
	D3DXVECTOR3	vcPos = m_pInput->GetMousePos();

	sprintf(m_sTitle, "Mouse Pos: (%5.f, %5.f, %5.f)", vcPos.x, vcPos.y, vcPos.z);
	SetWindowText(m_hWnd, m_sTitle);


	if(m_pInput->GetKey(DIK_SPACE))
	{
		PAINTSTRUCT	ps;
		D3DXVECTOR3	vcPos = m_pInput->GetMousePos();
	
		sprintf(m_sTitle, "You Pressed Space Key");

		

		InvalidateRect(m_hWnd, 0, 1);
		m_hDC = BeginPaint(m_hWnd, &ps);

		SetBkMode(m_hDC, TRANSPARENT);
		TextOut(m_hDC, int(vcPos.x), int(vcPos.y), m_sTitle, strlen(m_sTitle));
		EndPaint(m_hWnd, &ps);

		ReleaseDC(m_hWnd, m_hDC);
	}


	return 0;
}


INT CMain::Render()
{

	return 0;
}
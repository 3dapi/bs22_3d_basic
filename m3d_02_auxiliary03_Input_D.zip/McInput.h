// Interface for the CMcInput class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MCINPUT_H_
#define _MCINPUT_H_

class CMcInput
{
public:
	enum
	{
		MAX_INPUT_KEY = 256,
		MAX_INPUT_BTN = 8,
	};


protected:
	HWND					m_hWnd;
	LPDIRECTINPUT8			m_pDInput;		//DInput Instance
	LPDIRECTINPUTDEVICE8	m_pDiKey;		// Keyboard Device Instance
	LPDIRECTINPUTDEVICE8	m_pDiMs;		// Mouse Device Instance

	BYTE					KeyCur[MAX_INPUT_KEY];
	BYTE					KeyOld[MAX_INPUT_KEY];
	D3DXVECTOR3				m_vcMsCur;
	D3DXVECTOR3				m_vcMsOld;
	D3DXVECTOR3				m_vcDelta;
	DIMOUSESTATE			MsStCur;
	DIMOUSESTATE			MsStOld;

public:
	CMcInput();
	~CMcInput();

	INT			Create(HWND hWnd);
	INT			FrameMove();

	BOOL		GetKey(INT cKey);
	BOOL		KeyState(INT cKey);

	D3DXVECTOR3	GetMousePos();
	D3DXVECTOR3	GetMouseDelta();
	BOOL		GetMouseSt(INT nM);


protected:
	INT			InitDInput();
	INT			UpdateDInput();
};

#endif

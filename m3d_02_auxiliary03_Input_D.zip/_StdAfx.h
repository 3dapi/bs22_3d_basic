#pragma warning(disable: 4324)
#pragma warning(disable: 4996)


#ifndef __STDAFX_H_
#define __STDAFX_H_


#define _WIN32_WINNT 0x0400

#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <mmsystem.h>

#include <d3d9.h>
#include <d3dx9.h>

#pragma comment(lib, "dinput8.lib")
#pragma comment(lib, "dxguid.lib")


#define _WIN32_WINNT			0x0400
#define DIRECTINPUT_VERSION		0x0800
#include <dinput.h>

#include "McInput.h"															// Input class






#include "Main.h"

#endif
// Implementation of the CMcScene class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMcScene::CMcScene()
{
	m_pDev	= NULL;
	m_pTex	= NULL;

	m_dFunc	= D3DCMP_ALWAYS;
	m_dRef	= 128;
}

CMcScene::~CMcScene()
{
	Destroy();
}

INT CMcScene::Create(LPDIRECT3DDEVICE9 pDev)
{
	m_pDev	= pDev;
	
	m_pVtx0[0] = VtxD(-8.f,  6.f, 5.01f,		D3DXCOLOR(1,1,1,1));
	m_pVtx0[1] = VtxD( 4.f,  6.f, 5.01f,		D3DXCOLOR(1,1,1,0));
	m_pVtx0[2] = VtxD( 4.f, -4.f, 5.01f,		D3DXCOLOR(1,1,1,0));
	m_pVtx0[3] = VtxD(-8.f, -4.f, 5.01f,		D3DXCOLOR(1,1,1,1));

	m_pVtx1[0] = VtxDUV1(-4.f,  4.f, 5.f,    0.f, 0.f,  D3DXCOLOR(1,1,1,0));
	m_pVtx1[1] = VtxDUV1( 8.f,  4.f, 5.f,    1.f, 0.f,  D3DXCOLOR(1,1,1,1));
	m_pVtx1[2] = VtxDUV1( 8.f, -6.f, 5.f,    1.f, 1.f,  D3DXCOLOR(1,1,1,1));
	m_pVtx1[3] = VtxDUV1(-4.f, -6.f, 5.f,    0.f, 1.f,  D3DXCOLOR(1,1,1,0));


	D3DXCreateTextureFromFile(m_pDev, "Texture/env3_alpha.png", &m_pTex);

	return 0;
}


void CMcScene::Destroy()
{
	SAFE_RELEASE(	m_pTex	);
}

INT CMcScene::FrameMove()
{
	return 0;
}

void CMcScene::Render()
{
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSW, D3DTADDRESS_CLAMP);

	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);

	m_pDev->SetRenderState(D3DRS_LIGHTING, FALSE);
	m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);


	// Get Default Alpha Test
	DWORD	v;
	m_pDev->GetRenderState(D3DRS_ALPHAFUNC, &v);
	m_pDev->GetRenderState(D3DRS_ALPHAREF, &v);



	// �� �Լ� ����
	if(::GetAsyncKeyState('1')&0x8000)	m_dFunc = D3DCMP_NEVER            ;
	if(::GetAsyncKeyState('2')&0x8000)	m_dFunc = D3DCMP_LESS             ;
	if(::GetAsyncKeyState('3')&0x8000)	m_dFunc = D3DCMP_EQUAL            ;
	if(::GetAsyncKeyState('4')&0x8000)	m_dFunc = D3DCMP_LESSEQUAL        ;
	if(::GetAsyncKeyState('5')&0x8000)	m_dFunc = D3DCMP_GREATER          ;
	if(::GetAsyncKeyState('6')&0x8000)	m_dFunc = D3DCMP_NOTEQUAL         ;
	if(::GetAsyncKeyState('7')&0x8000)	m_dFunc = D3DCMP_GREATEREQUAL     ;
	if(::GetAsyncKeyState('8')&0x8000)	m_dFunc = D3DCMP_ALWAYS           ;

	// ���� ���� ��Ű�ų� ���� ���� ����.
	if(::GetAsyncKeyState(VK_ADD))
	{
		++m_dRef;
		if(m_dRef>255)	m_dRef = 255;
	}

	if(::GetAsyncKeyState(VK_SUBTRACT))
	{
		--m_dRef;

		if(m_dRef<0)	m_dRef = 0;
	}

	// Debug: ������ Ÿ��Ʋ�� �Լ��� ���� ���� ���
	char	sMsg[128]={0};
	sprintf(sMsg, "%ld %ld", m_dFunc, m_dRef);
	SetWindowText(GMAIN->GetHwnd(), sMsg);



	// ���� �׽�Ʈ�� �����Ѵ�.
	m_pDev->SetRenderState(D3DRS_ALPHATESTENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_ALPHAFUNC, (DWORD)m_dFunc);
	m_pDev->SetRenderState(D3DRS_ALPHAREF, (DWORD)m_dRef);




	// Default ������ �����Ѵ�.
	m_pDev->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
	m_pDev->SetTextureStageState(0, D3DTSS_COLORARG2, D3DTA_DIFFUSE);
	m_pDev->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_MODULATE);

	m_pDev->SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
	m_pDev->SetTextureStageState(0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE);
	m_pDev->SetTextureStageState(0, D3DTSS_ALPHAOP,	 D3DTOP_MODULATE);



	// ���� �������� ���� �׽�Ʈ�� ���� ����� ����.
	m_pDev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);


	m_pDev->SetTexture(0, NULL);
	m_pDev->SetFVF(VtxD::FVF);
	m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLEFAN, 2, m_pVtx0, sizeof(VtxD));

	
	m_pDev->SetTexture(0, m_pTex);
	m_pDev->SetFVF(VtxDUV1::FVF);
	m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLEFAN, 2, m_pVtx1, sizeof(VtxDUV1));


	m_pDev->SetTexture(0, NULL);

	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
	m_pDev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);

	m_pDev->SetRenderState(D3DRS_ALPHATESTENABLE, FALSE);
}



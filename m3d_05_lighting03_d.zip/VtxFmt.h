#ifndef _VTXFMT_H_
#define _VTXFMT_H_


struct VtxD
{
	D3DXVECTOR3	p;
	DWORD	d;

	VtxD() : d(0xFFFFFFFF){}
	VtxD(FLOAT X, FLOAT Y, FLOAT Z, DWORD D) : p(X,Y,Z), d(D){}
	enum { FVF = (D3DFVF_XYZ|D3DFVF_DIFFUSE)};
};

struct VtxND
{
	D3DXVECTOR3	p;
	D3DXVECTOR3	n;
	DWORD		d;

	VtxND() : p(0,0,0), n(0,1,0),d(0xFFFFFFFF){}
	VtxND(D3DXVECTOR3 P,D3DXVECTOR3 N, DWORD D=0xFFFFFFFF): p(P), n(N), d(D){}
	VtxND(FLOAT X, FLOAT Y, FLOAT Z
		, FLOAT Nx, FLOAT Ny, FLOAT Nz
		, DWORD D=0xFFFFFFFF) : p(X,Y,Z),n(Nx,Ny,Nz), d(D){}
	enum { FVF = (D3DFVF_XYZ|D3DFVF_NORMAL|D3DFVF_DIFFUSE)};
};



#endif _VTXFMT_H_
// Implementation of the CMcScene class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


D3DLIGHT9 m_light;


CMcScene::CMcScene()
{
	m_pDev	= NULL;
	m_pVtx	= NULL;
}

CMcScene::~CMcScene()
{
	Destroy();
}


INT	CMcScene::Create(PDEV pDev)
{
	m_pDev	= pDev;

	m_fW	= 10.f;

	m_vcI	= -D3DXVECTOR3(1, 0, 1) * 100.f;


	INT			nIdx;
	D3DXVECTOR3	p0;
	D3DXVECTOR3	p1;
	D3DXVECTOR3	p2;
	D3DXVECTOR3	p3;

	D3DXVECTOR3	n = D3DXVECTOR3(0,1,0);
	D3DXCOLOR	d = D3DXCOLOR(1,1,0,1); //Yellow;

	m_pVtx = new VtxND[ 64* 64 * 3 * 2];

	for(int j=0; j<64; ++j)
	{
		for(int i=0; i<64; ++i)
		{
			nIdx = j * 64 + i;

			p0 = m_vcI + D3DXVECTOR3( i+0.f, 0.1f, j+0.f) * m_fW;
			p1 = m_vcI + D3DXVECTOR3( i+0.f, 0.1f, j+1.f) * m_fW;
			p2 = m_vcI + D3DXVECTOR3( i+1.f, 0.1f, j+0.f) * m_fW;
			p3 = m_vcI + D3DXVECTOR3( i+1.f, 0.1f, j+1.f) * m_fW;

			m_pVtx[nIdx *6 + 0] = VtxND( p0, n, d);
			m_pVtx[nIdx *6 + 1] = VtxND( p1, n, d);
			m_pVtx[nIdx *6 + 2] = VtxND( p2, n, d);
			m_pVtx[nIdx *6 + 3] = VtxND( p3, n, d);

			m_pVtx[nIdx *6 + 4] = m_pVtx[nIdx *6 + 2];
			m_pVtx[nIdx *6 + 5] = m_pVtx[nIdx *6 + 1];
		}
	}

	return 0;
}


void CMcScene::Destroy()
{
	SAFE_DELETE_ARRAY(	m_pVtx	);
}

INT	CMcScene::FrameMove()
{
	return 0;
}

void CMcScene::Render()
{
	memset( &m_light, 0, sizeof(m_light) );
	m_light.Type = D3DLIGHT_SPOT;
	m_light.Position = D3DXVECTOR3(200, 250, 100);
	m_light.Direction = D3DXVECTOR3( 0.f, -1.f, 0.f );

	m_light.Diffuse		= D3DXCOLOR( 3, 1.5, 0, 0);
	m_light.Specular	= D3DXCOLOR( 2, 4, 16, 1);

	m_light.Range		 = 2500;
	m_light.Falloff      = 2.5f;

	m_light.Attenuation1 = 0.001f;
	m_light.Attenuation2 = 0.00001f;
	m_light.Theta        = D3DXToRadian(20);
	m_light.Phi          = D3DXToRadian(120);
	

	// Setup a material
	D3DMATERIAL9 mtrl={0};
	D3DXCOLOR	Color(5,1,5,1);

//	mtrl.Diffuse = Color;
	mtrl.Specular= Color;
	mtrl.Power	= 10.f;

	
	m_pDev->SetLight( 0, &m_light );
	m_pDev->LightEnable( 0, TRUE );
	m_pDev->SetMaterial( &mtrl );

	m_pDev->SetRenderState( D3DRS_AMBIENT, 0x0);

	m_pDev->SetRenderState( D3DRS_LIGHTING,  TRUE);
	m_pDev->SetRenderState( D3DRS_SPECULARENABLE, TRUE);
	m_pDev->SetRenderState( D3DRS_CULLMODE,  D3DCULL_NONE);


	m_pDev->SetTexture(0, NULL);
	m_pDev->SetFVF(VtxND::FVF);
	m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLELIST, 64 * 64 * 2, m_pVtx, sizeof(VtxND));
}



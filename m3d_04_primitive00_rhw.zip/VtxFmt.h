#ifndef _VTXFMT_H_
#define _VTXFMT_H_


struct VtxRHW
{
	D3DXVECTOR4	p;																// The transformed position for the vertex
	DWORD		d;																// The vertex color

	VtxRHW()	{}
	VtxRHW(FLOAT X, FLOAT Y, FLOAT Z, FLOAT W, DWORD D)
	{
		p.x	= X;
		p.y	= Y;
		p.z	= Z;
		p.w	= W;
		d	= D;
	}
	
};

#define FVF_VTXRHW			(D3DFVF_XYZRHW|D3DFVF_DIFFUSE)




struct VtxNDUV2
{
	D3DXVECTOR3	position;	// ���� ��ġ
	D3DXVECTOR3	normal;		// ���� ����
	D3DXVECTOR2	tex0;		// 0 �� �ؽ�ó
	D3DXVECTOR2	tex1;		// 1 �� �ؽ�ó

	enum{ FVF=(D3DFVF_XYZ| D3DFVF_NORMAL| D3DFVF_DIFFUSE | D3DFVF_TEX2), };
};



struct VtxDS
{
	D3DXVECTOR3 p;		// ��ġ
	DWORD		d;		// Diffuse
	DWORD		s;		// Specular

	static DWORD FVF;
};


#endif



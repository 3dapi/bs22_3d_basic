// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"




DWORD VtxDS::FVF= (D3DFVF_XYZ| D3DFVF_DIFFUSE | D3DFVF_SPECULAR);




CMain::CMain()
{
	strcpy(m_sCls, "Mck_D3D");

	m_hInst			= NULL;
	m_hWnd			= NULL;
	m_pD3D			= NULL;
	m_pd3dDevice	= NULL;

	m_dWinStyle		= WS_OVERLAPPED | WS_CAPTION |WS_SYSMENU|WS_VISIBLE;
	m_dScnX			= 800;
	m_dScnY			= 600;
}


CMain::~CMain()
{
}


INT CMain::Init()
{
	::SetWindowText(m_hWnd, "Primitive Base-RHW");

	// Initialize to render a quad
	VtxRHW pVtx[4];

	pVtx[0] = VtxRHW(  100.f, 100.f, 0.f, 1.f, 0xffff0000 );
	pVtx[1] = VtxRHW(  700.f, 100.f, 0.f, 1.f, 0xff00ff00 );
	pVtx[2] = VtxRHW(  700.f, 500.f, 0.f, 1.f, 0xff0000ff );
	pVtx[3] = VtxRHW(  100.f, 500.f, 0.f, 1.f, 0xffff00ff );


	VtxRHW* pVertices;

	m_dwSizeofVertices = sizeof(pVtx);

	// Create the vertex buffer
	if( FAILED( m_pd3dDevice->CreateVertexBuffer( m_dwSizeofVertices,
		0, FVF_VTXRHW,
		D3DPOOL_MANAGED, &m_pVB, 0 ) ) )
		return E_FAIL;


	if( FAILED( m_pVB->Lock( 0, m_dwSizeofVertices, (void**)&pVertices, 0 ) ) )
		return E_FAIL;

	memcpy( pVertices, pVtx, m_dwSizeofVertices);
	m_pVB->Unlock();

	return 0;
}

void CMain::Destroy()
{
	SAFE_RELEASE( m_pVB );
}


INT CMain::FrameMove()
{
	return 0;
}


INT CMain::Render()
{
	if( NULL == m_pd3dDevice )
		return -1;

	if( FAILED( m_pd3dDevice->BeginScene() ) )
		return -1;


	m_pd3dDevice->Clear( 0, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, 0xFF006699, 1.f, 0 );


	m_pd3dDevice->SetStreamSource( 0, m_pVB, 0, sizeof(VtxRHW) );
	m_pd3dDevice->SetFVF( FVF_VTXRHW );
	m_pd3dDevice->DrawPrimitive( D3DPT_TRIANGLEFAN, 0, 2 );

	
	// End the scene
	m_pd3dDevice->EndScene();


	m_pd3dDevice->Present( NULL, NULL, NULL, NULL );							// ���������� �ĸ���۸� ������۷� ��ü�Ѵ�.( flipping)

	return 0;
}
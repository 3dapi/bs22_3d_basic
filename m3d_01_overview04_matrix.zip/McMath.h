#ifndef _MCMATH_H_
#define _MCMATH_H_

#include <math.h>

struct Vector3
{
	union
	{
		struct
		{
			float	x;
			float	y;
			float	z;
		};

		float m[3];
	};


	Vector3() : x(0.f), y(0.f), z(0.f){}
	Vector3(float X, float Y, float Z):	x(X), y(Y), z(Z){}

	Vector3(const Vector3& r)
	{
		x = r.x;
		y = r.y;
		z = r.z;
	}

	Vector3(const Vector3* r)
	{
		x = r->x;
		y = r->y;
		z = r->z;
	}

	Vector3 operator+(const Vector3& v )
	{
		return Vector3(x + v.x, y + v.y, z + v.z);
	}

	// �̰��� �ϼ��Ͻÿ�.
	//operator - ( CONST Vector3& v )
	//{
	//}

	Vector3 operator*(float f)
	{
		return Vector3(x * f, y * f, z * f);
	}

	// �̰��� �ϼ��Ͻÿ�.
	//operator * ( float f )
	//{
	//}


	float LengthSq()
	{
		return	(x*x + y*y + z*z);
	}

	// �̰��� �ϼ��Ͻÿ�.
	//float	Length()
	//{
	//}


	operator float*()
	{
		return (float*) &x;
	}
};


inline float	Vector3Dot(const Vector3* p1, const Vector3* p2)
{
	return (p1->x * p2->x + p1->y * p2->y + p1->z * p2->z);
}

inline Vector3	Vector3Normalize(const Vector3* p1)
{
	float fL = sqrtf(p1->x * p1->x  +  p1->y * p1->y  +  p1->z * p1->z);

	fL = 1.f/fL;

	return Vector3(p1->x * fL, p1->y * fL, p1->z * fL);
}


inline Vector3	Vector3Cross(const Vector3* p1, const Vector3* p2)
{
	return Vector3(	p1->y * p2->z  - p1->z * p2->y
				,	p1->z * p2->x  - p1->x * p2->z
				,	p1->x * p2->y  - p1->y * p2->x);
}


struct Matrix
{
	union
	{
		struct
		{
			float	_11, _12, _13, _14;
			float	_21, _22, _23, _24;
			float	_31, _32, _33, _34;
			float	_41, _42, _43, _44;
		};

		float m[4][4];
	};


	Matrix()
	{
		_11=0.f, _12=0.f, _13=0.f, _14=0.f;
		_21=0.f, _22=0.f, _23=0.f, _24=0.f;
		_31=0.f, _32=0.f, _33=0.f, _34=0.f;
		_41=0.f, _42=0.f, _43=0.f, _44=0.f;
	}

	operator float*()
	{
		return (float*)&_11;
	}
};

inline Matrix MatrixMulti(Matrix* p1, Matrix* p2)
{
	Matrix mat;

	for(int i=0; i<4; ++i)
	{
		for(int j=0; j<4; ++j)
		{
			for(int k=0; i<4; ++k)
			{
				mat.m[i][j] = p1->m[i][k] * p2->m[k][j];
			}
		}
	}

	return mat;
}


inline void MatrixIdentity(Matrix& p)
{
	memset(&p, 0, sizeof(Matrix));

	for(int i=0; i<4; ++i)
	{
		p.m[i][i] = 1.f;
	}
}



#endif
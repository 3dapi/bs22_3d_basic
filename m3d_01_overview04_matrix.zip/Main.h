// Interface for the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _MAIN_H_
#define _MAIN_H_


// ���� ����ü
struct VtxD
{
    D3DXVECTOR3	p;		// ��ġ
    DWORD	color;		// Diffuse ����

	VtxD() : p(0,0,0), color(0xFFFFFFFF)	{}
	VtxD(float X, float Y, float Z, DWORD COLOR=0xFFFFFFFF): p(X,Y,Z), color(COLOR){}
	VtxD(const D3DXVECTOR3& _p, DWORD COLOR=0xFFFFFFFF) : p(_p), color(COLOR){}
};

// Vertex Format
#define D3DFVF_VTXST (D3DFVF_XYZ|D3DFVF_DIFFUSE)


class CMain
{
public:
	HINSTANCE				m_hInst			;
	HWND					m_hWnd			;
	LPDIRECT3D9             m_pD3D			;									// D3D
	LPDIRECT3DDEVICE9       m_pd3dDevice	;									// Device

public:
	LPDIRECT3DVERTEXBUFFER9 m_pVB			;									// ���� ����

public:
	INT		Init();
	void	Destroy();
	void	Render();

	INT		FrameMove();

	CMain();
	virtual ~CMain();

	INT		Create( HINSTANCE hInst);
	INT		Run();
	void	Cleanup();
	
	LRESULT MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam );
	static LRESULT WINAPI WndProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam );
};

extern CMain*	g_pApp;

#endif

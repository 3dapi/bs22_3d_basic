// Implementation of the CMcScene class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMcScene::CMcScene()
{
	m_pDev			= NULL;

	m_pMesh			= NULL;
	m_pTexSphere	= NULL;

	D3DXMatrixIdentity(&m_mtWld);
}

CMcScene::~CMcScene()
{
	Destroy();
}

INT CMcScene::Create(LPDIRECT3DDEVICE9 pDev)
{
	HRESULT hr;

	m_pDev	= pDev;
	
	
	ID3DXMesh* pMesh = NULL;
	hr = D3DXCreateTeapot(m_pDev, &pMesh, NULL);
	hr = pMesh->CloneMeshFVF(D3DXMESH_SYSTEMMEM, VtxN::FVF, m_pDev, &m_pMesh );
	pMesh->Release();

	DWORD nVtx = m_pMesh->GetNumVertices();

	VtxN* pVtx = NULL;
	m_pMesh->LockVertexBuffer(0, (void**)&pVtx);

	for(DWORD n=0; n<nVtx; ++n)
	{
		pVtx[n].p *=32.f;
	}

	m_pMesh->UnlockVertexBuffer();

	hr = D3DXCreateTextureFromFile(m_pDev, "Texture/spheremap.bmp", &m_pTexSphere);
	
	return 0;
}


void CMcScene::Destroy()
{
	SAFE_RELEASE(	m_pMesh		);
	SAFE_RELEASE( m_pTexSphere	);
}

INT CMcScene::FrameMove()
{
	D3DXMATRIX	mtRotY;
	D3DXMATRIX	mtRotZ;
	D3DXVECTOR3	vcAxis(2, 1, 1);
	D3DXVec3Normalize(&vcAxis, &vcAxis);

	float fAngle = D3DXToRadian( GetTickCount() * 0.05f );

	D3DXMatrixRotationZ(&mtRotZ, D3DXToRadian(-23.5F));
	D3DXMatrixRotationY(&mtRotY, fAngle);
	
	m_mtWld = mtRotY * mtRotZ;
	
	return 0;
}

void CMcScene::Render()
{
	m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);

	m_pDev->SetSamplerState( 0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR );
	m_pDev->SetSamplerState( 0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR );
	m_pDev->SetSamplerState( 0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR );

	m_pDev->SetSamplerState( 0, D3DSAMP_ADDRESSU,  D3DTADDRESS_MIRROR );
	m_pDev->SetSamplerState( 0, D3DSAMP_ADDRESSV,  D3DTADDRESS_MIRROR );
	m_pDev->SetSamplerState( 0, D3DSAMP_ADDRESSW,  D3DTADDRESS_MIRROR );

	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	m_pDev->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_SELECTARG1 );



	m_pDev->SetTextureStageState(0, D3DTSS_TEXCOORDINDEX, D3DTSS_TCI_CAMERASPACENORMAL);
	m_pDev->SetTextureStageState(0, D3DTSS_TEXTURETRANSFORMFLAGS, D3DTTFF_COUNT2);


	D3DXMATRIX mat(
		0.5f,	 0.0f,	0.0f,	0.0f,
		0.0f,	-0.5f,	0.0f,	0.0f,
		0.0f,	 0.0f,	1.0f,	0.0f,
		0.5f,	 0.5f,	0.0f,	1.0f
		);


	m_pDev->SetTransform(D3DTS_WORLD, &m_mtWld);
	m_pDev->SetTransform(D3DTS_TEXTURE0, &mat);
	m_pDev->SetTexture(0, m_pTexSphere);

	// Draw teapot
	m_pMesh->DrawSubset(0);


	D3DXMATRIX mtI;
	D3DXMatrixIdentity(&mtI);

	// Default Setting
	m_pDev->SetTransform(D3DTS_TEXTURE0, &mtI);
	m_pDev->SetTransform(D3DTS_WORLD, &mtI);
	m_pDev->SetTexture(0, NULL);

	m_pDev->SetTextureStageState(0, D3DTSS_TEXCOORDINDEX, D3DTSS_TCI_PASSTHRU);
	m_pDev->SetTextureStageState(0, D3DTSS_TEXTURETRANSFORMFLAGS, D3DTTFF_DISABLE);
}



// Interface for the CMain class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MAIN_H_
#define _MAIN_H_


class CMain
{
public:
	TCHAR					m_sCls[128]		;
	HINSTANCE				m_hInst			;
	HWND					m_hWnd			;
	DWORD					m_dWinStyle		;
	DWORD					m_dScnX			;									// Screen Width
	DWORD					m_dScnY			;									// Screen Height
	RECT					m_rcWinBounds	;									// Saved window bounds for mode switches
    RECT					m_rcWinClient	;									// Saved client area size for mode switches

public:
	LPDIRECT3D9             m_pD3D			;									// D3D
	LPDIRECT3DDEVICE9       m_pd3dDevice	;									// Device

public:
	LPDIRECT3DTEXTURE9      m_pTx;

public:
	INT		Init();
	void	Destroy();
	INT		Render();

	INT		FrameMove();

	CMain();
	virtual ~CMain();

	INT		Create( HINSTANCE hInst);
	INT		Run();
	void	Cleanup();
	
	LRESULT MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam );
};

extern CMain*	g_pApp;

#endif

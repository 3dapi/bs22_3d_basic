#ifndef _VTXFMT_H_
#define _VTXFMT_H_


struct VtxRHWD
{
	D3DXVECTOR4	p;

	FLOAT		s;		// Point Size
	DWORD		d;
	
	VtxRHWD()						{	p.x=p.y=p.z=0.f; p.w =1.f; s = 10.f; d=0xFFFFFFFF;	}
	VtxRHWD(FLOAT X,FLOAT Y, FLOAT S, DWORD D){	p.x=X; p.y=Y; p.z=0.F; p.w = 1.f; s = S; d=D;		}
};

#define FVF_VTXDRHW		(D3DFVF_XYZRHW|D3DFVF_PSIZE|D3DFVF_DIFFUSE)


#endif
// Interface for the CMcScene class.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _McScene_H_
#define _McScene_H_


struct VtxRHWD
{
	D3DXVECTOR4 p;
	D3DCOLOR    d;
	
	enum {	FVF = (D3DFVF_XYZRHW | D3DFVF_DIFFUSE),};
};



struct Vtx
{
	D3DXVECTOR3 p;
	enum {	FVF = (D3DFVF_XYZ),};
};


class CMcScene
{
protected:
	LPDIRECT3DDEVICE9	m_pDev;
	BOOL				m_bTwoSide;

	ID3DXMesh*			m_pMesh;
	D3DXMATRIX			m_mtObject;

	
	VtxRHWD				m_pRhw[4];



public:
	CMcScene();
	virtual ~CMcScene();
    
	INT		Create(LPDIRECT3DDEVICE9 pDev);
    void	Destroy();

	INT		FrameMove();
    void	Render();
};


#endif




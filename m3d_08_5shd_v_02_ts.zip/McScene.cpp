// Implementation of the CMcScene class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMcScene::CMcScene()
{
	m_pDev		= NULL;
	m_pMesh		= NULL;
}


CMcScene::~CMcScene()
{
	Destroy();
}

void CMcScene::Destroy()
{
	SAFE_RELEASE( m_pMesh	);
}


INT CMcScene::Create(LPDIRECT3DDEVICE9 pDev)
{
	HRESULT hr=-1;

	m_pDev = pDev;


	D3DCAPS9	caps;
	m_pDev->GetDeviceCaps(&caps);
	m_bTwoSide = caps.StencilCaps & D3DSTENCILCAPS_TWOSIDED;


	D3DXMATRIX mtZ, mtX;
	D3DXMatrixRotationX(&mtX, D3DXToRadian(90));
	D3DXMatrixRotationZ(&mtZ, D3DXToRadian(-30));

	m_mtObject = mtX * mtZ;
//	D3DXCreateTeapot(m_pDev, &m_pMesh, NULL);
	D3DXCreateCylinder(m_pDev, 60, 60, 250, 40, 20, &m_pMesh, NULL);






	// ������ ȭ�鿡 ���� ������ ���´�. ȭ�� ������ ������� ����̽��� �����
	// ������ �ڵ��� ã�´�.
	D3DDEVICE_CREATION_PARAMETERS Parameters;
	m_pDev->GetCreationParameters(&Parameters);

	// �����쿡 �ش��ϴ� ȭ�� ������ ��´�.
	RECT rc;
	GetClientRect(Parameters.hFocusWindow, &rc);

	FLOAT	sx = FLOAT(rc.right - rc.left);
	FLOAT	sy = FLOAT(rc.bottom- rc.top );



	m_pRhw[0].p = D3DXVECTOR4(  0, sy, 0.0f, 1.0f );
	m_pRhw[1].p = D3DXVECTOR4(  0,  0, 0.0f, 1.0f );
	m_pRhw[2].p = D3DXVECTOR4( sx, sy, 0.0f, 1.0f );
	m_pRhw[3].p = D3DXVECTOR4( sx,  0, 0.0f, 1.0f );

	m_pRhw[0].d = 0xAf555555;
	m_pRhw[1].d = 0xAf555555;
	m_pRhw[2].d = 0xAf555555;
	m_pRhw[3].d = 0xAf555555;

	return 0;
}


INT CMcScene::FrameMove()
{
	CLcInput*	pInput = GMAIN->GetInput();
	
	if(pInput->KeyState(VK_UP))
		m_mtObject._43 +=1.f;

	if(pInput->KeyState(VK_DOWN))
		m_mtObject._43 -=1.f;

	if(pInput->KeyState(VK_RIGHT))
		m_mtObject._41 +=1.f;

	if(pInput->KeyState(VK_LEFT))
		m_mtObject._41 -=1.f;

	return 0;
}


void CMcScene::Render()
{
	static D3DXMATRIX mtI(1,0,0,0,    0,1,0,0,    0,0,1,0,    0,0,0,1);

	m_pDev->SetRenderState( D3DRS_FILLMODE, D3DFILL_SOLID);
	m_pDev->SetRenderState( D3DRS_LIGHTING, FALSE );
	m_pDev->SetRenderState( D3DRS_FOGENABLE, FALSE );


	// 1. ���� ���� ���� ��Ȱ��ȭ
	m_pDev->SetRenderState( D3DRS_ZWRITEENABLE,  FALSE );
	m_pDev->SetRenderState( D3DRS_COLORWRITEENABLE, FALSE);

	m_pDev->SetRenderState( D3DRS_STENCILENABLE, TRUE );		// ���ٽ� Ȱ��ȭ


	if(m_bTwoSide)
	{
		// 2-side Ȱ��ȭ
		m_pDev->SetRenderState( D3DRS_TWOSIDEDSTENCILMODE, TRUE );

		// ����� �׸���.
		m_pDev->SetRenderState( D3DRS_CULLMODE,  D3DCULL_NONE);

		// 2. �ո� ����
		m_pDev->SetRenderState( D3DRS_STENCILREF, 0x1 );
		m_pDev->SetRenderState( D3DRS_STENCILMASK, 0xffffffff );
		m_pDev->SetRenderState( D3DRS_STENCILWRITEMASK, 0xffffffff );
		m_pDev->SetRenderState( D3DRS_STENCILFUNC, D3DCMP_ALWAYS );	// �׽�Ʈ�� ������ ���
		m_pDev->SetRenderState( D3DRS_STENCILZFAIL,	D3DSTENCILOP_KEEP);
		m_pDev->SetRenderState( D3DRS_STENCILFAIL,	D3DSTENCILOP_KEEP);
		m_pDev->SetRenderState( D3DRS_STENCILPASS,  D3DSTENCILOP_INCR);	// ���ٽ� ���� 1 ����

		
		// 3. �޸� ����
		m_pDev->SetRenderState( D3DRS_CCW_STENCILFUNC, D3DCMP_ALWAYS);
		m_pDev->SetRenderState( D3DRS_CCW_STENCILZFAIL, D3DSTENCILOP_KEEP );
		m_pDev->SetRenderState( D3DRS_CCW_STENCILFAIL,  D3DSTENCILOP_KEEP );
		m_pDev->SetRenderState( D3DRS_CCW_STENCILPASS, D3DSTENCILOP_DECR );

		// Object Rendering
		m_pDev->SetTransform(D3DTS_WORLD, &m_mtObject);
		m_pMesh->DrawSubset(0);
		
		m_pDev->SetRenderState( D3DRS_TWOSIDEDSTENCILMODE, FALSE);
	}

	else
	{

		// 2. �ո��� �׸��� ���� ���ٽ� ����
		m_pDev->SetRenderState( D3DRS_STENCILREF, 0x1 );
		m_pDev->SetRenderState( D3DRS_STENCILMASK, 0xffffffff );
		m_pDev->SetRenderState( D3DRS_STENCILWRITEMASK, 0xffffffff );
		m_pDev->SetRenderState( D3DRS_STENCILFUNC, D3DCMP_ALWAYS );	// �׽�Ʈ�� ������ ���
		m_pDev->SetRenderState( D3DRS_STENCILZFAIL,	D3DSTENCILOP_KEEP);
		m_pDev->SetRenderState( D3DRS_STENCILFAIL,	D3DSTENCILOP_KEEP);
		m_pDev->SetRenderState( D3DRS_STENCILPASS,  D3DSTENCILOP_INCR);	// ���ٽ� ���� 1 ����


		// 3. �ո� ������
		m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);
		m_pDev->SetTransform(D3DTS_WORLD, &m_mtObject);
		m_pMesh->DrawSubset(0);


		// 4. �޸� ���ٽ� ����
		m_pDev->SetRenderState( D3DRS_STENCILFUNC, D3DCMP_ALWAYS);
		m_pDev->SetRenderState( D3DRS_STENCILZFAIL, D3DSTENCILOP_KEEP);
		m_pDev->SetRenderState( D3DRS_STENCILFAIL, D3DSTENCILOP_KEEP);
		m_pDev->SetRenderState( D3DRS_STENCILPASS, D3DSTENCILOP_DECR);	// ���ٽ� ���� 1 ����


		// 5. �޸� ������
		m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_CW);
		m_pDev->SetTransform(D3DTS_WORLD, &m_mtObject);
		m_pMesh->DrawSubset(0);
	}



	// 6. ���� ��� ȯ��
	m_pDev->SetRenderState( D3DRS_COLORWRITEENABLE, 0xF);
	m_pDev->SetRenderState( D3DRS_ZWRITEENABLE,     TRUE );
	m_pDev->SetRenderState( D3DRS_CULLMODE,  D3DCULL_CCW );
	m_pDev->SetTransform(D3DTS_WORLD, &mtI);



	// 7. ȭ�� ��ü�� �׸���.
	m_pDev->SetRenderState( D3DRS_STENCILENABLE,    TRUE );
	m_pDev->SetRenderState( D3DRS_STENCILREF,  0x1 );
	m_pDev->SetRenderState( D3DRS_STENCILFUNC, D3DCMP_LESSEQUAL);	// 1 �� ���ٽ� ���� ��
	m_pDev->SetRenderState( D3DRS_STENCILPASS, D3DSTENCILOP_KEEP );



	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);

	m_pDev->SetFVF(VtxRHWD::FVF);
	m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLESTRIP, 2, m_pRhw, sizeof(VtxRHWD) );


	// 8. ���ٽ��� ��Ȱ��ȭ
	m_pDev->SetRenderState( D3DRS_STENCILENABLE,    FALSE );



	// ������ �׸���.
	m_pDev->SetRenderState(D3DRS_FILLMODE, D3DFILL_WIREFRAME);
	m_pDev->SetTransform(D3DTS_WORLD, &m_mtObject);
	m_pMesh->DrawSubset(0);
	m_pDev->SetTransform(D3DTS_WORLD, &mtI);
	m_pDev->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
}


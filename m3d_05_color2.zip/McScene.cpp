// Implementation of the CMcScene class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMcScene::CMcScene()
{
	m_pDev	= NULL;

	m_pVB	= NULL;
	m_pIB	= NULL;
}

CMcScene::~CMcScene()
{
	Destroy();
}


INT CMcScene::Create(LPDIRECT3DDEVICE9 pDev)
{
	int x, y;

	m_pDev	= pDev;

	m_iNx = 8+1;
	m_iNy = 8+1;
	m_iNv = m_iNx * m_iNy;

	if(FAILED(m_pDev->CreateVertexBuffer(
		m_iNv * sizeof(VtxD)
		, 0
		, VtxD::FVF
		, D3DPOOL_MANAGED
		, &m_pVB,0)))
		return -1;


	// Fill Vertex buffer

	VtxD* pVtx;
	m_pVB->Lock(0, 0, (void**)&pVtx, 0);

	for(y=0; y<m_iNy; ++y)
	{
		for(x=0; x<m_iNx; ++x)
		{
			int idx = y * m_iNx + x;

			pVtx[idx] = VtxD( (x-m_iNx/2) * 4.f
							, (y-m_iNy/2) * 4.f
							, 20.f
							, D3DCOLOR_XRGB(56, 56, 56)
								+ D3DCOLOR_XRGB(rand()%200, rand()%200, rand()%200)
							);
		}
	}

	m_pVB->Unlock();




	m_iNfc = (m_iNx-1) * (m_iNy-1) * 2;				// �ﰢ���� ��

	if(FAILED(m_pDev->CreateIndexBuffer(
		m_iNfc * sizeof(VtxIdx)
		, 0
		, D3DFMT_INDEX16
		, D3DPOOL_MANAGED
		, &m_pIB, 0)))
		return -1;


	// Fill Index buffer

	VtxIdx* pIdx;
	m_pIB->Lock(0, 0, (void**)&pIdx, 0);

	int k=0;
	for(y=0; y<m_iNy-1; ++y)
	{
		for(x=0; x<m_iNx-1; ++x)
		{
			int idx0 = (y+1) * m_iNx + x;

			pIdx[k] = VtxIdx(idx0, idx0+1, idx0-m_iNx);
			++k;

			int idx1 = (y+0) * m_iNx + x+1;
			pIdx[k] = VtxIdx(idx1, idx1-1, idx1+m_iNx);
			++k;
		}
	}

	m_pIB->Unlock();

	return 0;
}

void CMcScene::Destroy()
{
	SAFE_RELEASE(	m_pVB	);
	SAFE_RELEASE(	m_pIB	);
}


INT CMcScene::FrameMove()
{
	LPDIRECT3DSURFACE9	pSrf=NULL;
	D3DSURFACE_DESC		desc;
	m_pDev->GetBackBuffer( 0, 0, D3DBACKBUFFER_TYPE_MONO, &pSrf );
	pSrf->GetDesc( &desc );
	pSrf->Release();

	D3DXMATRIX proj;
	D3DXMatrixPerspectiveFovLH(
		&proj,
		D3DX_PI * 0.5f, // 90 - degree
		(float)desc.Width/ (float)desc.Height,
		1.0f,
		5000.0f);
	m_pDev->SetTransform(D3DTS_PROJECTION, &proj);


	return 0;
}


void CMcScene::Render()
{
	// Turn off lighting.
	m_pDev->SetRenderState(D3DRS_LIGHTING, FALSE);

	m_pDev->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
	m_pDev->SetRenderState(D3DRS_SHADEMODE, D3DSHADE_FLAT);	// Flat �� ���̵�
//	m_pDev->SetRenderState(D3DRS_SHADEMODE, D3DSHADE_GOURAUD);


	m_pDev->SetFVF(VtxD::FVF);
	m_pDev->SetStreamSource(0, m_pVB, 0, sizeof(VtxD));
	m_pDev->SetIndices(m_pIB);
	m_pDev->DrawIndexedPrimitive(D3DPT_TRIANGLELIST, 0, 0, m_iNv, 0, m_iNfc);
}
// Interface for the CMcScene class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MCSCENE_H_
#define _MCSCENE_H_

struct VtxD
{
	D3DXVECTOR3 p;
	DWORD		d;

	VtxD(){}
	VtxD(FLOAT X, FLOAT Y, FLOAT Z, DWORD D) : p(X, Y, Z), d(D){}
	enum{ FVF = (D3DFVF_XYZ | D3DFVF_DIFFUSE),	};
};


struct VtxIdx
{
	WORD a, b, c;

	VtxIdx() : a(0), b(1), c(2){}
	VtxIdx(WORD A, WORD B, WORD C) : a(A), b(B), c(C){}
};


class CMcScene
{
protected:
	LPDIRECT3DDEVICE9			m_pDev;

	INT							m_iNx;					// X�� �� ���� ��
	INT							m_iNy;					// Y�� �� ���� ��
	INT							m_iNv;					// ��ü ���� ��
	LPDIRECT3DVERTEXBUFFER9		m_pVB;					// Vertex Buffer

	INT							m_iNfc;					// �ﰢ���� ��
	LPDIRECT3DINDEXBUFFER9		m_pIB;					// Index Buffer
	

public:
	CMcScene();
	virtual ~CMcScene();

	INT		Create(LPDIRECT3DDEVICE9 pDev);
	void	Destroy();

	INT		FrameMove();
	void	Render();
};

#endif
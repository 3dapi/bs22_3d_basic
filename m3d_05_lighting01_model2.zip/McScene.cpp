// Implementation of the CMcScene class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMcScene::CMcScene()
{
	m_pDev		= NULL;

	m_pVtx		= NULL;
	m_pTx		= NULL;

	m_vcP		= D3DXVECTOR3(100, 100, 0);
}

CMcScene::~CMcScene()
{
	Destroy();
}

INT CMcScene::Create(LPDIRECT3DDEVICE9 pDev)
{
	m_pDev	= pDev;

	INT	iNSphereSegments	= 128;
	m_iNvx = 2*iNSphereSegments*(iNSphereSegments+1);

	m_pVtx = new VtxNUV1[m_iNvx];
	VtxNUV1* pV = m_pVtx;

	FLOAT fDeltaRingAngle = ( D3DX_PI / iNSphereSegments );
	FLOAT fDeltaSegAngle  = ( 2.0f * D3DX_PI / iNSphereSegments );

	// Generate the group of rings for the sphere
	for(INT ring = 0; ring < iNSphereSegments; ring++ )
	{
		FLOAT r0 = 50 * sinf( (ring+0) * fDeltaRingAngle );
		FLOAT r1 = 50 * sinf( (ring+1) * fDeltaRingAngle );
		FLOAT y0 = 50 * cosf( (ring+0) * fDeltaRingAngle );
		FLOAT y1 = 50 * cosf( (ring+1) * fDeltaRingAngle );

		// Generate the group of segments for the current ring
		for(INT seg = 0; seg < (iNSphereSegments+1); seg++ )
		{
			FLOAT x0 =  r0 * sinf( seg * fDeltaSegAngle );
			FLOAT z0 =  r0 * cosf( seg * fDeltaSegAngle );
			FLOAT x1 =  r1 * sinf( seg * fDeltaSegAngle );
			FLOAT z1 =  r1 * cosf( seg * fDeltaSegAngle );

			// Add two vertices to the strip which makes up the sphere
			// (using the transformed normal to generate texture coords)
			pV->p.x = x0;
			pV->p.y = y0;
			pV->p.z = z0;
			pV->n = pV->p;
			D3DXVec3Normalize(&pV->n, &pV->n);
			pV->u = -((FLOAT)seg)/iNSphereSegments;
			pV->v = (ring+0)/(FLOAT)iNSphereSegments;
			pV++;

			pV->p.x = x1;
			pV->p.y = y1;
			pV->p.z = z1;
			pV->n = pV->p;
			D3DXVec3Normalize(&pV->n, &pV->n);
			pV->u = -((FLOAT)seg)/iNSphereSegments;
			pV->v = (ring+1)/(FLOAT)iNSphereSegments;
			pV++;
		}

	}


	D3DXCreateTextureFromFile(m_pDev, "Texture/earth.bmp", &m_pTx);


	memset( &m_Mtl, 0, sizeof(m_Mtl) );
	memset( &m_Lgt, 0, sizeof(m_Lgt) );
	m_Lgt.Type = D3DLIGHT_DIRECTIONAL;

	D3DXVECTOR3 vecDir;
	vecDir = D3DXVECTOR3( 1.f, -1.f, 1.0f);
	D3DXVec3Normalize( (D3DXVECTOR3*)&m_Lgt.Direction, &vecDir );

	m_Lgt.Specular.r = 1.f;
	m_Lgt.Specular.g = 1.f;
	m_Lgt.Specular.b = 1.f;
	m_Lgt.Specular.a = 1.f;

	m_Lgt.Diffuse.r = 1.f;
	m_Lgt.Diffuse.g = 1.f;
	m_Lgt.Diffuse.b = 1.f;
	m_Lgt.Diffuse.a = 1.f;

	m_Lgt.Range = 1000;
	m_Lgt.Falloff = 0;
	m_Lgt.Attenuation0 = 1;
	m_Lgt.Attenuation1 = 0;
	m_Lgt.Attenuation2 = 0;

	m_Mtl.Specular.r = 1.0f;
	m_Mtl.Specular.g = 0.0f;
	m_Mtl.Specular.b = 0.0f;
	m_Mtl.Specular.a = 0.0f;

	m_Mtl.Diffuse.r = 1.f;
	m_Mtl.Diffuse.g = 0.f;
	m_Mtl.Diffuse.b = 0.f;
	m_Mtl.Diffuse.a = 0.f;
	m_Mtl.Power = 20;

	return 0;
}


void CMcScene::Destroy()
{
	SAFE_DELETE(	m_pVtx	);
	SAFE_RELEASE(	m_pTx	);
}

INT CMcScene::FrameMove()
{
	float c= D3DXToRadian( GetTickCount() * 0.1f);

	D3DXMATRIX	mtY;
	D3DXMATRIX	mtZ;

	D3DXMatrixRotationY(&mtY, -c);
	D3DXMatrixRotationZ(&mtZ, D3DXToRadian(-23.5f));

	m_mtWld = mtY * mtZ;

	if(g_pApp->m_pInput->KeyState(DIK_F8))
	{
		m_vcP +=D3DXVECTOR3(1, 0, 0);
	}

	if(g_pApp->m_pInput->KeyState(DIK_F9))
	{
		m_vcP -=D3DXVECTOR3(1, 0, 0);
	}

	m_mtWld._41 =m_vcP.x;
	m_mtWld._42 =m_vcP.y;
	m_mtWld._43 =m_vcP.z;


	return 0;
}

void CMcScene::Render()
{
	// ������ ����
	m_pDev->SetLight( 0, &m_Lgt );
	m_pDev->LightEnable( 0, TRUE );
	m_pDev->SetRenderState( D3DRS_SPECULARENABLE, TRUE );
	m_pDev->SetRenderState( D3DRS_LIGHTING, TRUE );


	m_pDev->SetMaterial( &m_Mtl );
	m_pDev->SetRenderState(D3DRS_SPECULARMATERIALSOURCE, D3DMCS_MATERIAL);

	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);

	m_pDev->SetTransform(D3DTS_WORLD, &m_mtWld);

	m_pDev->SetTexture( 0, m_pTx );
	m_pDev->SetFVF(VtxNUV1::FVF);

	m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLESTRIP
							, m_iNvx - 2
							, m_pVtx
							, sizeof(VtxNUV1)
							);


	// ����̽��� ���� ����� �ʱ�ȭ
	D3DXMATRIX	mtI;
	D3DXMatrixIdentity(&mtI);
	m_pDev->SetTransform(D3DTS_WORLD, &mtI);
}



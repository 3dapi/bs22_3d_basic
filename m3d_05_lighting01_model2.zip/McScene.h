// Interface for the CMcScene class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _McScene_H_
#define _McScene_H_

class CMcScene
{
protected:
	LPDIRECT3DDEVICE9		m_pDev;

	LPDIRECT3DTEXTURE9		m_pTx;

	D3DXMATRIX				m_mtWld;
	VtxNUV1*				m_pVtx;
	DWORD					m_iNvx;
	D3DXVECTOR3				m_vcP;


	D3DMATERIAL9	m_Mtl;
	D3DLIGHT9		m_Lgt;

public:
	CMcScene();
	virtual ~CMcScene();

	INT		Create(LPDIRECT3DDEVICE9 pDev);
	void	Destroy();

	INT		FrameMove();
	void	Render();
};

#endif
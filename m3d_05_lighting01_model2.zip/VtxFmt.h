#ifndef _VTXFMT_H_
#define _VTXFMT_H_

struct Vtx
{
    D3DXVECTOR3	p;																	// vertex position

	Vtx(){}
	Vtx(D3DXVECTOR3 P)							{	p=P;	}
	Vtx(FLOAT X, FLOAT Y, FLOAT Z)	: p(X,Y,Z)	{			}

	enum { FVF = (D3DFVF_XYZ)};
};


struct VtxD
{
	D3DXVECTOR3	p;
	DWORD	d;

	VtxD() : d(0xFFFFFFFF){}
	VtxD(FLOAT X, FLOAT Y, FLOAT Z, DWORD D) : p(X,Y,Z), d(D){}
	enum { FVF = (D3DFVF_XYZ|D3DFVF_DIFFUSE)};
};



struct VtxNUV1
{
	D3DXVECTOR3	p;
	D3DXVECTOR3	n;
	FLOAT	u, v;
	
	VtxNUV1()						: p(0,0,0),n(0,0,0),u(0),v(0){}
	VtxNUV1(	FLOAT X,FLOAT Y,FLOAT Z
			,	FLOAT Nx,FLOAT Ny,FLOAT Nz
			,	FLOAT U, FLOAT V)		: p(X,Y,Z),n(Nx,Ny,Nz),u(U),v(V){}

	enum {	FVF= (D3DFVF_XYZ|D3DFVF_NORMAL|D3DFVF_TEX1)	};

};


#endif
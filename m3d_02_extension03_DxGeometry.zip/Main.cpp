// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMain::CMain()
{
	m_pD3DXFont		= NULL;
	m_pGeo			= NULL;
}


HRESULT CMain::Init()
{
	if( FAILED( D3DXCreateFont( GDEVICE, 16, 0, FW_BOLD, 1, 0, HANGUL_CHARSET, OUT_DEFAULT_PRECIS, ANTIALIASED_QUALITY, FF_DONTCARE, "Arial", &m_pD3DXFont ) ) )
		return -1;


	SAFE_NEWCREATE1(	m_pGeo,		CMcGeo, m_pd3dDevice	);

	return S_OK;
}


HRESULT CMain::Destroy()
{
	SAFE_RELEASE( m_pD3DXFont	);
	SAFE_DELETE(	m_pGeo		);

	return S_OK;
}


HRESULT CMain::Restore()
{
	m_pD3DXFont->OnResetDevice();

	SAFE_RESTORE(	m_pGeo		);

	// �� ��� �����
	D3DXVECTOR3 vcEye	= D3DXVECTOR3(0, 0, -15);
	D3DXVECTOR3 vcLook	= D3DXVECTOR3(0, 1, 0);
	D3DXVECTOR3 vcUp	= D3DXVECTOR3(0,1,0);

	D3DXMatrixLookAtLH(&m_mtViw, &vcEye, &vcLook, &vcUp);

	// ���� ��� �����
	FLOAT	fScreenW = FLOAT(GMAIN->m_d3dsdBackBuffer.Width);
	FLOAT	fScreenH = FLOAT(GMAIN->m_d3dsdBackBuffer.Height);
	FLOAT	fFOV	= D3DX_PI/4.0f;
	FLOAT	fAspect	= fScreenW/fScreenH;
	FLOAT	fNear	= 1.f;
	FLOAT	fFar	= 5000.f;
	
	D3DXMatrixPerspectiveFovLH(&m_mtPrj, fFOV, fAspect, fNear, fFar);

	return S_OK;
}


HRESULT CMain::Invalidate()
{
	m_pD3DXFont->OnLostDevice();

	SAFE_INVALIDATE(	m_pGeo		);

	return S_OK;
}


HRESULT CMain::FrameMove()
{
	SAFE_FRAMEMOVE(	m_pGeo		);

	return S_OK;
}


HRESULT CMain::Render()
{
	MATA	mtW;
	D3DXMatrixIdentity(&mtW);
	GDEVICE->SetTransform(D3DTS_WORLD, &mtW);

	GDEVICE->SetTransform(D3DTS_VIEW, &m_mtViw);
	GDEVICE->SetTransform(D3DTS_PROJECTION, &m_mtPrj);	


	GDEVICE->Clear( 0L, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER|D3DCLEAR_STENCIL, 0xFF006699, 1.0f, 0L);

	if( FAILED( GDEVICE->BeginScene() ) )
		return -1;

	GDEVICE->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
	GDEVICE->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);

	SAFE_RENDER(	m_pGeo	);

	RenderText();

	GDEVICE->EndScene();

	return S_OK;
}


HRESULT CMain::RenderText()
{
	GDEVICE->SetRenderState(D3DRS_LIGHTING, FALSE);
	GDEVICE->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
	GDEVICE->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);
	GDEVICE->SetTexture( 0, 0);

	CHAR szMsg[MAX_PATH];
	RECT rc;
	rc.left   = 2;
	rc.right  = m_d3dsdBackBuffer.Width - 20;
	rc.top = 3;
	rc.bottom = rc.top + 20;

	sprintf(szMsg, "%s %s",m_strDeviceStats, m_strFrameStats );

	m_pD3DXFont->DrawText(NULL, szMsg, -1, &rc, 0, D3DXCOLOR(1,1,0,1) );

	return S_OK;
}

LRESULT CMain::MsgProc( HWND hWnd, UINT msg, WPARAM wParam,LPARAM lParam)
{
	WPARAM	wparHi;
	WPARAM	wparLo;

	wparHi = HIWORD(wParam);
	wparLo = LOWORD(wParam);

	switch( msg )
	{
		case WM_PAINT:
		{
			if( m_bLoadingApp )
			{
				HDC hDC = GetDC( hWnd );
				RECT rc;
				GetClientRect( hWnd, &rc );
				ReleaseDC( hWnd, hDC );
			}
			break;
		}
	}

	return CD3DApplication::MsgProc( hWnd, msg, wParam, lParam );
}


// Implementation of the CMcGeo class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMcGeo::CMcGeo()
{
	m_pDev		= NULL;

	m_pBox		= NULL;
	m_pCylinder	= NULL;
	m_pSphere	= NULL;
	m_pTorus	= NULL;
	m_pTeapot	= NULL;
}

CMcGeo::~CMcGeo()
{
	Destroy();
}


INT CMcGeo::Create(LPDIRECT3DDEVICE9 pDev)
{
	m_pDev	= pDev;

	D3DXCreateBox(m_pDev, 1, 2, 3,&m_pBox,NULL);
	D3DXCreateCylinder(m_pDev, 2, 3, 5, 15, 4, &m_pCylinder, NULL);
	D3DXCreateSphere(m_pDev, 3, 16, 8, &m_pSphere, NULL);
	D3DXCreateTorus(m_pDev, 1, 3, 9, 20, &m_pTorus, NULL);
	D3DXCreateTeapot(m_pDev, &m_pTeapot, 0);
	
	m_fT = 0.f;

	return 0;
}


void CMcGeo::Destroy()
{
	SAFE_RELEASE(	m_pBox		);
	SAFE_RELEASE(	m_pCylinder	);
	SAFE_RELEASE(	m_pSphere	);
	SAFE_RELEASE(	m_pTorus	);
	SAFE_RELEASE(	m_pTeapot	);
}


INT CMcGeo::Restore()
{
	return 0;
}


void CMcGeo::Invalidate()
{
}


INT	CMcGeo::FrameMove()
{
	m_fT += GMAIN->GetElapsedTime();

	D3DXMATRIX mtX, mtY;

	D3DXMatrixRotationX(&mtX, D3DXToRadian(45));
	D3DXMatrixRotationY(&mtY, m_fT);
	
	m_mtWld = mtX * mtY;
	
	return 0;
}

void CMcGeo::Render()
{
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);

	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER , D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER , D3DTEXF_LINEAR);

	m_pDev->SetRenderState( D3DRS_LIGHTING,  FALSE);
	m_pDev->SetRenderState( D3DRS_ALPHABLENDENABLE,  FALSE);
	m_pDev->SetRenderState( D3DRS_ALPHATESTENABLE,  FALSE);

	m_pDev->SetRenderState(D3DRS_FILLMODE, D3DFILL_WIREFRAME);
	m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);

	
	// Draw Box.
	m_mtWld._41 = -16.f;
	m_mtWld._42 = 2.f;
	m_mtWld._43 = 20.f;

	m_pDev->SetTransform(D3DTS_WORLD, &m_mtWld);
	m_pBox->DrawSubset(0);

	//Draw Cylinder
	m_mtWld._41 = -8.f;
	m_mtWld._42 = 2.f;
	m_mtWld._43 = 20.f;

	m_pDev->SetTransform(D3DTS_WORLD, &m_mtWld);
	m_pCylinder->DrawSubset(0);

	//Draw Sphere
	m_mtWld._41 = -0.f;
	m_mtWld._42 = 2.f;
	m_mtWld._43 = 20.f;
	m_pDev->SetTransform(D3DTS_WORLD, &m_mtWld);
	m_pSphere->DrawSubset(0);

	//Draw Torus
	m_mtWld._41 = 8.f;
	m_mtWld._42 = 2.f;
	m_mtWld._43 = 20.f;

	m_pDev->SetTransform(D3DTS_WORLD, &m_mtWld);
	m_pTorus->DrawSubset(0);

	//Draw Teapot
	m_mtWld._41 = 16.f;
	m_mtWld._42 = 2.f;
	m_mtWld._43 = 20.f;

	m_pDev->SetTransform(D3DTS_WORLD, &m_mtWld);
	m_pTeapot->DrawSubset(0);


	// ������������ ���� ����� ���� ��ķ� �ʱ�ȭ(�߿�)
	D3DXMatrixIdentity(&m_mtWld);
	m_pDev->SetTransform(D3DTS_WORLD, &m_mtWld);

	
	m_pDev->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);


}
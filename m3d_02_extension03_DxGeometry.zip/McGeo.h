// Interface for the CMcGeo class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MCGEO_H_
#define _MCGEO_H_

class CMcGeo
{
protected:
	LPDIRECT3DDEVICE9	m_pDev;

	LPD3DXMESH	m_pBox;
	LPD3DXMESH	m_pCylinder;
	LPD3DXMESH	m_pSphere;
	LPD3DXMESH	m_pTorus;
	LPD3DXMESH	m_pTeapot;

	D3DXMATRIX m_mtWld;
	FLOAT		m_fT;
	
public:
	CMcGeo();
	~CMcGeo();

	INT		Create(LPDIRECT3DDEVICE9 pDev);
	void	Destroy();

	INT		Restore();
	void	Invalidate();

	INT		FrameMove();
	void	Render();
};

#endif
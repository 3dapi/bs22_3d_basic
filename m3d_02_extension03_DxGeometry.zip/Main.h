// Interface for the CMain class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MAIN_H_
#define _MAIN_H_


class CMain : public CD3DApplication
{
public:
	ID3DXFont*		m_pD3DXFont	;												// D3DX font
	
	CMcGeo*			m_pGeo		;

	MATA			m_mtViw		;												// View Matrix
	MATA			m_mtPrj		;												// Projection Matrix


public:
	virtual HRESULT Init();
	virtual HRESULT Destroy();

	virtual HRESULT Restore();
	virtual HRESULT Invalidate();
	
	virtual HRESULT FrameMove();
	virtual HRESULT Render();
	
	HRESULT RenderText();
	
public:
	LRESULT MsgProc( HWND, UINT, WPARAM, LPARAM);
	CMain();

	FLOAT	GetElapsedTime()	{	return m_fElapsedTime;	}
};

extern CMain*	g_pApp;


#endif

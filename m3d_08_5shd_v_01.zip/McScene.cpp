// Implementation of the CMcScene class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMcScene::CMcScene()
{
	m_pDev		= NULL;
	m_pMesh		= NULL;
}


CMcScene::~CMcScene()
{
	Destroy();
}

void CMcScene::Destroy()
{
	SAFE_RELEASE( m_pMesh	);
}


INT CMcScene::Create(LPDIRECT3DDEVICE9 pDev)
{
	HRESULT hr=-1;

	m_pDev = pDev;

	D3DXMATRIX mtZ, mtX;
	D3DXMatrixRotationX(&mtX, D3DXToRadian(90));
	D3DXMatrixRotationZ(&mtZ, D3DXToRadian(-30));

	m_mtObject = mtX * mtZ;
//	D3DXCreateTeapot(m_pDev, &m_pMesh, NULL);
	D3DXCreateCylinder(m_pDev, 60, 60, 250, 40, 20, &m_pMesh, NULL);






	// ������ ȭ�鿡 ���� ������ ���´�. ȭ�� ������ ������� ����̽��� �����
	// ������ �ڵ��� ã�´�.
	D3DDEVICE_CREATION_PARAMETERS Parameters;
	m_pDev->GetCreationParameters(&Parameters);

	// �����쿡 �ش��ϴ� ȭ�� ������ ��´�.
	RECT rc;
	GetClientRect(Parameters.hFocusWindow, &rc);

	FLOAT	sx = FLOAT(rc.right - rc.left);
	FLOAT	sy = FLOAT(rc.bottom- rc.top );



	m_pRhw[0].p = D3DXVECTOR4(  0, sy, 0.0f, 1.0f );
	m_pRhw[1].p = D3DXVECTOR4(  0,  0, 0.0f, 1.0f );
	m_pRhw[2].p = D3DXVECTOR4( sx, sy, 0.0f, 1.0f );
	m_pRhw[3].p = D3DXVECTOR4( sx,  0, 0.0f, 1.0f );

	m_pRhw[0].d = 0xAfFF0000;
	m_pRhw[1].d = 0xAf00FF00;
	m_pRhw[2].d = 0xAf0000FF;
	m_pRhw[3].d = 0xAfFF00FF;

	return 0;
}


INT CMcScene::FrameMove()
{
	CLcInput*	pInput = GMAIN->GetInput();
	
	if(pInput->KeyState(VK_UP))
		m_mtObject._43 +=1.f;

	if(pInput->KeyState(VK_DOWN))
		m_mtObject._43 -=1.f;

	if(pInput->KeyState(VK_RIGHT))
		m_mtObject._41 +=1.f;

	if(pInput->KeyState(VK_LEFT))
		m_mtObject._41 -=1.f;

	return 0;
}


void CMcScene::Render()
{
	static D3DXMATRIX mtI(1,0,0,0,    0,1,0,0,    0,0,1,0,    0,0,0,1);
	m_pDev->SetRenderState( D3DRS_LIGHTING, FALSE );
	m_pDev->SetRenderState( D3DRS_FOGENABLE, FALSE );


	m_pDev->SetRenderState(D3DRS_FILLMODE, D3DFILL_WIREFRAME);
	m_pDev->SetTransform(D3DTS_WORLD, &m_mtObject);
	m_pMesh->DrawSubset(0);
	m_pDev->SetTransform(D3DTS_WORLD, &mtI);
	m_pDev->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
}


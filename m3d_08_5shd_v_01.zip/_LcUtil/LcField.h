// Interface for the CLcField class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LcField_H_
#define _LcField_H_

class CLcField
{
public:
	struct VtxD
	{
		D3DXVECTOR3	p;

		DWORD	d;

		VtxD() : p(0,0,0), d(0xFF006600){}
		VtxD(FLOAT X, FLOAT Y, FLOAT Z, DWORD D=0xFF006600) : p(X,Y,Z), d(D){}

		enum	{FVF = (D3DFVF_XYZ|D3DFVF_DIFFUSE),};
	};

protected:
	LPDIRECT3DDEVICE9 m_pDev;
	VtxD		m_pVtx[4];

public:
	CLcField();
	virtual ~CLcField();

	INT		Create(LPDIRECT3DDEVICE9 pDev);
	void	Destroy();

	INT		FrameMove();
	void	Render();
};

#endif
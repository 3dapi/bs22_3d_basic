// Interface for the CMcScene class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _McScene_H_
#define _McScene_H_


struct VtxDUV1
{
	D3DXVECTOR3	p;
	DWORD		d;
	FLOAT		u,v;

	VtxDUV1() : p(0,0,0), u(0), v(0), d(0xFFFFFFFF){}
	VtxDUV1(FLOAT X,FLOAT Y,FLOAT Z
		,FLOAT U,FLOAT V, DWORD D=0XFFFFFFFF) : p(X,Y,Z), d(D),u(U), v(V){}
	enum { FVF = (D3DFVF_XYZ|D3DFVF_DIFFUSE|D3DFVF_TEX1)};
};


class CMcScene
{
protected:
	LPDIRECT3DDEVICE9		m_pDev;

	VtxDUV1					m_pVtx[4];
	LPDIRECT3DTEXTURE9		m_pTex;
	
public:
	CMcScene();
	virtual ~CMcScene();

	INT		Create(LPDIRECT3DDEVICE9 pDev);
	void	Destroy();

	INT		FrameMove();
	void	Render();
};

#endif
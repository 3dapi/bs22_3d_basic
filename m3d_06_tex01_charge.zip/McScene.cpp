// Implementation of the CMcScene class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMcScene::CMcScene()
{
	m_pTx	= NULL;
}

CMcScene::~CMcScene()
{
	Destroy();
}

INT CMcScene::Create(LPDIRECT3DDEVICE9 pDev)
{
	m_pDev	= pDev;

	m_pVtx[0] = VtxUV1(-5.0f, -5.0f, 5.f, -2.f,  3.f);
	m_pVtx[1] = VtxUV1(-5.0f,  5.0f, 5.f, -2.f, -2.f);
	m_pVtx[2] = VtxUV1( 5.0f,  5.0f, 5.f,  3.f, -2.f);
	m_pVtx[3] = VtxUV1( 5.0f, -5.0f, 5.f,  3.f,  3.f);

	D3DXCreateTextureFromFile(m_pDev, "Texture/charge.png", &m_pTx);

	return 0;
}


void CMcScene::Destroy()
{
	SAFE_RELEASE(	m_pTx	);
}

INT CMcScene::FrameMove()
{
	return 0;
}

void CMcScene::Render()
{
	m_pDev->SetRenderState(D3DRS_LIGHTING, FALSE);



	m_pDev->SetTexture(0, m_pTx);
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_MIRROR);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_MIRROR);

	m_pDev->SetFVF(VtxUV1::FVF);
	m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLEFAN, 2, m_pVtx, sizeof(VtxUV1));

	m_pDev->SetTexture(0, NULL);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);
}



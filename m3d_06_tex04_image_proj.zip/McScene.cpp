// Implementation of the CMcScene class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMcScene::CMcScene()
{
	m_pDev	= NULL;
	
	m_nVtx	= 0;
	m_nIdx	= 0;
	m_pVtx	= NULL;
	m_pIdx	= NULL;
	
	m_pTxTiger	= NULL;
	m_pTxLogo	= NULL;
}

CMcScene::~CMcScene()
{
	Destroy();
}

INT CMcScene::Create(LPDIRECT3DDEVICE9 pDev)
{
	HRESULT hr;
	INT		i;

	m_pDev	= pDev;
	
	
	LPD3DXMESH		pMdlS=NULL;
	if( FAILED( D3DXLoadMeshFromX( "xFile/Tiger.x",	D3DXMESH_SYSTEMMEM,	m_pDev, NULL, NULL, NULL, NULL, &pMdlS ) ) )
		return -1;
	
	D3DXCreateTextureFromFile(m_pDev, "xFile/tiger.bmp", &m_pTxTiger);
	
	
	LPD3DXMESH pMdlD=NULL;
	hr = pMdlS->CloneMeshFVF(D3DXMESH_SYSTEMMEM, VtxUV1::FVF, m_pDev, &pMdlD);
	pMdlS->Release();
	
	m_nVtx = pMdlD->GetNumVertices();
	m_nIdx = pMdlD->GetNumFaces();
	
	//	DWORD dFVF = pMdlD->GetFVF();
	
	m_pVtx = new VtxUV1[m_nVtx];
	m_pIdx = new VtxIdx[m_nIdx];
	
	void* pVtx= NULL;
	hr = pMdlD->LockVertexBuffer(0, &pVtx);
	
	memcpy(m_pVtx, pVtx, m_nVtx * sizeof(VtxUV1));
	
	hr = pMdlD->UnlockVertexBuffer();
	
	void* pIdx= NULL;
	hr = pMdlD->LockIndexBuffer(0, &pIdx);
	
	memcpy(m_pIdx, pIdx, m_nIdx * sizeof(VtxIdx));
	
	hr = pMdlD->UnlockIndexBuffer();
	
	pMdlD->Release();
	
	
	FLOAT	fMin =1000000;
	for(i=0; i<m_nVtx; ++i)
	{
		if(m_pVtx[i].p.y <fMin)
			fMin = m_pVtx[i].p.y;
	}

	for(i=0; i<m_nVtx; ++i)
	{
		m_pVtx[i].p.y -= fMin;
	}

	float fSCale=10;
	for(i=0; i<m_nVtx; ++i)
	{
		m_pVtx[i].p *= fSCale;
	}


	m_pPlane[0] = VtxUV1(-25, 0, -25, 0, 1);
	m_pPlane[1] = VtxUV1(-25, 0,  25, 0, 0);
	m_pPlane[2] = VtxUV1( 25, 0,  25, 1, 0);
	m_pPlane[3] = VtxUV1( 25, 0, -25, 1, 1);


	D3DXCreateTextureFromFile(m_pDev, "Texture/dx5_logo.png", &m_pTxLogo);
	
	return 0;
}


void CMcScene::Destroy()
{
	SAFE_DELETE_ARRAY(	m_pVtx		);
	SAFE_DELETE_ARRAY(	m_pIdx		);
	SAFE_RELEASE(	m_pTxTiger	);
	SAFE_RELEASE(	m_pTxLogo	);
}

INT CMcScene::FrameMove()
{
	D3DXMATRIX	mtTex;
	D3DXMATRIX	mtViwI;
	D3DXMATRIX	mtPrj;

	D3DXMATRIX	mtLgt;
	D3DXVECTOR3	vcLgtPos(25, 25, -25);
	D3DXVECTOR3	vcLgtLook(0, 0, 0);

	FLOAT fRotAngle = D3DXToRadian( GetTickCount() * 0.02f );
	vcLgtPos.x = 20 * cosf(fRotAngle);
	vcLgtPos.z = 20 * sinf(fRotAngle);

	D3DXMatrixLookAtLH(&mtLgt, &vcLgtPos, &vcLgtLook, &D3DXVECTOR3(0,1,0));
	D3DXMatrixPerspectiveFovLH(&mtPrj, D3DXToRadian(45), 1, 1, 1000);
	
	m_pDev->GetTransform( D3DTS_VIEW, &mtViwI);
	D3DXMatrixInverse(&mtViwI, NULL, &mtViwI);
	
	mtTex	= D3DXMATRIX(0.5F,  0.0F,  0,	0,
						 0.0F, -0.5F,  0,	0,
						 0.0F,  0.0F,  1,	0,
						 0.5F,  0.5F,  0,	1
						);

	// Camera Space�� ������ �������� �ٲٱ� ���ؼ� ī�޶� ���� ����� ���ฦ�� ���Ѵ�.
	m_mtPrjTex = mtViwI * mtLgt * mtPrj * mtTex;
	
	return 0;
}

void CMcScene::Render()
{
	m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
	m_pDev->SetRenderState(D3DRS_LIGHTING, FALSE);
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);


	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_BORDER);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_BORDER);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSW, D3DTADDRESS_BORDER);
	m_pDev->SetSamplerState(0, D3DSAMP_BORDERCOLOR, 0x00FFFFFF);

//
//	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP);
//	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP);
//	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSW, D3DTADDRESS_CLAMP);

	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
	m_pDev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	m_pDev->SetRenderState(D3DRS_DESTBLEND,D3DBLEND_INVSRCALPHA);


	m_pDev->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
	m_pDev->SetTextureStageState(0, D3DTSS_COLORARG2, D3DTA_DIFFUSE);
	m_pDev->SetTextureStageState(0, D3DTSS_COLOROP  , D3DTOP_MODULATE);

	m_pDev->SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
	m_pDev->SetTextureStageState(0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE);
	m_pDev->SetTextureStageState(0, D3DTSS_ALPHAOP  , D3DTOP_MODULATE);
	
	
	
	m_pDev->SetTransform( D3DTS_TEXTURE0, &m_mtPrjTex );
	m_pDev->SetTextureStageState( 0, D3DTSS_TEXTURETRANSFORMFLAGS, D3DTTFF_COUNT4 | D3DTTFF_PROJECTED );
	m_pDev->SetTextureStageState( 0, D3DTSS_TEXCOORDINDEX, D3DTSS_TCI_CAMERASPACEPOSITION );
	
	m_pDev->SetFVF(VtxUV1::FVF);
	m_pDev->SetTexture(0, m_pTxLogo);
	

	// Draw Tiger
	m_pDev->DrawIndexedPrimitiveUP(D3DPT_TRIANGLELIST
		, 0
		, m_nVtx
		, m_nIdx
		, m_pIdx
		, D3DFMT_INDEX16
		, m_pVtx
		, sizeof(VtxUV1));


	// Draw Plane
	m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLEFAN, 2, m_pPlane, sizeof(VtxUV1));


	D3DXMATRIX mtI;
	D3DXMatrixIdentity(&mtI);
	m_pDev->SetTransform(D3DTS_TEXTURE0, &mtI);
	m_pDev->SetTexture(0, NULL);
	m_pDev->SetTextureStageState( 0, D3DTSS_TEXTURETRANSFORMFLAGS, D3DTTFF_DISABLE);
	m_pDev->SetTextureStageState( 0, D3DTSS_TEXCOORDINDEX, D3DTSS_TCI_PASSTHRU );


	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
}



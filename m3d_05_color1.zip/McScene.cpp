// Implementation of the CMcScene class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMcScene::CMcScene()
{
	m_pDev	= NULL;

	m_pVB	= NULL;
}

CMcScene::~CMcScene()
{
	Destroy();
}


INT CMcScene::Create(LPDIRECT3DDEVICE9 pDev)
{
	m_pDev	= pDev;

	m_pDev->CreateVertexBuffer(
		4 * sizeof(VtxD),
		0,
		VtxD::FVF,
		D3DPOOL_MANAGED,
		&m_pVB,
		0);


	// Fill the buffer with the triangle data.

	VtxD* v;
	m_pVB->Lock(0, 0, (void**)&v, 0);

	// Fan
//	DWORD	PINK  =	D3DCOLOR_XRGB(     255,   0, 255);
//	DWORD	RED   = D3DCOLOR_ARGB(255, 255,   0,   0);
//	DWORD	GREEN = D3DCOLOR_RGBA(  0, 255,   0, 255);
//	DWORD	BLUE  =	D3DCOLOR_XRGB(  0,   0, 255);
//
//
//	v[0] = VtxD(-1.0f, 0.0f, 2.0f, PINK	 );
//	v[1] = VtxD( 0.0f, 1.0f, 2.0f, RED   );
//	v[2] = VtxD( 1.0f, 0.0f, 2.0f, GREEN );
//	v[3] = VtxD( 0.0f,-1.0f, 2.0f, BLUE  );


	//	// Strip
D3DXCOLOR	red(1, 0, 0, 1);
D3DXCOLOR	green = D3DXCOLOR(0, 1, 0, 1);
DWORD		blue  = D3DXCOLOR(0, 0, 1, 1);

D3DXCOLOR	pink;
pink  = red;
pink += blue;

	v[2] = VtxD(-1.0f, 0.0f, 2.0f, pink);
	v[0] = VtxD( 0.0f, 1.0f, 2.0f, red );
	v[1] = VtxD( 1.0f, 0.0f, 2.0f, green);
	v[3] = VtxD( 0.0f,-1.0f, 2.0f, blue);

	m_pVB->Unlock();

	return 0;
}

void CMcScene::Destroy()
{
	SAFE_RELEASE(	m_pVB	);
}


INT CMcScene::FrameMove()
{
	LPDIRECT3DSURFACE9	pSrf=NULL;
	D3DSURFACE_DESC		desc;
	m_pDev->GetBackBuffer( 0, 0, D3DBACKBUFFER_TYPE_MONO, &pSrf );
	pSrf->GetDesc( &desc );
	pSrf->Release();

	D3DXMATRIX proj;
	D3DXMatrixPerspectiveFovLH(
		&proj,
		D3DX_PI * 0.5f, // 90 - degree
		(float)desc.Width/ (float)desc.Height,
		1.0f,
		5000.0f);
	m_pDev->SetTransform(D3DTS_PROJECTION, &proj);


	return 0;
}


void CMcScene::Render()
{
	m_pDev->SetRenderState(D3DRS_LIGHTING, FALSE);			// ���� ��Ȱ��ȭ



	// ���� �簢��
	m_pDev->SetRenderState(D3DRS_SHADEMODE, D3DSHADE_FLAT);	// Flat Shading

	D3DXMatrixTranslation(&m_mtW, -1.25f, 0.0f, 0.0f);
	m_pDev->SetTransform(D3DTS_WORLD, &m_mtW);

	m_pDev->SetFVF(VtxD::FVF);
	m_pDev->SetStreamSource(0, m_pVB, 0, sizeof(VtxD));
//	m_pDev->DrawPrimitive(D3DPT_TRIANGLEFAN, 0, 2);
	m_pDev->DrawPrimitive(D3DPT_TRIANGLESTRIP, 0, 2);



	// ���� �簢��
	m_pDev->SetRenderState(D3DRS_SHADEMODE, D3DSHADE_GOURAUD);	// ���� ���̵�

	D3DXMatrixTranslation(&m_mtW, 1.25f, 0.0f, 0.0f);
	m_pDev->SetTransform(D3DTS_WORLD, &m_mtW);


	m_pDev->SetFVF(VtxD::FVF);
	m_pDev->SetStreamSource(0, m_pVB, 0, sizeof(VtxD));
//	m_pDev->DrawPrimitive(D3DPT_TRIANGLEFAN, 0, 2);
	m_pDev->DrawPrimitive(D3DPT_TRIANGLESTRIP, 0, 2);
}
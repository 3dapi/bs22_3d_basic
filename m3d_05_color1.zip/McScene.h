// Interface for the CMcScene class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MCSCENE_H_
#define _MCSCENE_H_

struct VtxD
{
	D3DXVECTOR3 p;
	DWORD		d;

	VtxD(){}
	VtxD(FLOAT X, FLOAT Y, FLOAT Z, DWORD D) : p(X, Y, Z), d(D){}
	enum{ FVF = (D3DFVF_XYZ | D3DFVF_DIFFUSE),	};
};


class CMcScene
{
protected:
	LPDIRECT3DDEVICE9			m_pDev;

	D3DXMATRIX					m_mtW;
	LPDIRECT3DVERTEXBUFFER9		m_pVB;

public:
	CMcScene();
	virtual ~CMcScene();

	INT		Create(LPDIRECT3DDEVICE9 pDev);
	void	Destroy();

	INT		FrameMove();
	void	Render();
};

#endif
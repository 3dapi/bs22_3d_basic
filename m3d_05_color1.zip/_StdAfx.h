#pragma warning(disable: 4324)
#pragma warning(disable: 4996)


#ifndef __STDAFX_H_
#define __STDAFX_H_

#pragma once

#define STRICT
#define	WIN32_LEAN_AND_MEAN

#include <windows.h>
#include <windowsx.h>
#include <basetsd.h>
#include <commctrl.h>
#include <commdlg.h>

#include <math.h>
#include <mmsystem.h>
#include <stdio.h>
#include <tchar.h>


#include <D3D9.h>
#include <d3dx9.h>

#include "DXUtil.h"
#include "D3DUtil.h"
#include "D3DEnum.h"
#include "D3DSettings.h"

#include "resource.h"
#include "D3DApp.h"


#define GMAIN			g_pApp
#define GHINST			g_pApp->m_hInst
#define GHWND			g_pApp->m_hWnd

#define GDEVICE			g_pApp->m_pd3dDevice


#include "McScene.h"





#include "Main.h"


#endif
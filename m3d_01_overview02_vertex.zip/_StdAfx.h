#pragma warning(disable: 4324)
#pragma warning(disable: 4996)


#ifndef __STDAFX_H_
#define __STDAFX_H_

#pragma comment(lib, "d3d9.lib")

#include <windows.h>
#include <d3d9.h>







#include "Main.h"

#endif
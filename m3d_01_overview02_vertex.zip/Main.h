// Interface for the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _MAIN_H_
#define _MAIN_H_


LRESULT WINAPI WndProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam );



// ���� ����ü
struct VtxRHWD
{
    FLOAT x, y, z, rhw; // ��ġ
    DWORD color;        // ����
};



// Our custom FVF, which describes our custom vertex structure
#define D3DFVF_VTXST (D3DFVF_XYZRHW|D3DFVF_DIFFUSE)


class CMain
{
public:
	HINSTANCE				m_hInst			;
	HWND					m_hWnd			;
	LPDIRECT3D9             m_pD3D			;									// D3D
	LPDIRECT3DDEVICE9       m_pd3dDevice	;									// Device

public:
	LPDIRECT3DVERTEXBUFFER9 m_pVB			;									// ���� ����

public:
	INT		Init();
	void	Destroy();
	void	Render();

	INT		FrameMove();

	CMain();
	virtual ~CMain();

	INT		Create( HINSTANCE hInst);
	INT		Run();
	void	Cleanup();
	
	LRESULT MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam );
};

extern CMain*	g_pApp;

#endif

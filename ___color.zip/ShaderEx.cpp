// Implementation of the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CShaderEx::CShaderEx()
{
	m_pDev	= NULL;
	
	m_pFVF	= NULL;
	m_pEft	= NULL;
	
	m_pTex0	= NULL;
	m_pTex1	= NULL;
	m_pTex2	= NULL;
	m_pTex3	= NULL;
	m_pTex4	= NULL;
	m_pTex5	= NULL;
}


CShaderEx::~CShaderEx()
{
	Destroy();
}


INT CShaderEx::Create(PDEV pDev)
{
	HRESULT	hr=0;

	m_pDev	= pDev;

	m_pVtx[0] = VtxDUV1(-1, 1,  0,  0, 0);
	m_pVtx[1] = VtxDUV1( 1, 1,  0,  1, 0);
	m_pVtx[2] = VtxDUV1( 1,-1,  0,  1, 1);
	m_pVtx[3] = VtxDUV1(-1,-1,  0,  0, 1);


	DWORD dwFlags = 0;

	#if defined( _DEBUG ) || defined( DEBUG )
		dwFlags |= D3DXSHADER_DEBUG;
	#endif


	LPD3DXBUFFER	pErr	= NULL;
	
	hr = D3DXCreateEffectFromFile(	m_pDev
									,	"data/Shader.fx"
									,	NULL
									,	NULL
									,	dwFlags
									,	0
									,	&m_pEft
									,	&pErr);
	
	
	if ( FAILED(hr) )
	{
		MessageBox( GetActiveWindow(), (char*)pErr->GetBufferPointer(), "Err", 0);
		SAFE_RELEASE(pErr);
		return -1;
	}

	D3DVERTEXELEMENT9 vertex_decl[MAX_FVF_DECL_SIZE]={0};
	D3DXDeclaratorFromFVF(VtxDUV1::FVF, vertex_decl);
	
	if( FAILED( hr = m_pDev->CreateVertexDeclaration(vertex_decl, &m_pFVF)))
		return -1;


	D3DXCreateTextureFromFile(m_pDev, "Texture/colorw_magenta.png"	, &m_pTex0);
	D3DXCreateTextureFromFile(m_pDev, "Texture/colorw_yellow.png"	, &m_pTex1);
	D3DXCreateTextureFromFile(m_pDev, "Texture/colorw_cyan.png"		, &m_pTex2);
	D3DXCreateTextureFromFile(m_pDev, "Texture/colorb_red.png"		, &m_pTex3);
	D3DXCreateTextureFromFile(m_pDev, "Texture/colorb_green.png"	, &m_pTex4);
	D3DXCreateTextureFromFile(m_pDev, "Texture/colorb_blue.png"		, &m_pTex5);

	return 0;
}

void CShaderEx::Destroy()
{
	SAFE_RELEASE(	m_pFVF	);
	SAFE_RELEASE(	m_pEft	);
	SAFE_RELEASE(	m_pTex0	);
	SAFE_RELEASE(	m_pTex1	);
	SAFE_RELEASE(	m_pTex2	);
	SAFE_RELEASE(	m_pTex3	);
	SAFE_RELEASE(	m_pTex4	);
	SAFE_RELEASE(	m_pTex5	);
}


INT CShaderEx::Restore()
{
	return m_pEft->OnResetDevice();
}

void CShaderEx::Invalidate()
{
	m_pEft->OnLostDevice();
}


INT CShaderEx::FrameMove()
{
	return 0;
}


void CShaderEx::Render()
{
	INT i=0;

	for(i=0; i<7; ++i)
	{
		m_pDev->SetSamplerState(i, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP);
		m_pDev->SetSamplerState(i, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP);

		m_pDev->SetSamplerState(i, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
		m_pDev->SetSamplerState(i, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
		m_pDev->SetSamplerState(i, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
	}


	m_pDev->SetTexture(0, m_pTex0);
	m_pDev->SetTexture(1, m_pTex1);
	m_pDev->SetTexture(2, m_pTex2);
	m_pDev->SetTexture(3, m_pTex3);
	m_pDev->SetTexture(4, m_pTex4);
	m_pDev->SetTexture(5, m_pTex5);



	D3DVIEWPORT9	vpt;
	D3DVIEWPORT9	tpt;
	m_pDev->GetViewport(&vpt);

	tpt = vpt;

	m_pDev->SetVertexDeclaration(m_pFVF);


	m_pEft->SetTechnique("Tech");
	m_pEft->Begin(NULL, 0);


	m_pEft->BeginPass(0);
	tpt.Width = 600;
	m_pDev->SetViewport(&tpt);
	m_pDev->SetFVF(VtxDUV1::FVF);
	m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, m_pVtx, sizeof(VtxDUV1));
	m_pEft->EndPass();



	m_pEft->BeginPass(1);
	tpt.X = 600;
	m_pDev->SetViewport(&tpt);
	m_pDev->SetFVF(VtxDUV1::FVF);
	m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, m_pVtx, sizeof(VtxDUV1));
	m_pEft->EndPass();


	m_pEft->End();

	m_pDev->SetTexture(0, NULL);
	
	m_pDev->SetVertexDeclaration( NULL);
	m_pDev->SetVertexShader( NULL);
	m_pDev->SetPixelShader( NULL);

	m_pDev->SetViewport(&vpt);
}


